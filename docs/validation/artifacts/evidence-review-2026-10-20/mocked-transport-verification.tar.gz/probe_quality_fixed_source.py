"""Verify fixed-source transport offline; no model quality inference."""
from pathlib import Path
import os
T=Path(__file__).resolve().parent
safe={k:v for k,v in os.environ.items() if k in ('HOME','PATH','LANG','LC_ALL')}
safe.update(PYTHON_DOTENV_DISABLED='1',DEEPR_ENV_FILE=str(T/'absent.env'),DEEPR_DATA_DIR=str(T/'offline-quality-runtime/data'),DEEPR_REPORTS_PATH=str(T/'offline-quality-runtime/reports'),DEEPR_COST_DATA_DIR=str(T/'offline-quality-runtime/costs'))
os.environ.clear();os.environ.update(safe)
import asyncio,hashlib,json
from deepr.evals import correction_survival as cs
run=asyncio.run(cs.run_diagnostic(T/'quality-fixed-mock60',distractors=60,code_identity='Unreleased complete-finding and response-form candidate; mocked transport only'))
report=cs.build_report(run);items,_=cs.blinded_review_packet(cs.load_run(T/'quality-fixed-mock60'),salt='quality-fixed-transport-probe')
for item in items:
 c=item['review_context'];assert c['source_inventory_sha256']==run['source_inventory_sha256'][c['world_id']]
 assert all(hashlib.sha256(source['text'].encode()).hexdigest()==source['text_sha256'] for source in c['sources'])
 assert len(c['sources'])==60+({'w1':1,'w2':3,'w3':6}[c['world_id']])
 if item['case_id']=='historical':assert len(c['sources'])==61 and all(source['source_id'] not in ('release-v3','payments-note') for source in c['sources'])
assert run['paid_calls']==0 and len(run['attempts'])==36
assert report['arms']['production']['stages']['retrieval']=={'selected':18,'not_applicable':2}
assert report['arms']['production']['stages']['delivery']=={'delivered':18,'not_applicable':2}
assert all(row['status']=='isolated' for row in report['historical_isolation'])
report_path=T/'quality-fixed-mock60-report.json';report_path.write_text(json.dumps(report,indent=2)+'\n')
receipt={'case_set_sha256':run['case_set_sha256'],'recipe_sha256':cs.recipe_sha256(),'attempts':36,'real_model_calls':0,'source_inventory_fingerprints':run['source_inventory_sha256'],'production_retrieval':report['arms']['production']['stages']['retrieval'],'production_delivery':report['arms']['production']['stages']['delivery'],'historical_isolation':[row['status'] for row in report['historical_isolation']],'report_sha256':hashlib.sha256(report_path.read_bytes()).hexdigest(),'scope':'Current source transport/accounting; no semantic acceptance or model calls. Original source snapshots and failed trials unchanged.'}
(T/'quality-fixed-mock60-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
