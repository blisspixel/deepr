"""Verify exact brief prompts, then assemble retained outputs through owning seams."""
from pathlib import Path
from datetime import date
from dataclasses import asdict
import hashlib,importlib.util,json,sys
from deepr.experts import brief as current
from deepr.experts.corpus_store import CorpusStore
from deepr.experts.study_contracts import LensOutcome,StudyFinding,StudyResult
T=Path(__file__).resolve().parent;D=T/'packing-fixtures-v4';h=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((T/'review258-v4-reviewed-comparison.json').read_text())['labels_frozen_before_key'] is True
key=json.loads((D/'assignment-key-unopened/key.json').read_text());manifest=json.loads((D/'manifest.json').read_text())
legacy=T/'original_brief.py';assert h(legacy.read_bytes())==manifest['old_brief_sha256']
spec=importlib.util.spec_from_file_location('frozen_old_brief_assembly_probe',legacy);old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
out=T/'brief-assembly-probe';out.mkdir(exist_ok=False);corpus=CorpusStore('Fenn comparison',storage_dir=D/'corpus');results=[]
for iid,info in key.items():
 item=json.loads((D/f'{iid}.input.json').read_text())
 if item['kind']!='brief':continue
 scenario=info['pair'].split('.',1)[1];groups={lens:[] for lens in ('synopsis','orientation','mechanism','failure','contention','implication','analogy','question')}
 for source in item['sources']:
  fid=source['source_id'];text=source['text'];sha=h(text.encode());assert sha==source['text_sha256'] and corpus.read(sha)==text;lens,index=fid.rsplit('-',1)
  field='qualification' if fid=='contention-0' else 'observation'
  if scenario=='trailing-condition' and fid=='mechanism-0':field='mechanism'
  groups[lens].append(StudyFinding(lens=lens,axis='interrogation',kind='fixture',title=('When may a cache entry be renewed?' if scenario=='trailing-condition' and fid=='mechanism-0' else f'Fenn {fid}'),payload={field:text},anchors=[text[:70]],grounded_anchor_count=1,corpus_shas=[sha],finding_id=fid))
 study=StudyResult(expert_name='Fenn cache applicability',outcomes=[LensOutcome(lens=lens,axis='interrogation',status='ok',findings=fs) for lens,fs in groups.items()])
 domain='Cache entry renewal conditions and source qualifications' if scenario=='trailing-condition' else 'Cache applicability and source qualifications'
 module=old if info['arm']=='old' else current;kwargs={'expert_name':study.expert_name,'domain':domain,'as_of_date':date(2026,10,20)}
 prompt=module.build_brief_prompt(study,**kwargs);assert prompt==item['prompt'] and h(prompt.encode())==item['prompt_sha256']
 answer=json.loads((D/'answers'/f'{iid}.json').read_text());row={'item_id':iid,'pair':info['pair'],'arm':info['arm'],'status':answer['status'],'exact_prompt_reconstructed':True,'prompt_sha256':item['prompt_sha256'],'answer_sha256':answer.get('answer_sha256')}
 if 'answer' in answer:
  assert h(answer['answer'].encode())==answer['answer_sha256']
  try:
   parsed=json.loads(answer['answer']);assert isinstance(parsed,dict)
   selection={}
   if info['arm']=='current':
    _,selected=current.brief_prompt_with_selection(study,**kwargs);selection={'selection':selected}
   assembled=module.assemble_brief(parsed,expert_name=study.expert_name,result=study,corpus=corpus,as_of_date=date(2026,10,20),**selection);rendered=module.render_brief(assembled)
   folder=out/iid;folder.mkdir();(folder/'assembled.json').write_text(json.dumps(asdict(assembled),indent=2,default=str)+'\n');(folder/'rendered.md').write_text(rendered)
   row.update(assembly_status='completed',assembled_positions=len(assembled.positions),rendered_sha256=h(rendered.encode()),rendered_file=str(folder/'rendered.md'),limits='Assembly success is a form/transport observation; full semantic review remains separate.')
  except Exception as error:row.update(assembly_status='failed',error_type=type(error).__name__,error=str(error))
 else:row['assembly_status']='no_answer'
 results.append(row)
assert len(results)==4
(T/'brief-assembly-receipt.json').write_text(json.dumps({'results':results,'new_model_calls':0,'worlds':'Exact frozen source bytes; reconstructed study rendering matches every archived prompt before applying original/current assembler. No original evidence or answers rewritten.'},indent=2)+'\n');print(json.dumps(results,indent=2))
