# Fenn cache applicability: brief

## In sixty seconds

Studied sources (recorded attribution): Fenn catalogue caching can reduce repeated reads only for immutable public replies.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): Authenticated replies need tenant-scoped keys and revocation tracking.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): An operator trial found account-specific replies leaked across tenants when tenant keys were absent.
Cited findings (study binding: not checked in this view): contention-0
Studied sources (recorded attribution): Public immutable replies were unaffected by the tenant leakage issue.
Cited findings (study binding: not checked in this view): contention-0
Studied sources (recorded attribution): Do not cache authenticated replies until tenant keys and revocation tracking are verified.
Cited findings (study binding: not checked in this view): contention-0
Studied sources (recorded attribution): Most findings in the corpus are inventory facts that establish no cache policy.
Cited findings (study binding: not checked in this view): synopsis-1, orientation-0, orientation-1, mechanism-1, failure-0, failure-1, contention-1, implication-0, implication-1, analogy-0, analogy-1, question-0, question-1

## Where I land, and why

1. **When may a cache entry be renewed for Fenn catalogue data?**
   - Stance: Cache entries may be renewed for immutable public replies. Renewal for authenticated replies is prohibited until tenant-scoped keys and revocation tracking are verified.
   - Because: The synopsis explicitly limits caching benefits to immutable public replies and mandates tenant-scoped keys for authenticated data. The contention finding provides empirical evidence of cross-tenant leakage when these keys are absent, reinforcing the restriction. The mechanism finding mentions a synthetic trial but does not provide specific renewal conditions, so the stance relies on the explicit constraints in synopsis-0 and contention-0.
   - Confidence in that basis: high (High confidence because two independent findings (synopsis-0 and contention-0) align on the restriction, and the contention finding provides a concrete failure example. The other findings are placeholders that do not contradict this stance.)
   - **Does not resolve**: The mechanism-0 finding references a synthetic throughput trial that records timing and inventory but does not specify the cache policy constraints, leaving a gap between the trial data and the policy recommendation. The contention-0 finding is the only one providing a specific failure mode, but it is a single operator trial and may not represent all deployment configurations.
   - Would change my mind: If a documented Fenn release note or API specification explicitly states that authenticated replies can be safely cached without tenant-scoped keys, or if a new operator trial demonstrates zero leakage with a different keying strategy that does not require revocation tracking.
   - Rests on: Fenn synopsis-0 (synopsis-0); Fenn contention-0 (contention-0)
   - Evidential depth: 2 source(s), 2 publisher(s)

## Settled, live, unknown

**Settled (skip these)**
- Caching is only beneficial for immutable public replies.
- Authenticated replies require tenant-scoped keys and revocation tracking.
- Cross-tenant leakage occurs if tenant keys are absent for authenticated replies.

**Live**
- Whether the synthetic throughput trial in mechanism-0 supports or contradicts the caching restrictions.
- The specific conditions under which revocation tracking is considered 'verified'.

**Genuinely unknown**
- The performance impact of implementing tenant-scoped keys on cache hit rates.
- Whether any Fenn version allows caching of authenticated replies under specific, undocumented conditions.

## The numbers that matter

- 0 cache policy facts established by 13 of 15 findings.
- 1 operator trial demonstrating cross-tenant leakage.

## What people try that does not work

- Attempting to cache authenticated replies without tenant-scoped keys, which leads to cross-tenant data leakage as demonstrated in the operator trial.
- Assuming that the synthetic throughput trial in mechanism-0 validates a caching strategy, when it only records timing and inventory without establishing policy.

## Questions I expect

**Is the restriction on caching authenticated replies based on a single operator trial, and does it apply to all Fenn deployments?** (this one costs me something)
The restriction is based on the contention-0 finding, which describes a specific operator trial. While the synopsis-0 finding generalizes this to a policy recommendation, the evidence base is limited to one documented failure mode. It is not confirmed that all deployments exhibit this behavior, but the safe default is to assume it does until proven otherwise.
_Asked because: To challenge the generalizability of the stance based on a single data point._

**What specific metrics define 'verified' revocation tracking?**
The findings do not specify metrics. The stance relies on the qualitative requirement for 'revocation tracking' in synopsis-0 and contention-0. Without a defined standard, 'verified' remains an operational assumption rather than a measurable criterion.
_Asked because: To identify the lack of quantitative criteria in the source material._

## Who this rests on

| Origin | Sources | Trust | Note |
|---|---|---|---|
| fenn-hosted.example | 1 | primary | - |
| fenn-manual.example | 1 | primary | - |
| fenn-monitor.example | 1 | primary | - |
| fenn-release.example | 1 | primary | - |
| fenn-self.example | 1 | primary | - |
| filler-0.example | 1 | tertiary | - |
| filler-1.example | 1 | tertiary | - |
| filler-10.example | 1 | tertiary | - |
| filler-11.example | 1 | tertiary | - |
| filler-12.example | 1 | tertiary | - |
| filler-13.example | 1 | tertiary | - |
| filler-2.example | 1 | tertiary | - |
| filler-3.example | 1 | tertiary | - |
| filler-4.example | 1 | tertiary | - |
| filler-5.example | 1 | tertiary | - |
| filler-6.example | 1 | tertiary | - |
| filler-7.example | 1 | tertiary | - |
| filler-8.example | 1 | tertiary | - |
| filler-9.example | 1 | tertiary | - |
| lens-cap-analogy-0.example | 1 | primary | - |
| lens-cap-analogy-1.example | 1 | primary | - |
| lens-cap-analogy-2.example | 1 | primary | - |
| lens-cap-analogy-3.example | 1 | primary | - |
| lens-cap-contention-0.example | 1 | primary | - |
| lens-cap-contention-1.example | 1 | primary | - |
| lens-cap-contention-2.example | 1 | primary | - |
| lens-cap-contention-3.example | 1 | primary | - |
| lens-cap-failure-0.example | 1 | primary | - |
| lens-cap-failure-1.example | 1 | primary | - |
| lens-cap-failure-10.example | 1 | primary | - |
| lens-cap-failure-11.example | 1 | primary | - |
| lens-cap-failure-12.example | 1 | primary | - |
| lens-cap-failure-13.example | 1 | primary | - |
| lens-cap-failure-14.example | 1 | primary | - |
| lens-cap-failure-15.example | 1 | primary | - |
| lens-cap-failure-16.example | 1 | primary | - |
| lens-cap-failure-17.example | 1 | primary | - |
| lens-cap-failure-18.example | 1 | primary | - |
| lens-cap-failure-19.example | 1 | primary | - |
| lens-cap-failure-2.example | 1 | primary | - |
| lens-cap-failure-20.example | 1 | primary | - |
| lens-cap-failure-21.example | 1 | primary | - |
| lens-cap-failure-22.example | 1 | primary | - |
| lens-cap-failure-23.example | 1 | primary | - |
| lens-cap-failure-24.example | 1 | primary | - |
| lens-cap-failure-25.example | 1 | primary | - |
| lens-cap-failure-26.example | 1 | primary | - |
| lens-cap-failure-27.example | 1 | primary | - |
| lens-cap-failure-28.example | 1 | primary | - |
| lens-cap-failure-29.example | 1 | primary | - |
| lens-cap-failure-3.example | 1 | primary | - |
| lens-cap-failure-30.example | 1 | primary | - |
| lens-cap-failure-31.example | 1 | primary | - |
| lens-cap-failure-32.example | 1 | primary | - |
| lens-cap-failure-33.example | 1 | primary | - |
| lens-cap-failure-34.example | 1 | primary | - |
| lens-cap-failure-4.example | 1 | primary | - |
| lens-cap-failure-5.example | 1 | primary | - |
| lens-cap-failure-6.example | 1 | primary | - |
| lens-cap-failure-7.example | 1 | primary | - |
| lens-cap-failure-8.example | 1 | primary | - |
| lens-cap-failure-9.example | 1 | primary | - |
| lens-cap-implication-0.example | 1 | primary | - |
| lens-cap-implication-1.example | 1 | primary | - |
| lens-cap-implication-2.example | 1 | primary | - |
| lens-cap-implication-3.example | 1 | primary | - |
| lens-cap-mechanism-0.example | 1 | primary | - |
| lens-cap-mechanism-1.example | 1 | primary | - |
| lens-cap-mechanism-10.example | 1 | primary | - |
| lens-cap-mechanism-11.example | 1 | primary | - |
| lens-cap-mechanism-12.example | 1 | primary | - |
| lens-cap-mechanism-13.example | 1 | primary | - |
| lens-cap-mechanism-14.example | 1 | primary | - |
| lens-cap-mechanism-15.example | 1 | primary | - |
| lens-cap-mechanism-16.example | 1 | primary | - |
| lens-cap-mechanism-17.example | 1 | primary | - |
| lens-cap-mechanism-18.example | 1 | primary | - |
| lens-cap-mechanism-19.example | 1 | primary | - |
| lens-cap-mechanism-2.example | 1 | primary | - |
| lens-cap-mechanism-20.example | 1 | primary | - |
| lens-cap-mechanism-21.example | 1 | primary | - |
| lens-cap-mechanism-22.example | 1 | primary | - |
| lens-cap-mechanism-23.example | 1 | primary | - |
| lens-cap-mechanism-24.example | 1 | primary | - |
| lens-cap-mechanism-25.example | 1 | primary | - |
| lens-cap-mechanism-26.example | 1 | primary | - |
| lens-cap-mechanism-27.example | 1 | primary | - |
| lens-cap-mechanism-28.example | 1 | primary | - |
| lens-cap-mechanism-29.example | 1 | primary | - |
| lens-cap-mechanism-3.example | 1 | primary | - |
| lens-cap-mechanism-30.example | 1 | primary | - |
| lens-cap-mechanism-31.example | 1 | primary | - |
| lens-cap-mechanism-32.example | 1 | primary | - |
| lens-cap-mechanism-33.example | 1 | primary | - |
| lens-cap-mechanism-34.example | 1 | primary | - |
| lens-cap-mechanism-4.example | 1 | primary | - |
| lens-cap-mechanism-5.example | 1 | primary | - |
| lens-cap-mechanism-6.example | 1 | primary | - |
| lens-cap-mechanism-7.example | 1 | primary | - |
| lens-cap-mechanism-8.example | 1 | primary | - |
| lens-cap-mechanism-9.example | 1 | primary | - |
| lens-cap-orientation-0.example | 1 | primary | - |
| lens-cap-orientation-1.example | 1 | primary | - |
| lens-cap-orientation-10.example | 1 | primary | - |
| lens-cap-orientation-11.example | 1 | primary | - |
| lens-cap-orientation-12.example | 1 | primary | - |
| lens-cap-orientation-13.example | 1 | primary | - |
| lens-cap-orientation-14.example | 1 | primary | - |
| lens-cap-orientation-15.example | 1 | primary | - |
| lens-cap-orientation-16.example | 1 | primary | - |
| lens-cap-orientation-17.example | 1 | primary | - |
| lens-cap-orientation-18.example | 1 | primary | - |
| lens-cap-orientation-19.example | 1 | primary | - |
| lens-cap-orientation-2.example | 1 | primary | - |
| lens-cap-orientation-20.example | 1 | primary | - |
| lens-cap-orientation-21.example | 1 | primary | - |
| lens-cap-orientation-22.example | 1 | primary | - |
| lens-cap-orientation-23.example | 1 | primary | - |
| lens-cap-orientation-24.example | 1 | primary | - |
| lens-cap-orientation-25.example | 1 | primary | - |
| lens-cap-orientation-26.example | 1 | primary | - |
| lens-cap-orientation-27.example | 1 | primary | - |
| lens-cap-orientation-28.example | 1 | primary | - |
| lens-cap-orientation-29.example | 1 | primary | - |
| lens-cap-orientation-3.example | 1 | primary | - |
| lens-cap-orientation-30.example | 1 | primary | - |
| lens-cap-orientation-31.example | 1 | primary | - |
| lens-cap-orientation-32.example | 1 | primary | - |
| lens-cap-orientation-33.example | 1 | primary | - |
| lens-cap-orientation-34.example | 1 | primary | - |
| lens-cap-orientation-4.example | 1 | primary | - |
| lens-cap-orientation-5.example | 1 | primary | - |
| lens-cap-orientation-6.example | 1 | primary | - |
| lens-cap-orientation-7.example | 1 | primary | - |
| lens-cap-orientation-8.example | 1 | primary | - |
| lens-cap-orientation-9.example | 1 | primary | - |
| lens-cap-question-0.example | 1 | primary | - |
| lens-cap-question-1.example | 1 | primary | - |
| lens-cap-question-2.example | 1 | primary | - |
| lens-cap-question-3.example | 1 | primary | - |
| lens-cap-synopsis-0.example | 1 | primary | - |
| lens-cap-synopsis-1.example | 1 | primary | - |
| lens-cap-synopsis-10.example | 1 | primary | - |
| lens-cap-synopsis-11.example | 1 | primary | - |
| lens-cap-synopsis-12.example | 1 | primary | - |
| lens-cap-synopsis-13.example | 1 | primary | - |
| lens-cap-synopsis-14.example | 1 | primary | - |
| lens-cap-synopsis-15.example | 1 | primary | - |
| lens-cap-synopsis-16.example | 1 | primary | - |
| lens-cap-synopsis-17.example | 1 | primary | - |
| lens-cap-synopsis-18.example | 1 | primary | - |
| lens-cap-synopsis-19.example | 1 | primary | - |
| lens-cap-synopsis-2.example | 1 | primary | - |
| lens-cap-synopsis-20.example | 1 | primary | - |
| lens-cap-synopsis-21.example | 1 | primary | - |
| lens-cap-synopsis-22.example | 1 | primary | - |
| lens-cap-synopsis-23.example | 1 | primary | - |
| lens-cap-synopsis-24.example | 1 | primary | - |
| lens-cap-synopsis-25.example | 1 | primary | - |
| lens-cap-synopsis-26.example | 1 | primary | - |
| lens-cap-synopsis-27.example | 1 | primary | - |
| lens-cap-synopsis-28.example | 1 | primary | - |
| lens-cap-synopsis-29.example | 1 | primary | - |
| lens-cap-synopsis-3.example | 1 | primary | - |
| lens-cap-synopsis-30.example | 1 | primary | - |
| lens-cap-synopsis-31.example | 1 | primary | - |
| lens-cap-synopsis-32.example | 1 | primary | - |
| lens-cap-synopsis-33.example | 1 | primary | - |
| lens-cap-synopsis-34.example | 1 | primary | - |
| lens-cap-synopsis-4.example | 1 | primary | - |
| lens-cap-synopsis-5.example | 1 | primary | - |
| lens-cap-synopsis-6.example | 1 | primary | - |
| lens-cap-synopsis-7.example | 1 | primary | - |
| lens-cap-synopsis-8.example | 1 | primary | - |
| lens-cap-synopsis-9.example | 1 | primary | - |
| trailing-condition-mechanism-0.example | 1 | primary | - |

## Read this brief knowing

- 1 position(s) state a stance with no likelihood. A stance with no stated likelihood cannot be scored later, and so was never a judgment.

## Limitations

- 1 finding field(s) were shortened for synthesis and marked as shortened; the full text remains in the study.

---

Derived from study findings over a retained corpus. Positions are the expert's reading of that evidence, not verified fact; each states what would overturn it.
