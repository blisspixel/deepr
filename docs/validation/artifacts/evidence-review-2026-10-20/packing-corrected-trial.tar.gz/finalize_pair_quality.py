"""Freeze every independent whole-pair judgment before opening its method key."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,os
T=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();p=T/'review258-pair-quality-blinded.json';packet={v['pair_id']:v for v in json.loads(p.read_text())};f=json.loads((T/'review258-pair-quality-input-freeze.json').read_text());assert h(p.read_bytes())==f['packet_sha256']
reviews={};hashes={}
for who in ('R1','R2','R3'):
 path=T/f'reviewers/{who}/review258-pair-quality.json';rows=json.loads(path.read_text());by_id={r['pair_id']:r for r in rows};assert len(rows)==len(by_id)==len(packet)==8 and set(by_id)==set(packet)
 for iid,row in by_id.items():
  pair=packet[iid];assert row['disposition'] in ('no_material_difference','A_materially_worse','B_materially_worse','uncertain') and row['note'].strip() and row['abstention_assessment'].strip()
  assert set(row['source_ids'])<={v['source_id'] for v in pair['sources']}
  for side in ('A','B'):
   answer=pair[side];assert row[side+'_answer_sha256']==answer['answer_sha256'];assert h(answer['answer'].encode())==answer['answer_sha256'];quote=row[side+'_quote'];assert not quote or quote in answer['answer'] or quote in answer.get('assembled_markdown','')
 reviews[who]=by_id;hashes[who]=h(path.read_bytes())
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
freeze={'frozen_at':datetime.now(timezone.utc).isoformat(),'all_three_reviews_frozen_before_key':True,'assignment_key_opened':False,'packet_sha256':h(p.read_bytes()),'reviewer_sha256':hashes,'pairs_per_reviewer':8,'scope':'Three method-blind development quality audits. Root had already inspected methods for the primary frozen-label report; root is not represented as blinded. No primary labels may be revised. Independent service exact snapshot/cost unknown.'}
write(T/'review258-pair-quality-final-blind-freeze.json',freeze)
keypath=T/'review258-pair-quality-key-unopened.json';key=json.loads(keypath.read_text());assert set(key)==set(packet);opened=datetime.now(timezone.utc).isoformat();joined={}
for iid,info in key.items():
 values={}
 for who,rows in reviews.items():
  row=dict(rows[iid]);d=row['disposition'];row['method_disposition']=info[d[0]]+'_materially_worse' if d in ('A_materially_worse','B_materially_worse') else d;values[who]=row
 joined[info['pair']]={'pair_id':iid,'reviews':values}
r={'key_opened_at':opened,'labels_frozen_before_key':True,'assignment_key_sha256':h(keypath.read_bytes()),'pairs':joined,'counts_by_reviewer':{who:dict(Counter(v['reviews'][who]['method_disposition'] for v in joined.values())) for who in reviews},'accepted_policy':None,'requires_accountable_material_assessment':True,'limits':'No majority rule, statistical winner, held-out transfer, global semantic qualification, native budget reset or retrospective relabeling.'};write(T/'review258-pair-quality-reviewed.json',r);print(json.dumps({'counts_by_reviewer':r['counts_by_reviewer'],'pairs':{k:{w:x['method_disposition'] for w,x in v['reviews'].items()} for k,v in joined.items()}},indent=2))
