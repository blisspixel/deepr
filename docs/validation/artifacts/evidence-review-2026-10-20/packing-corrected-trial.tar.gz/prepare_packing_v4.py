"""Prospective correction of first-trial fixture and phase-budget defects."""
from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
s=(T/'packing_fixtures_v3.py').read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count,(old[:70],s.count(old));s=s.replace(old,new)
replace("DEST=TASK/'packing-fixtures-v3'","DEST=TASK/'packing-fixtures-v4'")
replace("FennCache planning note {i}: caching, tenant keys, Windows and Linux, eviction, entry limits and monitoring are topics for a future exercise. No defaults, measurements or recommendations are established. ","FennCache planning note {i}: This planning exercise introduces no new defaults, measurements or recommendations; it does not amend the operational manual, release or monitoring guidance. Caching and eviction are agenda topics only. ")
replace("'sources':full_sources,'prompt':prompt", "'sources':full_sources,'delivered_evidence':{'prompt':prompt,'prompt_sha256':h(prompt.encode())},'prompt':prompt")
replace("'output_tokens':3072 if kind=='brief' else 1024", "'output_tokens':6144 if kind=='brief' else 1024,'timeout_seconds':900 if kind=='brief' else 600")
replace("[{'source_id':sid,'text':text} for sid,text in SOURCES]", "[{'source_id':sid,'text':text,'text_sha256':h(text.encode()),'trust_class':'primary','observed_at':'2026-10-20','origin_key':sid+'.example'} for sid,text in SOURCES]+[{'source_id':f'filler-{i}','text':corpus.read(entry.sha256),'text_sha256':entry.sha256,'trust_class':entry.trust_class,'observed_at':entry.fetched_at,'origin_key':entry.origin_key} for i in range(14) for entry in corpus.entries.values() if entry.origin_key==f'filler-{i}.example']")
replace("The trial records timing and inventory detail only. ", "The trial records timing and inventory; a separate cache-policy constraint follows. ")
replace("'preserve-disagreement','expectation':'preserve','description':'Do not imply that the operator tenant-leak warning was absent, settled, or refuted; retain its scope or explicitly acknowledge unseen/shortened material.'", "'preserve-warning','expectation':'preserve','description':'Retain the reported tenant-key-absent leak and verification prerequisite. Do not claim the deployment hazard was mitigated or the warning refuted. Treating the scoped precaution as established guidance is allowed.'")
replace("The original mechanism-0 source permits renewal only after successful origin validation, never on a timer alone. Preserve that condition if established from delivered evidence; otherwise disclose the shortened/unavailable condition and defer renewal advice rather than invent it.", "The retained mechanism-0 policy requires successful origin validation before renewal and forbids timer-only extension. Preserve and explain this condition. Evaluate retained-world answer adequacy; record a cautious delivered-context gap in the rationale without counting an omitted known condition as used correctly.")
replace("all_sources.append({'source_id':fid,'text':text})", "all_sources.append({'source_id':fid,'text':text,'text_sha256':h(text.encode()),'trust_class':entry.trust_class,'observed_at':entry.fetched_at,'origin_key':entry.origin_key})")
replace("'pairs':len(pairs),'answers_scheduled'", "'fixture_version':'packing-v4','preceding_trial':'packing-fixtures-v3 retained and not admitted as a clean contrast; source-scope ambiguity, incomplete initial review handoff, delivery-dependent obligation and one3072-token truncated brief. This prospective revision does not overwrite it.','phase_budget':'Consult1024tokens/600seconds; brief6144tokens/900seconds, both methods equal. Global100calls/10800seconds from ORIGINAL protocol start remain binding. No automatic retry.','review_unit':'Semantic labels evaluate individual obligations against the complete retained source world. Exact delivered prompts localize transport loss and support explanation of cautious gaps; a missing known condition is still missing, never promoted to successful evidence use. Completion/schema status is separate from visible content.','pairs':len(pairs),'answers_scheduled'")
replace("'source_commit':'47bd", "'source_commit':'47bd")
# Annotation only: no new semantic acceptance threshold or source/method authority.
path=T/'packing_fixtures_v4.py';assert not path.exists();path.write_text(s)
print('Prepared separate v4 fixture generator; no generation dispatched.')
