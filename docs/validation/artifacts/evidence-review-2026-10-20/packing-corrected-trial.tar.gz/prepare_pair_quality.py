"""Present every frozen pair for a second, method-blind material-quality audit."""
from pathlib import Path
import hashlib,json,os,secrets
from collections import defaultdict
from datetime import datetime,timezone
T=Path(__file__).resolve().parent;D=T/'packing-fixtures-v4';h=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((T/'review258-v4-reviewed-comparison.json').read_text())['labels_frozen_before_key'] is True
key=json.loads((D/'assignment-key-unopened/key.json').read_text());assembly=json.loads((T/'brief-assembly-receipt.json').read_text());assembled={x['item_id']:x for x in assembly['results']};pairs=defaultdict(dict)
for iid,info in key.items():
 item=json.loads((D/f'{iid}.input.json').read_text());answer=json.loads((D/'answers'/f'{iid}.json').read_text());pairs[info['pair']][info['arm']]=(item,answer)
packet=[];private={}
for name,pair in sorted(pairs.items()):
 assert set(pair)=={'old','current'};old=pair['old'][0];current=pair['current'][0]
 assert old['sources']==current['sources'] and old['question']==current['question'] and old['obligations']==current['obligations']
 oid=secrets.token_hex(8);order=secrets.choice([['old','current'],['current','old']]);entry={'pair_id':oid,'kind':old['kind'],'question':old['question'],'sources':old['sources'],'obligations':old['obligations']}
 for side,arm in zip(('A','B'),order,strict=True):
  item,response=pair[arm];row={'item_id':item['item_id'],'status':response['status'],'delivered_prompt':item['prompt'],'prompt_sha256':item['prompt_sha256']}
  for field in ('answer','answer_sha256','json_object','position_count'):
   if field in response:row[field]=response[field]
  if 'answer' in response:assert h(response['answer'].encode())==response['answer_sha256']
  if item['item_id'] in assembled:
   a=assembled[item['item_id']];row['assembly_status']=a['assembly_status']
   if 'rendered_file' in a:
    text=Path(a['rendered_file']).read_text();assert h(text.encode())==a['rendered_sha256'];row['assembled_markdown']=text
  entry[side]=row
 packet.append(entry);private[oid]={'pair':name,'A':order[0],'B':order[1]}
assert len(packet)==8
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
write(T/'review258-pair-quality-blinded.json',packet);write(T/'review258-pair-quality-key-unopened.json',private)
write(T/'review258-pair-quality-input-freeze.json',{'created_at':datetime.now(timezone.utc).isoformat(),'packet_sha256':h((T/'review258-pair-quality-blinded.json').read_bytes()),'pairs':8,'new_model_calls':0,'prior_labels':'Final obligation labels already frozen before primary method key opened; no retrospective changes. This additional audit compares every complete pair and actual assembled briefs with method names hidden. Independent service exact snapshot/cost remains unobserved.'});print('All8pairs prepared, A/B method assignments withheld from independent quality reviewer.')
