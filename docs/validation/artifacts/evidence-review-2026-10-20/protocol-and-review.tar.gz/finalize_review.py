"""Freeze complete blind judgments, then bind the withheld assignment key."""
import argparse,hashlib,json,os
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['259-v2','258-v4']);a=p.parse_args();T=Path(__file__).resolve().parent;prefix='review'+a.phase;h=lambda b:hashlib.sha256(b).hexdigest()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def now():return datetime.now(timezone.utc).isoformat()
packet_path=T/('review259-v2-blinded-packet.json' if a.phase=='259-v2' else 'packing-fixtures-v4/blinded-review.json');packet={i['item_id']:i for i in json.loads(packet_path.read_text())};freeze=json.loads((T/(prefix+'-independent-freeze.json')).read_text());assert freeze['packet_sha256']==h(packet_path.read_bytes());slot=lambda r:(r['item_id'],r['obligation_id']);reviews={}
for who in ('R1','R2'):
 path=T/f'reviewers/{who}/{prefix}.json';assert h(path.read_bytes())==freeze['reviewer_sha256'][who];reviews[who]={slot(r):r for r in json.loads(path.read_text())}
assert set(reviews['R1'])==set(reviews['R2'])
differences={s for s in reviews['R1'] if reviews['R1'][s]['label']!=reviews['R2'][s]['label']};assert len(differences)==freeze['disagreements']
path=T/f'reviewers/R3/{prefix}-adjudication.json';adjudications=json.loads(path.read_text()) if differences else [];third={slot(r):r for r in adjudications};assert len(third)==len(adjudications)==len(differences) and set(third)==differences
labels=[]
for s in sorted(reviews['R1']):
 row=dict(third.get(s,reviews['R1'][s]));item=packet[s[0]];sources=item['review_context']['sources'] if a.phase=='259-v2' else item['sources'];assert row['answer_sha256']==item['answer_sha256'];assert row['label'] in ('used_correctly','ignored','misapplied','appropriately_deferred');assert row['note'].strip();assert not row['answer_quote'] or row['answer_quote'] in item['answer'];assert set(row['source_ids'])<={v['source_id'] for v in sources};row['reviewer']='R3 blind adjudication' if s in third else 'R1+R2';row['reviewer_notes']={who:reviews[who][s]['note'] for who in reviews};labels.append(row)
write(T/(prefix+'-final-labels.json'),labels)
blind={'frozen_at':now(),'labels_sha256':h((T/(prefix+'-final-labels.json')).read_bytes()),'labels':len(labels),'agreements':freeze['agreements'],'blind_adjudications':len(third),'assignment_key_opened':False,'packet_sha256':h(packet_path.read_bytes()),'limits':'Bounded independent model judgments, not human review, expertise qualification, S0 acceptance, default promotion or a statistical policy winner. Prior failed and ambiguous trials remain separate. Completion/schema status is separate from visible semantic content.'}
write(T/(prefix+'-final-blind-freeze.json'),blind)
# The complete review freeze is durable before any assignment-key read below.
key_path=T/('review259-v2-key-unopened/key.json' if a.phase=='259-v2' else 'packing-fixtures-v4/assignment-key-unopened/key.json');key=json.loads(key_path.read_text());assert set(key)==set(packet);opened=now()
if a.phase=='259-v2':
 from deepr.evals import correction_survival as cs
 root=T/'correction-survival-v2';before={str(p.relative_to(root)):h(p.read_bytes()) for p in root.rglob('*') if p.is_file()};policy=json.loads((T/'review259-v2-policy-freeze.json').read_text());run=cs.load_run(root,expected_recipe_sha256=policy['recipe_sha256']);bound=cs.bind_review_labels(run,key,labels);assert len(bound)==len(labels);report=cs.build_report(run,bound);write(T/(prefix+'-reviewed-report.json'),report);(T/(prefix+'-reviewed-report.md')).write_text(cs.render_report(report));attempts={x['attempt_id']:x for x in run['attempts']};trace=[]
 for row in labels:
  aid=key[row['item_id']];attempt=attempts[aid];trace.append({'attempt_id':aid,'case_id':attempt['case_id'],'arm':attempt['arm'],'obligation_id':row['obligation_id'],'label':row['label'],'note':row['note'],'answer_quote':row['answer_quote'],'source_ids':row['source_ids'],'stage_receipts':attempt['stage_receipts'][row['obligation_id']],'prompt_sha256':attempt['prompt_sha256'],'answer_sha256':attempt['answer_sha256']})
 write(T/(prefix+'-reviewed-trace.json'),trace);assert before=={str(p.relative_to(root)):h(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
 receipt={'key_opened_at':opened,'labels_frozen_before_key':True,'assignment_key_sha256':h(key_path.read_bytes()),'label_freeze_sha256':h((T/(prefix+'-final-blind-freeze.json')).read_bytes()),'scheduled_answers':run['scheduled_attempts'],'completed_answers':sum(x['status']=='completed' for x in run['attempts']),'failed_answers':sum(x['status']!='completed' for x in run['attempts']),'bound_labels':len(bound),'original_files_unchanged':len(before),'original_code_identity':run['code_identity'],'original_recipe_sha256':run['recipe_sha256'],'current_recipe_sha256':report['current_recipe_sha256'],'arms':{arm:r['stages']['answer'] for arm,r in report['arms'].items()},'acceptance_scope':'Artifact/review binding and terminal diagnostic accounting only; semantic interpretation and issue acceptance require inspection of the complete dated record, including negative findings and limitations.'}
 write(T/(prefix+'-acceptance-receipt.json'),receipt);print(json.dumps(receipt,indent=2))
else:
 pairs=defaultdict(dict)
 for iid,item in packet.items():
  info=key[iid];rows=[r for r in labels if r['item_id']==iid];pairs[info['pair']][info['arm']]={'item_id':iid,'status':item['status'],'answer_sha256':item.get('answer_sha256'),'json_object':item.get('json_object'),'position_count':item.get('position_count'),'labels':{r['obligation_id']:r['label'] for r in rows},'notes':{r['obligation_id']:r['note'] for r in rows}}
 assert len(pairs)==8 and all(set(pair)=={'old','current'} for pair in pairs.values());counts=Counter(item['status'] for item in packet.values());report={'key_opened_at':opened,'labels_frozen_before_key':True,'assignment_key_sha256':h(key_path.read_bytes()),'label_freeze_sha256':h((T/(prefix+'-final-blind-freeze.json')).read_bytes()),'scheduled_answers':16,'terminal_answers':len(packet),'statuses':dict(counts),'reviewed_obligations':len(labels),'pairs':dict(pairs),'accepted_clean_policy_contrast':None,'needs_material_supported_answer_review':True,'limits':'Same eight corrected development-case families, not held-out transfer. First flawed contrast and failed calibration remain separate. Equal output/context allowances are not equal token consumption. JSON object and completion status do not establish a production-valid or useful brief. No automatic semantic winner/default promotion.'};write(T/(prefix+'-reviewed-comparison.json'),report);print(json.dumps({'statuses':dict(counts),'reviewed_obligations':len(labels),'pairs':{name:{arm:{'status':row['status'],'labels':row['labels']} for arm,row in pair.items()} for name,pair in pairs.items()}},indent=2))
