"""Validate independent labels and freeze blind disagreement inputs."""
import argparse,copy,hashlib,json,os
from datetime import datetime,timezone
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['259-v2','258-v4']);a=p.parse_args();T=Path(__file__).resolve().parent;prefix='review'+a.phase
packet_path=T/('review259-v2-blinded-packet.json' if a.phase=='259-v2' else 'packing-fixtures-v4/blinded-review.json')
h=lambda b:hashlib.sha256(b).hexdigest()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
packet=json.loads(packet_path.read_text());expected={};by_id={x['item_id']:x for x in packet}
for item in packet:
 if 'answer_sha256' not in item:continue
 assert h(item['answer'].encode())==item['answer_sha256']
 obligations=item['review_context']['obligations'] if a.phase=='259-v2' else item['obligations']
 for obligation in obligations:expected[(item['item_id'],obligation['obligation_id'])]=(item,obligation)
assert len(expected)>0
reviews={}
for who in ('R1','R2'):
 path=T/f'reviewers/{who}/{prefix}.json';rows=json.loads(path.read_text());slots={(r['item_id'],r['obligation_id']):r for r in rows};assert len(rows)==len(slots)==len(expected) and set(slots)==set(expected)
 for slot,row in slots.items():
  item,_=expected[slot];sources=item['review_context']['sources'] if a.phase=='259-v2' else item['sources']
  assert row['answer_sha256']==item['answer_sha256'];assert row['label'] in ('used_correctly','ignored','misapplied','appropriately_deferred');assert row['reviewer']==who and row['note'].strip();assert not row['answer_quote'] or row['answer_quote'] in item['answer'];assert set(row['source_ids'])<={s['source_id'] for s in sources}
 reviews[who]=slots
slots=[slot for slot in sorted(expected) if reviews['R1'][slot]['label']!=reviews['R2'][slot]['label']];inputs=[]
for slot in slots:
 item,obligation=expected[slot];item=copy.deepcopy(item)
 if a.phase=='259-v2':item['obligations']=[slot[1]];item['review_context']['obligations']=[obligation]
 else:item['obligations']=[obligation]
 inputs.append(item)
write(T/(prefix+'-adjudication-inputs.json'),inputs)
write(T/(prefix+'-disagreements.json'),[{'item_id':slot[0],'obligation_id':slot[1],'reviews':{who:reviews[who][slot] for who in reviews}} for slot in slots])
freeze={'frozen_at':datetime.now(timezone.utc).isoformat(),'assignment_key_opened':False,'reviewable_items':sum('answer_sha256' in x for x in packet),'unreviewable_terminal_items':sum('answer_sha256' not in x for x in packet),'rows_per_reviewer':len(expected),'agreements':len(expected)-len(slots),'disagreements':len(slots),'packet_sha256':h(packet_path.read_bytes()),'reviewer_sha256':{who:h((T/f'reviewers/{who}/{prefix}.json').read_bytes()) for who in reviews},'adjudication_inputs_sha256':h((T/(prefix+'-adjudication-inputs.json')).read_bytes())}
write(T/(prefix+'-independent-freeze.json'),freeze);print(json.dumps(freeze,indent=2))
