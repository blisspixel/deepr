from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
T=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest()
base=json.loads((T/'calibration-inputs-v2.json').read_text());oldkey=json.loads((T/'calibration-key-v2.json').read_text())
replacements=[('Aster','Luma'),('aster','luma'),('January 10','January 12'),('June 12','May 14'),('800','600'),('max_attempts = 4','max_attempts = 3'),('four attempts','three attempts'),('12 hours','6 hours'),('12-hour','6-hour'),('25-second','20-second'),('25 seconds','20 seconds'),('180-second','120-second'),('180 seconds','120 seconds')]
inputs=[];key={}
for i,row in enumerate(base):
 text=json.dumps(row)
 for a,b in replacements:text=text.replace(a,b)
 r=json.loads(text);item=h(f'luma-control-round2-{i}'.encode())[:16];r['item_id']=item;r['answer_sha256']=h(r['answer'].encode())
 if i==5:
  r['question']='Which two backoff recommendations do the supplied documents report, and in what deployment scopes?'
  r['answer']='The hosted team reports a 20-second cap on its hosted clusters; self-hosted maintainers suggest 120 seconds after repeated load spikes. These are different deployment scopes and the documents do not resolve their disagreement.'
  r['obligations'][0]['description']='Report both documented values with their hosted/self-hosted scope and retain disagreement. This obligation asks what the documents say, not for a universally best setting.'
  r['answer_sha256']=h(r['answer'].encode())
 inputs.append(r);key[item]={'obligation_id':r['obligations'][0]['obligation_id'],'label':oldkey[row['item_id']]['label']}
text=(T/'review-instructions-v2.txt').read_text()+'\nScope clarification: the point being judged is the individual obligation, not the whole question. Reporting the two documented sides of a conflict with their scopes can fully satisfy an obligation to preserve those sides (used_correctly), even if the overall best decision is unresolved. Use appropriately_deferred when the obligation itself asks for a point the frozen sources cannot settle and the answer scopes that gap and identifies a relevant check. Do not turn known, correctly reported scoped observations into deferrals solely because another decision remains open. This clarifies the original rubric; it does not add evidence or change obligations.\n'
for name,payload in [('agent-calibration-inputs.json',inputs),('agent-calibration-key.json',key)]:
 p=T/name;assert not p.exists();p.write_text(json.dumps(payload,indent=2)+'\n')
p=T/'review-instructions-v3.txt';assert not p.exists();p.write_text(text)
(T/'agent-calibration-freeze.json').write_text(json.dumps({'frozen_at':datetime.now(timezone.utc).isoformat(),'inputs_sha256':h((T/'agent-calibration-inputs.json').read_bytes()),'key_sha256':h((T/'agent-calibration-key.json').read_bytes()),'instructions_sha256':h(p.read_bytes()),'pass':'16/16 exact predeclared labels and inspected semantic rationales; all preceding unsuccessful calibration retained. No labels from a prior round overwrite a later round.'},indent=2)+'\n')
print('Fresh Luma controls and obligation-level clarification frozen before independent calibration.')
