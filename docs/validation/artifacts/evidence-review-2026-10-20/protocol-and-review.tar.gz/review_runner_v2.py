"""Bounded, ledger-backed local review, with frozen calibration and blinded inputs."""
import argparse,asyncio,hashlib,json,os,re,time
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/home/pueo/Work/deepr');TASK=Path(__file__).resolve().parent
safe={k:v for k,v in os.environ.items() if k in ('PATH','HOME','LANG','LC_ALL')}
safe.update(PYTHON_DOTENV_DISABLED='1',DEEPR_ENV_FILE=str(TASK/'absent.env'),DEEPR_DATA_DIR=str(TASK/'runtime/data'),DEEPR_EXPERTS_PATH=str(TASK/'runtime/experts'),DEEPR_REPORTS_PATH=str(TASK/'runtime/reports'),DEEPR_COST_DATA_DIR=str(TASK/'runtime/costs'),DEEPR_QUEUE_DB_PATH=str(TASK/'runtime/queue.db'),DEEPR_BUDGET_FILE=str(TASK/'runtime/budget.json'),TMPDIR=str(TASK/'tmp'))
os.environ.clear();os.environ.update(safe);(TASK/'tmp').mkdir(exist_ok=True)
from filelock import FileLock
from deepr.experts.chat_backends import ExpertChatRequest
from deepr.experts.investigation.ollama_backend import NativeOllamaInvestigationBackend
from deepr.utils.atomic_io import atomic_write_json
from deepr.evals.correction_survival_cases import REVIEW_LABELS

protocol=json.loads((TASK/'review-protocol-v2.json').read_text());settings=protocol['judge']
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,payload):atomic_write_json(path,payload,fsync=True,overwrite=False)
assert sha((TASK/'review-instructions-v2.txt').read_bytes())==protocol['review_instructions_sha256']
assert sha((TASK/'calibration-inputs-v2.json').read_bytes())==protocol['calibration']['inputs_sha256']
assert sha((TASK/'calibration-key-v2.json').read_bytes())==protocol['calibration']['key_sha256']
client=NativeOllamaInvestigationBackend(model=settings['model'],timeout=settings['timeout_seconds'])
client.pinned_digest=settings['digest']

async def call(item_id,prompt,obligations,phase):
 started=time.perf_counter();calls=TASK/'calls';calls.mkdir(exist_ok=True)
 with FileLock(str(TASK/'call-budget.lock')):
  count=len(list(calls.glob('*.request.json')))
  if count>=protocol['local_generation_ceiling']:raise RuntimeError('frozen total local call ceiling reached')
  if (datetime.now(timezone.utc)-datetime.fromisoformat(protocol['created_at'])).total_seconds()>protocol['wall_ceiling_seconds']:raise RuntimeError('frozen wall ceiling reached')
  request_path=calls/f'{count+1:03d}.{phase}.{item_id}.request.json'
  request={'ordinal':count+1,'phase':phase,'item_id':item_id,'judge':settings,'system':(TASK/'review-instructions-v2.txt').read_text(),'user':prompt,'obligations':obligations,'created_at':datetime.now(timezone.utc).isoformat()}
  write(request_path,request)
 response_path=request_path.with_name(request_path.name.replace('.request.json','.response.json'))
 try:
  result=await client.complete(ExpertChatRequest(model=settings['model'],messages=[{'role':'system','content':request['system']},{'role':'user','content':prompt}],extra={k:settings[k] for k in ('num_ctx','max_tokens','temperature','think','seed')}|{'response_format':{'type':'json_object'}}),correlation_id=f'issue-completion:{phase}:{item_id}')
  raw=result.raw_response or {}
  response={'status':'returned','text':result.text,'stop_reason':result.stop_reason,'native_stop_reason':raw.get('done_reason'),'observed_digest':client.last_attested_digest,'tokens_input':raw.get('prompt_eval_count'),'tokens_output':raw.get('eval_count'),'elapsed_s':round(time.perf_counter()-started,3)}
  write(response_path,response)
  if client.last_attested_digest!=settings['digest']:raise ValueError('judge digest mismatch')
  if raw.get('done_reason')=='length' or result.stop_reason=='length':raise ValueError('judge output truncated')
  payload=json.loads(result.text);reviews=payload['reviews']
  assert isinstance(reviews,list) and len(reviews)==len(obligations)
  assert {r['obligation_id'] for r in reviews}==set(obligations)
  for r in reviews:
   assert r['label'] in REVIEW_LABELS and isinstance(r['reason'],str) and r['reason'].strip()
   assert isinstance(r['answer_quote'],str) and isinstance(r['source_ids'],list)
  return {'item_id':item_id,'request_sha256':sha(request_path.read_bytes()),'response_sha256':sha(response_path.read_bytes()),'reviews':reviews,'status':'valid'}
 except Exception as error:
  if not response_path.exists():write(response_path,{'status':'failed','error_type':type(error).__name__,'error':str(error),'elapsed_s':round(time.perf_counter()-started,3)})
  return {'item_id':item_id,'status':'failed','error_type':type(error).__name__,'error':str(error)}

async def calibration():
 out=TASK/'calibration-results-v2.json';assert not out.exists()
 items=json.loads((TASK/'calibration-inputs-v2.json').read_text());key=json.loads((TASK/'calibration-key-v2.json').read_text());results=[]
 for i,item in enumerate(items,1):
  row=await call(item['item_id'],json.dumps(item,ensure_ascii=True),[o['obligation_id'] for o in item['obligations']],'calibration')
  if row['status']=='valid':row['matches_predeclared_label']=row['reviews'][0]['label']==key[item['item_id']]['label']
  results.append(row);write(TASK/f'calibration-v2-{i:02d}.json',row)
  print(f'Calibration {i}/{len(items)}: {row["status"]}, matches={row.get("matches_predeclared_label")}',flush=True)
 write(out,{'protocol_sha256':sha((TASK/'review-protocol-v2.json').read_bytes()),'controls':len(items),'matched':sum(r.get('matches_predeclared_label',False) for r in results),'results':results,'manual_rationale_admission_required':True})

async def review259():
 admission=json.loads((TASK/'calibration-admission-v2.json').read_text())
 assert admission['admitted'] is True and admission['calibration_results_sha256']==sha((TASK/'calibration-results-v2.json').read_bytes())
 packet=ROOT/'.agent/correction-survival-2026-10-19/review-packet.md'
 assert sha(packet.read_bytes())==protocol['259']['packet_sha256']
 template=json.loads((ROOT/'.agent/correction-survival-2026-10-19/labels-template.json').read_text());expected={}
 for row in template:expected.setdefault(row['item_id'],[]).append(row)
 blocks=packet.read_text().split('\n## Item ')[1:];assert len(blocks)==36
 out=TASK/'review259-labels.json';assert not out.exists();labels=[];results=[]
 for i,block in enumerate(blocks,1):
  item_id,body=block.split('\n',1);item_id=item_id.strip();entries=expected[item_id]
  row=await call(item_id,'## Item '+block,[e['obligation_id'] for e in entries],'review259')
  results.append(row);write(TASK/f'review259-{i:02d}.json',row)
  if row['status']=='valid':
   for review in row['reviews']:
    entry=next(e for e in entries if e['obligation_id']==review['obligation_id'])
    labels.append({'item_id':item_id,'answer_sha256':entry['answer_sha256'],'obligation_id':review['obligation_id'],'label':review['label'],'reviewer':f'local:{settings["model"]}@{settings["digest"]}','note':review['reason'],'answer_quote':review['answer_quote'],'source_ids':review['source_ids']})
  print(f'Blinded review {i}/36: {row["status"]}',flush=True)
 write(out,labels)
 write(TASK/'review259-model-freeze.json',{'frozen_at':datetime.now(timezone.utc).isoformat(),'labels_sha256':sha(out.read_bytes()),'labels':len(labels),'scheduled_answers':36,'results':results,'assignment_key_opened':False,'manual_rationale_review_required':True})

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['calibration','review259']);args=p.parse_args()
 with FileLock(str(TASK/'runner.lock'),timeout=0):asyncio.run(calibration() if args.phase=='calibration' else review259())
