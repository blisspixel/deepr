# Correction survival diagnostic (correction-survival-v1)

- Model: local:qwen3.8:27b@aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813; paid calls: 0; distractor sources per world: 0
- Cases: full set; attempts: 36 of 36 scheduled; reviewed obligations: 0

## production
12 completed, 0 failed, 100568 prompt characters

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, presented 18 |
| retrieval | not_applicable 2, selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | unreviewed 20 |

## oracle_packet
12 completed, 0 failed, 33242 prompt characters

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, oracle_selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | unreviewed 20 |

## fresh_sources
12 completed, 0 failed, 45388 prompt characters

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, not_used_by_arm 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, provided 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | unreviewed 20 |

Historical isolation: 3 isolated, 0 leaked.

Mechanical stage receipts only. Answer use is unreviewed unless a bound label says otherwise. Mock answers establish transport and accounting, not answer quality.
