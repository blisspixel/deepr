"""Freeze blinded judgments before key access; inspect v1 with its retained implementation."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,sys

ROOT=Path('/home/pueo/Work/deepr');T=Path(__file__).resolve().parent
import deepr
from deepr.evals import correction_survival as cs
from deepr.evals.correction_survival_cases import CASE_SET_VERSION
assert Path(deepr.__file__).resolve().is_relative_to(ROOT/'.agent/reader-evidence/release43 installed')
assert CASE_SET_VERSION=='correction-survival-v1'
h=lambda b:hashlib.sha256(b).hexdigest()
def write(path,value):
 with path.open('x') as f:
  json.dump(value,f,indent=2);f.write('\n');f.flush()
  import os
  os.fsync(f.fileno())
freeze=json.loads((T/'review259-independent-freeze.json').read_text())
for who,sha in freeze['reviewer_sha256'].items():assert h((T/f'reviewers/{who}/review259.json').read_bytes())==sha
r1=json.loads((T/'reviewers/R1/review259.json').read_text());r2=json.loads((T/'reviewers/R2/review259.json').read_text());adjudicated=json.loads((T/'reviewers/R3/review259-adjudication.json').read_text())
slot=lambda r:(r['item_id'],r['obligation_id'])
a={slot(r):r for r in r1};b={slot(r):r for r in r2};c={slot(r):r for r in adjudicated}
assert set(a)==set(b) and len(a)==60
assert set(c)=={key for key in a if a[key]['label']!=b[key]['label']} and len(c)==3
labels=[]
for key in sorted(a):
 row=dict(c.get(key,a[key]));assert row['answer_sha256']==a[key]['answer_sha256']==b[key]['answer_sha256']
 row['reviewer']='R1+R2' if key not in c else 'R3 (independent blind adjudication)'
 row['reviewer_notes']={'R1':a[key]['note'],'R2':b[key]['note']}|({'R3':c[key]['note']} if key in c else {})
 labels.append(row)
path=T/'review259-final-labels.json';write(path,labels)
blind={'frozen_at':datetime.now(timezone.utc).isoformat(),'labels_sha256':h(path.read_bytes()),'labels':60,'agreements':57,'blind_adjudications':3,'assignment_key_opened':False,'fixture_audit_sha256':h((T/'reviewers/R3/fixture-audit.json').read_bytes()),'interpretation_audit_sha256':h((T/'reviewers/R3/fixture-interpretation-audit.json').read_bytes()),'limits':'V1 source/fixture contradictions retained. Labels are bounded model judgments, not a qualified answer rate or a causal estimate. Calibrated reviewers and audits do not accept S0.'}
write(T/'review259-final-blind-freeze.json',blind)
# First and only assignment-key access happens after the complete label freeze is durable.
key_path=ROOT/'.agent/correction-survival-2026-10-19/review-key-DO-NOT-OPEN-BEFORE-LABELS/key.json'
raw=json.loads(key_path.read_text());ids={r['item_id'] for r in labels}
candidates=[raw]+([v for v in raw.values() if isinstance(v,dict)] if isinstance(raw,dict) else [])
valid=[candidate for candidate in candidates if isinstance(candidate,dict) and set(candidate)==ids and all(isinstance(v,str) for v in candidate.values())]
assert len(valid)==1,'assignment key shape does not match frozen review IDs'
key=valid[0]
run_dir=ROOT/'.agent/correction-survival-2026-10-19/local-d0'
run=cs.load_run(run_dir,expected_recipe_sha256='9d909236d977157010192a2827d910d006b3140912693d5a8b711c0babbe06c8')
bound=cs.bind_review_labels(run,key,labels);assert len(bound)==60
report=cs.build_report(run,bound)
write(T/'review259-v1-reviewed-report.json',report)
(T/'review259-v1-reviewed-report.md').write_text(cs.render_report(report))
attempts={a['attempt_id']:a for a in run['attempts']};trace=[]
for label in labels:
 aid=key[label['item_id']];attempt=attempts[aid]
 trace.append({'attempt_id':aid,'case_id':attempt['case_id'],'arm':attempt['arm'],'obligation_id':label['obligation_id'],'label':label['label'],'reviewer':label['reviewer'],'note':label['note'],'answer_quote':label['answer_quote'],'source_ids':label['source_ids'],'stage_receipts':attempt['stage_receipts'][label['obligation_id']]})
write(T/'review259-v1-reviewed-trace.json',trace)
before=json.loads((T/'retained259-before-review.json').read_text());after={str(p.relative_to(run_dir)):h(p.read_bytes()) for p in run_dir.rglob('*') if p.is_file()};assert before==after
receipt={'label_freeze_sha256':h((T/'review259-final-blind-freeze.json').read_bytes()),'key_opened_at':datetime.now(timezone.utc).isoformat(),'labels_frozen_before_key':True,'assignment_key_sha256':h(key_path.read_bytes()),'bound_labels':len(bound),'reviewed_obligations':report['reviewed_obligations'],'scheduled_answers':report['scheduled_attempts'],'original_files_unchanged':len(before),'original_code_identity':report['code_identity'],'original_recipe_sha256':report['recipe_sha256'],'arms':{arm:row['stages']['answer'] for arm,row in report['arms'].items()},'v1_fixture_defects':'Known source/obligation and interpretation defects; do not interpret these counts as qualified model performance. New v2 measurement remains separate.'}
write(T/'review259-v1-acceptance-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
