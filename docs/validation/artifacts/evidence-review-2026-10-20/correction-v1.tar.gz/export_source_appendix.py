from dataclasses import asdict
from pathlib import Path
import hashlib,json
from deepr.evals.correction_survival import load_run
from deepr.evals.correction_survival_cases import CASES,world,case_set_sha256
from deepr.experts.corpus_store import content_hash
T=Path(__file__).resolve().parent;root=Path('/home/pueo/Work/deepr');retained=root/'.agent/correction-survival-2026-10-19/local-d0'
h=lambda b:hashlib.sha256(b).hexdigest()
run=load_run(retained,expected_recipe_sha256='9d909236d977157010192a2827d910d006b3140912693d5a8b711c0babbe06c8')
assert run['case_set_sha256']==case_set_sha256() and run['scheduled_attempts']==36
worlds={}
for wid in ('w1','w2','w3'):
 w=world(wid);sources=[]
 for s in w.sources:
  digest=content_hash(s.text);copies=list((retained/'worlds').glob(f'c*/{wid}/corpus/sources/{digest[:2]}/{digest}.md'))
  assert copies, (wid,s.source_id)
  for path in copies:
   assert path.read_text()==s.text,(path,'source bytes differ')
  sources.append(asdict(s)|{'corpus_content_sha256':digest,'retained_bytes_sha256':h(copies[0].read_bytes()),'retained_copies_verified':len(copies)})
 expected={x['corpus_content_sha256'] for x in sources}
 for corpus in (retained/'worlds').glob(f'c*/{wid}/corpus'):
  actual={p.stem for p in (corpus/'sources').glob('*/*.md')}
  assert actual==expected,(wid,'world source inventory differs')
 worlds[wid]={'cutoff':w.cutoff,'sources':sources}
payload={'kind':'correction-survival-frozen-review-sources-v1','case_set_sha256':run['case_set_sha256'],'original_run_sha256':h((retained/'run.json').read_bytes()),'original_recipe_sha256':run['recipe_sha256'],'worlds':worlds,'cases':[asdict(c) for c in CASES],'review_rule':'For each question use only its designated frozen world. Later-world evidence must not inform a historical answer. This appendix supplies original source bytes, not answer-method identities. Case obligations and sources are unchanged; flag any tension between them rather than silently resolving it.'}
p=T/'review259-frozen-sources.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2)+'\n')
before=json.loads((T/'retained259-before-review.json').read_text());after={str(p.relative_to(retained)):h(p.read_bytes()) for p in retained.rglob('*') if p.is_file()}
assert before==after
(T/'review259-source-appendix-receipt.json').write_text(json.dumps({'appendix_sha256':h(p.read_bytes()),'verified_worlds':3,'all_retained_source_copies_match_frozen_cases':True,'original_files_unchanged':len(before),'no_assignment_key_read':True},indent=2)+'\n')
print('Frozen source appendix exported: all original world inventories and source bytes verified; 96 retained files unchanged; no arm key read.')
