# Correction survival diagnostic (correction-survival-v1)

- Model: local:qwen3.8:27b@aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813; paid calls: 0; distractor sources per world: 0; configured finding routing: lexical
- Cases: full set; attempts: 36 of 36 scheduled; reviewed obligations: 60
- Recorded code: deepr 2.50.41; recorded recipe: 9d909236d977157010192a2827d910d006b3140912693d5a8b711c0babbe06c8
- Current recipe: 2ecd0a58d34adeea76720dc19ddd3dc2783524de33659371e8300d75ebf2eea8; recorded/current match: False (None means unknown).

## production
12 completed, 0 failed, 100568 prompt characters
Elapsed ms: answer 1326333.047, routing None, total attempt None (None means unknown).
Effective routes: {}; routing states: {}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, presented 18 |
| retrieval | not_applicable 2, selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | misapplied 1, used_correctly 19 |

## oracle_packet
12 completed, 0 failed, 33242 prompt characters
Elapsed ms: answer 1129131.89, routing None, total attempt None (None means unknown).
Effective routes: {}; routing states: {}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, oracle_selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | misapplied 2, used_correctly 18 |

## fresh_sources
12 completed, 0 failed, 45388 prompt characters
Elapsed ms: answer 1307297.414, routing None, total attempt None (None means unknown).
Effective routes: {}; routing states: {}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, not_used_by_arm 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, provided 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | ignored 1, misapplied 5, used_correctly 14 |

Historical isolation: 3 isolated, 0 leaked.

Mechanical stage receipts only. Answer use is unreviewed unless a bound label says otherwise. Mock answers establish transport and accounting, not answer quality. elapsed_ms is answer-only; total_elapsed_ms includes routing and packet assembly through the answer, excluding shared world/study/brief setup and artifact writes. Legacy routing/total timing is unknown.
