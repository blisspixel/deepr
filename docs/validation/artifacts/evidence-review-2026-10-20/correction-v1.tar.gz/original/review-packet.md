# Correction survival review packet (blinded)

Run: `local:qwen3.8:27b`, case set `correction-survival-v1`, 36 answers. Arms are hidden; each answer has an opaque id.

## How to review

For each obligation, judge only from the frozen world's sources and the answer text. used_correctly: the answer applies the obligation's evidence within its stated scope and explains it. ignored: the answer does not use the evidence where the question needs it. misapplied: the answer uses the evidence outside its scope, contradicts it, or uses knowledge the world did not contain. appropriately_deferred: the answer explicitly declines or scopes the point because the world cannot settle it, and says what would. Citation strings and matching words are not evidence of use.

Labels: used_correctly, ignored, misapplied, appropriately_deferred. Judge each obligation from the answer text and the case world only; the world sources are in `src/deepr/evals/correction_survival_cases.py`. Fill `labels-template.json` (one row per item and obligation, with your name as reviewer). Do not open the key folder until every label is saved.

## Item 0302a8ea2bcb8195

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> **Short Answer:**
> Retries are **conditionally safe** for payment jobs, but only if two specific conditions are met:
> 1.  **Idempotency keys are explicitly enabled** on the agent platform (especially critical for Windows agents in Tern 3.0+).
> 2.  **Total retry duration is capped below the payment provider’s deduplication window** (typically 24 hours).
> 
> If either condition fails, retries can result in duplicate charges.
> 
> ### Mechanisms & Conditions
> 
> **1. Idempotency Key Enforcement**
> The safety of retries relies on the worker discarding duplicate executions via idempotency keys.
> *   **Linux/Container Agents:** Keys are enabled by default. Retries are generally safe regarding duplicate execution.
> *   **Windows Agents (Tern 3.0+):** Keys are **disabled by default** due to the optional Windows key store. On these agents, a retry will execute side effects twice unless `idempotency_keys` is explicitly enabled or `max_retries` is set to 0.
> *   **Action:** Verify your agent platform. If using Windows, explicitly enable keys or disable retries for payment jobs.
> 
> **2. Provider Deduplication Windows**
> Even with idempotency keys, external payment providers only deduplicate requests within their own window (typically 24 hours).
> *   **Risk:** If the total time from the first attempt to the final retry exceeds the provider’s window, the provider treats the retry as a new transaction, causing a double charge.
> *   **Action:** Cap the total retry time (backoff + execution time) to be significantly less than the provider’s deduplication window. For example, if the window is 24 hours, ensure the maximum retry schedule completes well before 24 hours have elapsed since the initial request.
> 
> **3. Backoff Configuration**
> *   **Default Recommendation:** The Tern manual suggests `max_retries = 5` for ordinary jobs.
> *   **Backoff Cap:** The vendor blog recommends capping exponential backoff at 60 seconds to prevent idle queues during short outages. However, a maintainer comment on issue #982 suggests a 300-second cap for self-hosted clusters, noting that a 60-second cap amplified load during a regional outage. This thread is open, and no benchmark settles the difference.
> *   **Action:** For payment jobs, prioritize avoiding duplicate charges over queue efficiency. A longer backoff cap (e.g., 300s) may be safer to reduce the chance of hitting provider rate limits or transient failures that lead to retries, but this must be balanced against the total retry time constraint.
> 
> ### Alternatives & Verification
> 
> *   **Alternative 1: Disable Retries for Payment Jobs**
>     Set `max_retries = 0` for jobs that call external payment providers. This eliminates the risk of duplicate charges from retries but requires manual intervention or a separate reconciliation process to handle failed payments.
> *   **Alternative 2: Explicit Idempotency + Time Cap**
>     Enable idempotency keys explicitly and configure the retry schedule so that the last possible retry occurs well before the provider’s deduplication window expires. This is the most robust approach for automated processing.
> 
> **Verification Steps:**
> 1.  Check your agent platform (Windows vs. Linux/Container) and confirm idempotency key status.
> 2.  Review your payment provider’s documentation for their specific deduplication window.
> 3.  Calculate the worst-case total retry time (sum of all backoff intervals + execution time) and ensure it is less than the provider’s window.
> 4.  Monitor for duplicate charge reports to validate the configuration.
> 
> ### Uncertainty & Omissions
> 
> *   **Backoff Cap:** The optimal backoff cap (60s vs. 300s) is unresolved in the provided sources. The 60s recommendation is based on hosted clusters only, while the 300s suggestion is from an open issue for self-hosted clusters. No benchmark data is provided to settle this.
> *   **Provider Windows:** The "typically 24 hours" window is a general statement. Specific providers may have different windows (e.g., 1 hour, 7 days). You must verify the exact window for your specific payment provider.
> *   **Scope:** This analysis is based on Tern 3.0 documentation and forum posts. It does not cover other job schedulers or payment providers not mentioned in the sources.

## Item 16a16d74aceba7fd

**Question (w3):** What backoff cap should we configure for Tern?

**Obligations:**
- `vendor-view` (retain_conflict): Vendor: 60 seconds, hosted.
- `maintainer-view` (retain_conflict): Maintainer: 300 seconds, self-hosted; open.

**Answer:**

> There is no single correct backoff cap for Tern; the appropriate value depends entirely on your deployment topology (hosted vs. self-hosted) and your specific outage history. The available evidence presents a direct conflict between two sources, with no independent benchmark to resolve it.
> 
> **The Conflict**
> *   **Vendor Recommendation (60 seconds):** The vendor engineering blog recommends a 60-second cap, arguing that longer caps leave queues idle during short outages. **Crucially, this recommendation is explicitly limited to "hosted clusters only."**
> *   **Maintainer Recommendation (300 seconds):** The maintainer of the Tern project suggests a 300-second cap specifically for **self-hosted clusters**. This suggestion stems from an incident where a 60-second cap "amplified load" during a regional outage. However, the maintainer notes that the discussion thread remains open and **no benchmark settles the difference.**
> 
> **Decision Framework**
> 1.  **If you are using the Vendor’s Hosted Service:**
>     *   **Use 60 seconds.** This aligns with the vendor’s measured performance on their infrastructure. Their primary concern is minimizing idle time during short, frequent outages typical of managed services.
> 2.  **If you are Self-Hosted:**
>     *   **Use 300 seconds as a starting point.** The maintainer’s warning about load amplification during outages is a significant risk factor for self-hosted environments, where you lack the vendor’s internal load-balancing or redundancy. A higher cap prevents your clients from hammering a struggling backend.
>     *   **However, treat this as a hypothesis, not a fact.** The maintainer explicitly states there is no benchmark to prove 300 seconds is optimal. It is a conservative suggestion based on a single incident.
> 
> **Verification & Action Plan**
> Since neither source provides a universally applicable benchmark, you must verify the setting in your own environment:
> 
> 1.  **Baseline Your Outage Profile:** Determine the average duration of your typical outages. If your outages are consistently shorter than 60 seconds, a 300-second cap will cause significant idle time. If outages frequently exceed 60 seconds, the 60-second cap may cause excessive retry storms.
> 2.  **Load Test Both Values:**
>     *   Simulate a backend outage of 30 seconds, 90 seconds, and 180 seconds.
>     *   Measure the **retry rate** (requests per second) and **queue depth** for both 60s and 300s caps.
>     *   **Success Criterion:** The cap that minimizes backend load during the outage while keeping client-side latency acceptable for your use case.
> 3.  **Monitor Post-Deployment:**
>     *   Track `retry_attempts` and `backoff_wait_time` metrics.
>     *   If you see a spike in retries during minor network blips, lower the cap.
>     *   If you see backend saturation during outages, raise the cap.
> 
> **Material Uncertainty**
> The most significant uncertainty is the lack of a definitive benchmark. The maintainer’s 300-second suggestion is anecdotal (based on one outage) and unverified. The vendor’s 60-second recommendation is measured but restricted to their hosted environment. **You cannot assume either value is correct for your specific infrastructure without local testing.**
> 
> **Omission**
> No information was provided regarding Tern’s specific backoff algorithm (e.g., whether it is pure exponential, jittered, or linear). This affects how the cap interacts with the base delay. Verify Tern’s documentation for the exact backoff formula to ensure the cap is applied as expected.

## Item 1a3617e7d4bb00bb

**Question (w3):** At what queue depth should the Tern alarm trigger?

**Obligations:**
- `alarm` (preserve): 1,000 pending jobs, unchanged since the v2 manual.

**Answer:**

> **Tern Queue Alarm Threshold**
> 
> The Tern alarm should trigger at **1,000 pending jobs**.
> 
> **Mechanism and Rationale**
> According to the *Tern 2 operations manual* (Section 9: Monitoring), this threshold is calibrated to the "reference cluster." The manual states that below 1,000 pending jobs, the backlog clears within one scheduling interval. Therefore, exceeding this depth indicates that the system is failing to process jobs within the expected timeframe, warranting an alert.
> 
> **Conditions and Scope**
> *   **Platform Specificity:** This threshold is explicitly tied to the "reference cluster." It may not be appropriate for clusters with different hardware, worker counts, or job complexity profiles.
> *   **Version:** This applies to *Tern 2*.
> *   **Context:** This is a monitoring threshold, distinct from retry logic (Section 7), which recommends `max_retries = 5` for ordinary jobs using idempotency keys.
> 
> **Verification and Uncertainty**
> *   **Source:** The figure is drawn directly from the retained passage in the *Tern 2 operations manual* (Section 9).
> *   **Limitation:** This is stored research only; no live check was performed to verify if the current deployment environment matches the "reference cluster" specifications. If your cluster deviates significantly from the reference configuration (e.g., fewer workers, slower I/O), the 1,000-job threshold may trigger too late or too early.
> *   **Omission:** The manual does not provide a formula for adjusting this threshold based on cluster size or job type. You must validate this value against your specific cluster’s historical backlog behavior.
> 
> **Actionable Recommendation**
> 1.  **Default:** Set the alarm to 1,000 pending jobs if your environment matches the reference cluster.
> 2.  **Validate:** Monitor your cluster’s actual backlog clearance time. If backlogs consistently exceed 1,000 jobs without clearing within one scheduling interval, the threshold is likely correct. If backlogs clear quickly at 1,000 jobs, consider lowering the threshold to catch degradation earlier.
> 3.  **Do Not Assume:** Do not apply this threshold blindly to non-reference clusters without testing.

## Item 1fddf74b7cb40193

**Question (w2):** We run Tern 3.0 agents on Windows. Is max_retries = 5 still safe for jobs with side effects?

**Obligations:**
- `use-correction` (use): Keys are off by default on 3.0 Windows agents.
- `keep-mechanism` (preserve): Keys are what make retries safe.
- `scope-linux` (preserve): Linux and container agents are unaffected.

**Answer:**

> **No, `max_retries = 5` is not safe for jobs with side effects on Tern 3.0 Windows agents by default.**
> 
> **Mechanism**
> In Tern 2, retries were considered safe across all platforms because idempotency keys were enabled by default. These keys allowed the worker to discard duplicate executions, preventing side effects from running twice. However, the Tern 3.0 release notes introduce a breaking change specifically for Windows agents: idempotency keys are now **disabled by default** because the Windows key store is optional.
> 
> **Condition for Safety**
> On a Tern 3.0 Windows agent without idempotency keys enabled, a retry can execute a job's side effects twice. Therefore, the safety of `max_retries = 5` depends entirely on whether idempotency keys are explicitly enabled.
> 
> **Actionable Steps**
> To safely use `max_retries = 5` for jobs with side effects on your Windows agents, you must choose one of the following:
> 1.  **Enable idempotency keys explicitly:** Configure `idempotency_keys` to be enabled in your agent settings. This restores the duplicate-discard mechanism that makes retries safe.
> 2.  **Set `max_retries = 0`:** If you cannot or do not want to enable idempotency keys, you must disable retries for jobs with side effects to prevent duplicate execution.
> 
> **Verification**
> *   **Source:** Tern 3.0 release notes (docs.tern.example/releases) explicitly state: "On a Windows agent without keys, a retry can execute a job's side effects twice. Either enable idempotency_keys explicitly or set max_retries = 0 for jobs with side effects."
> *   **Contrast:** The Tern 2 operations manual recommended `max_retries = 5` based on keys being enabled by default on *every* platform. This assumption is no longer valid for Windows in Tern 3.0.
> *   **Dissent:** An unsourced forum post claims retries are "always unsafe" and should be turned off everywhere. This is a generalization without version or platform specifics and does not account for the idempotency key mechanism that makes retries safe when properly configured. It is not a valid basis for changing your configuration beyond the documented breaking change.
> 
> **Uncertainty**
> The provided materials do not specify if other platforms (Linux, containers) have changed their defaults in later releases beyond 3.0, but the 3.0 notes confirm Linux and container agents remain unchanged with keys enabled. The safety of `max_retries = 5` on Windows is strictly conditional on the explicit enabling of idempotency keys.

## Item 2b9896559b6014cc

**Question (w3):** On Tern 2 Windows agents, are idempotency keys on by default?

**Obligations:**
- `v2-default` (use): Yes: the change applies to 3.0 only.
- `v3-scope` (preserve): The 3.0 change does not apply to v2.

**Answer:**

> **Yes, idempotency keys are on by default on Tern 2 Windows agents.**
> 
> According to the Tern 2 operations manual, idempotency keys are enabled by default on every agent platform, including Windows. This design ensures that retries are safe, as the worker discards duplicate executions using these keys.
> 
> **Important Distinction for Tern 3.0**
> It is critical to note that this default behavior **changed in Tern 3.0**. The Tern 3.0 release notes explicitly state a breaking change: idempotency keys are **disabled by default** on Windows agents in version 3.0 because the Windows key store is optional. If you are running Tern 3.0 on Windows, you must either explicitly enable `idempotency_keys` or set `max_retries = 0` for jobs with side effects to prevent duplicate execution.
> 
> **Verification and Context**
> *   **Source for Tern 2:** The Tern 2 operations manual (Section 7) confirms keys are enabled by default on all platforms.
> *   **Source for Tern 3.0:** The Tern 3.0 release notes confirm the change to disabled-by-default on Windows.
> *   **Uncertainty:** The provided materials do not specify the exact version cutoff or migration timeline between Tern 2 and Tern 3.0. Ensure you verify your specific Tern version to determine which default applies. If you are on Tern 2, keys are on. If you are on Tern 3.0, they are off on Windows.
> 
> **Actionable Recommendation**
> 1.  **Check your Tern version.**
> 2.  **If Tern 2:** No action needed; keys are on by default.
> 3.  **If Tern 3.0 (Windows):** Explicitly enable `idempotency_keys` in your agent configuration or set `max_retries = 0` for any job with side effects (e.g., payments, external API calls) to avoid duplicate executions.

## Item 331431e15b7ffd84

**Question (w2):** A forum post says retries are always unsafe. Should we disable retries on our Linux Tern 3.0 agents?

**Obligations:**
- `keep-advice` (preserve): Linux keeps keys on; retries stay safe.
- `weigh-forum` (use): The post gives no version, platform or measurement.

**Answer:**

> No. Do not disable retries on your Linux Tern 3.0 agents based on that forum post. The claim that retries are "always unsafe" is an unsourced generalization that contradicts the specific documentation for your platform.
> 
> **Mechanism and Platform Specifics**
> Retries in Tern are safe when idempotency keys are enabled. The worker uses these keys to discard duplicate executions, preventing side effects from running twice. According to the Tern 3.0 release notes, idempotency keys remain **enabled by default** on Linux and container agents. The breaking change in version 3.0 applies only to Windows agents, where keys are disabled by default because the Windows key store is optional.
> 
> Since you are using Linux agents:
> 1.  Idempotency keys are active by default.
> 2.  Retries are therefore safe for jobs with side effects.
> 3.  Disabling retries (`max_retries = 0`) would unnecessarily reduce fault tolerance without addressing a safety risk.
> 
> **Disagreement with the Forum Post**
> The forum post asserts that retries are unsafe in "every job scheduler." This is a **DISAGREEMENT** with the documented behavior of Tern on Linux. The post provides no version, platform, or measurement to support its claim. The Tern 3.0 release notes explicitly state that Linux agents are unchanged and keep keys enabled, directly refuting the idea that retries are inherently unsafe on your specific configuration.
> 
> **Actionable Recommendation**
> *   **Keep retries enabled:** Maintain the default or recommended `max_retries` setting (Tern 2 docs recommend 5 for ordinary jobs; verify if this changed in 3.0, though the release notes only flag the key default change).
> *   **Verify key status:** Confirm that `idempotency_keys` is not explicitly set to `false` in your Linux agent configuration. If it is enabled (the default), retries are safe.
> *   **Ignore the forum advice for Linux:** The advice to "turn them off everywhere" is only relevant to Windows 3.0 agents where keys are off by default.
> 
> **Uncertainty**
> The primary uncertainty is whether your specific Linux agent configuration has manually disabled idempotency keys. If you have explicitly set `idempotency_keys = false`, then retries *would* be unsafe, and you should either re-enable keys or set `max_retries = 0`. However, based on the default behavior described in the release notes, no action is required.

## Item 3399365fbffa714f

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> **Short Answer**
> Retries for payment jobs are **conditionally safe**. They are safe only if two specific conditions are met:
> 1.  **Idempotency keys are enabled** on the specific agent platform.
> 2.  **Total retry duration** (including backoff) remains **below the payment provider’s deduplication window** (typically 24 hours).
> 
> If either condition fails, retries risk double-charging the customer.
> 
> ### Mechanisms and Conditions
> 
> **1. Idempotency Keys and Platform Defaults**
> The Tern 2 operations manual states that retries are safe because every job carries an idempotency key, which allows the worker to discard duplicate executions. However, this safety mechanism depends on the platform:
> *   **Linux and Container Agents:** Idempotency keys are enabled by default in both Tern 2 and Tern 3.0. Retries are safe here, provided the provider window constraint is met.
> *   **Windows Agents (Tern 3.0):** A breaking change in Tern 3.0 disables idempotency keys by default on Windows agents because the Windows key store is optional. On these agents, retries **will** execute side effects twice (e.g., double charge) unless you explicitly enable `idempotency_keys` or set `max_retries = 0`.
> 
> **2. Provider Deduplication Windows**
> Even with idempotency keys enabled, the worker only prevents *internal* duplicate executions. It does not prevent the *payment provider* from processing the charge if the retry occurs after the provider’s deduplication window has expired.
> *   **Constraint:** Payment providers typically deduplicate requests only within a 24-hour window.
> *   **Risk:** If the total time from the initial failure to the final retry exceeds this window (e.g., due to long exponential backoff or queue delays), the provider may treat the retry as a new, valid transaction, resulting in a double charge.
> *   **Requirement:** You must cap the total retry time (max_retries × backoff interval) to be strictly less than the provider’s deduplication window.
> 
> ### Verification and Configuration
> 
> To ensure safety, verify the following:
> 
> 1.  **Check Agent Platform:**
>     *   If using **Tern 3.0 on Windows**, confirm that `idempotency_keys` is explicitly set to `true` in your job configuration. If you cannot guarantee this, set `max_retries = 0` for payment jobs.
>     *   If using **Linux/Containers**, keys are on by default, but verify your specific deployment configuration to ensure no local overrides have disabled them.
> 
> 2.  **Calculate Retry Window:**
>     *   Determine your provider’s deduplication window (e.g., 24 hours).
>     *   Calculate the worst-case total retry time: `max_retries` × `max_backoff_interval` + `queue_delay`.
>     *   Ensure this total is significantly less than the provider’s window. For example, if the window is 24 hours, ensure your retry strategy completes within 12–18 hours to allow for buffer.
> 
> 3.  **Monitor Queue Depth:**
>     *   The Tern 2 manual recommends triggering a queue-depth alarm at **1,000 pending jobs**. High queue depths can delay retries, pushing them past the provider’s deduplication window. Monitor this metric to ensure backlogs do not cause retries to land outside the safe window.
> 
> ### Dissent and Uncertainty
> 
> *   **Dissent:** An unsourced forum post claims retries are "always unsafe" and should be disabled everywhere. This is a broad generalization without version or platform context. The documented evidence shows retries are safe *when* idempotency keys are active and the provider window is respected. The forum post does not account for these mechanisms.
> *   **Uncertainty:**
>     *   The exact deduplication window varies by payment provider. The "24 hours" figure is a typical value from the integration notes, but you must verify your specific provider’s documentation.
>     *   The study notes that 4 positions state a stance with no likelihood, meaning they are assertions rather than scored judgments. The safety of retries is conditional, not absolute.
>     *   No live check was performed. The behavior described is based on Tern 2 and 3.0 documentation. If you are using a different scheduler or a newer version of Tern, these defaults may change.
> 
> ### Actionable Steps
> 
> 1.  **For Windows (Tern 3.0):** Explicitly set `idempotency_keys: true` for payment jobs, or set `max_retries: 0`.
> 2.  **For All Platforms:** Configure `max_retries` and backoff so that the total retry duration is < 50% of your provider’s deduplication window (e.g., < 12 hours if the window is 24 hours).
> 3.  **Monitor:** Set an alarm for queue depth > 1,000 to prevent delays from pushing retries out of the safe window.
> 4.  **Verify:** Confirm your payment provider’s deduplication window and test the retry behavior in a sandbox environment with a known failure scenario.

## Item 40cd1ac5571a287e

**Question (w2):** Since Tern 3.0 turned idempotency keys off on every platform, should we turn retries off on Linux too?

**Obligations:**
- `correct-premise` (correct_premise): Only Windows agents changed.

**Answer:**

> No. The premise that Tern 3.0 turned idempotency keys off on every platform is incorrect.
> 
> According to the stored research finding [change-1] and the retained passage from the Tern 3.0 release notes, the breaking change applies **only to the Windows agent**. The documentation explicitly states: "Linux and container agents are unchanged and keep keys enabled."
> 
> Therefore, on Linux:
> 1.  **Idempotency keys remain enabled by default.**
> 2.  Retries are safe to keep enabled for jobs with side effects, as the idempotency mechanism will prevent duplicate execution.
> 3.  Turning off retries (`max_retries = 0`) on Linux is unnecessary and would reduce system resilience without addressing a non-existent vulnerability.
> 
> **Actionable Guidance:**
> *   **Do not** disable retries on Linux.
> *   **Verify** that your Linux agents are running Tern 3.0 and that `idempotency_keys` is not explicitly disabled in your configuration (though it defaults to enabled).
> *   **Review Windows agents:** If you have Windows agents, you must either explicitly enable `idempotency_keys` or set `max_retries = 0` for jobs with side effects to avoid double-execution.
> 
> **Uncertainty:**
> This answer relies solely on the provided stored research. No live check was performed to confirm your specific deployment configuration. If your Linux agents have been manually configured to disable idempotency keys, the risk profile would change, but that would be a local configuration issue, not a default behavior of Tern 3.0.

## Item 52431d2039d2d984

**Question (w3):** What retry settings should we use for Tern agents on macOS?

**Obligations:**
- `defer-macos` (defer): No source covers macOS agents; say so and scope the answer.

**Answer:**

> **Recommendation**
> For Tern agents on macOS, use **`max_retries = 5`** with a **backoff cap of 60 seconds**.
> 
> **Mechanisms and Conditions**
> 1.  **Idempotency Safety:** The Tern 2 operations manual states that idempotency keys are enabled by default on "every agent platform," allowing safe retries because duplicate executions are discarded. The Tern 3.0 release notes explicitly state that Linux and container agents are unchanged and keep keys enabled. While macOS is not explicitly listed in the 3.0 breaking change note (which only flags Windows), it is not flagged as a platform where keys are disabled. Therefore, the default safe retry behavior applies.
> 2.  **Backoff Cap:** The vendor engineering blog recommends capping exponential backoff at 60 seconds to prevent queues from idling during short outages. A maintainer comment on GitHub issue 982 suggests 300 seconds for self-hosted clusters to avoid amplifying load during regional outages. However, the 300-second suggestion is unverified (thread remains open, no benchmark) and specific to self-hosted clusters. The 60-second cap is measured on hosted clusters. For a general macOS deployment, 60 seconds is the documented, measured standard.
> 3.  **Payment Jobs Exception:** If the jobs call external payment providers, you must cap total retry time below the provider’s deduplication window (typically 24 hours). With `max_retries = 5` and a 60-second cap, the total retry time is well under 24 hours, so this setting is safe for payment jobs.
> 
> **Alternatives**
> *   **Self-Hosted Clusters:** If you are running a self-hosted cluster and have experienced load amplification during outages, consider testing a 300-second backoff cap, but note this is an unverified suggestion from an open issue.
> *   **Jobs with Side Effects (if idempotency is disabled):** If you have explicitly disabled idempotency keys (not recommended on macOS), you must set `max_retries = 0` for jobs with side effects to prevent duplicate execution.
> 
> **Verification**
> *   **Idempotency:** Confirmed by Tern 2 manual (default enabled) and Tern 3.0 release notes (Linux/container unchanged; Windows is the only platform flagged for disabled keys).
> *   **Backoff Cap:** 60 seconds is supported by vendor blog measurements. 300 seconds is a dissenting, unverified suggestion from a maintainer.
> *   **Payment Safety:** Confirmed by integration notes that provider deduplication windows are typically 24 hours, which is longer than the total retry time with the recommended settings.
> 
> **Uncertainty**
> The Tern 3.0 release notes do not explicitly mention macOS, only Windows, Linux, and containers. It is assumed macOS behaves like Linux/containers (idempotency enabled) because it is not listed as a breaking change platform. If your macOS agent uses a Windows-like key store implementation, verify idempotency keys are enabled.

## Item 5c21aadb3a548cd8

**Question (w1):** As of January 2026, what did the Tern documentation recommend for max_retries on Windows agents?

**Obligations:**
- `answer-from-w1` (use): Keys on by default everywhere; max_retries = 5.
- `no-later-knowledge` (isolate): No 3.0 or later source may inform the answer.

**Answer:**

> Based on the provided stored research from the "Tern 2 operations manual," the documentation does **not** specify a distinct recommendation for `max_retries` on Windows agents.
> 
> The supplied excerpt (Section 7) states:
> > "We recommend max_retries = 5 for ordinary jobs."
> 
> It further asserts that this recommendation is safe because "idempotency keys are enabled by default on **every** agent platform." The text explicitly claims platform-agnostic safety, implying that the `max_retries = 5` recommendation applies universally, including to Windows agents, without listing Windows as a separate case or exception.
> 
> **Key Constraints and Uncertainties:**
> 1.  **Source Scope:** The evidence is a bounded excerpt from a specific manual version ("Tern 2"). It does not confirm if this is the latest documentation as of January 2026, nor does it confirm if "Tern 2" is the current version in use.
> 2.  **Platform Specificity:** The claim that idempotency keys are on by default on *every* platform is a strong assertion by the source. If Windows agents in your environment have idempotency keys disabled (contrary to the manual's claim), the safety of `max_retries = 5` would be compromised, as duplicate executions would not be discarded.
> 3.  **No Dissent Recorded:** The single contributor’s position is that `max_retries = 5` is safe due to default idempotency. No dissenting view or platform-specific override for Windows is present in the supplied data.
> 
> **Conclusion:**
> According to the provided Tern 2 documentation excerpt, the recommended value for `max_retries` is **5**, with no specific differentiation for Windows agents. The documentation asserts this is safe on all platforms due to default idempotency keys. Verify that idempotency keys are indeed enabled on your specific Windows agent instances, as the safety of this retry count depends entirely on that condition.

## Item 602d33e04e59d78c

**Question (w3):** At what queue depth should the Tern alarm trigger?

**Obligations:**
- `alarm` (preserve): 1,000 pending jobs, unchanged since the v2 manual.

**Answer:**

> **1,000 pending jobs.**
> 
> According to the Tern 2 operations manual (Section 9), the queue-depth alarm should trigger at **1,000 pending jobs**. The manual states that below this threshold, the backlog clears within one scheduling interval on the reference cluster. This recommendation is explicitly noted as applying to the "reference cluster," implying that the optimal threshold may vary based on cluster size, job duration, and processing capacity.
> 
> **Verification and Context:**
> *   **Source:** The value is drawn directly from the retained passage in the Tern 2 operations manual (`docs.tern.example`).
> *   **Scope:** The manual does not provide a formula for adjusting this number for non-reference clusters. It is a static recommendation for the specific environment tested by the authors.
> *   **Relevance to Other Settings:** The stored research includes unresolved dissent regarding backoff caps (60s vs 300s) and idempotency key defaults on Windows (Tern 3.0), but these do not alter the monitoring threshold. The Tern 3.0 release notes explicitly state that "Monitoring defaults are unchanged in this release," confirming that the 1,000-job threshold remains the default recommendation even in the newer version, despite changes to retry safety on Windows agents.
> 
> **Uncertainty:**
> The primary uncertainty is that the 1,000-job threshold is calibrated for a specific "reference cluster." If your deployment has significantly different worker counts, job complexity, or scheduling intervals, this threshold may be too high (leading to delayed alerts) or too low (causing alert fatigue). The provided sources do not offer a method to scale this value dynamically.

## Item 6366ae19ad0d3c09

**Question (w3):** On Tern 2 Windows agents, are idempotency keys on by default?

**Obligations:**
- `v2-default` (use): Yes: the change applies to 3.0 only.
- `v3-scope` (preserve): The 3.0 change does not apply to v2.

**Answer:**

> **Yes.** On Tern 2 Windows agents, idempotency keys are enabled by default.
> 
> According to the *Tern 2 operations manual* (Section 7), "idempotency keys are enabled by default on every agent platform." This includes Windows, Linux, and container agents. The manual explicitly states that this default configuration makes retries safe because the worker discards duplicate executions using the key.
> 
> **Important Distinction for Tern 3.0:**
> If you are upgrading to or running **Tern 3.0**, this default changes for Windows agents only. The *Tern 3.0 release notes* identify a breaking change: "on the Windows agent, idempotency keys are now disabled by default because the Windows key store is optional." Linux and container agents remain unchanged in 3.0 and keep keys enabled.
> 
> **Verification and Action:**
> 1.  **Confirm Version:** Verify your agent version. If it is 2.x, keys are on by default. If it is 3.0+, keys are off by default on Windows.
> 2.  **Check Configuration:** Regardless of version, explicitly verify the `idempotency_keys` setting in your agent configuration file to ensure it is set to `true` if you rely on retry safety.
> 3.  **Retry Safety:** If keys are enabled, the manual recommends `max_retries = 5` for ordinary jobs. If keys are disabled (e.g., Tern 3.0 Windows default), you must either enable `idempotency_keys` explicitly or set `max_retries = 0` for any job with side effects to prevent duplicate execution.
> 
> **Uncertainty:**
> The provided sources are static documentation excerpts. No live check was performed to confirm the specific configuration of your current deployment. Additionally, the sources do not specify if any intermediate patch releases between 2.0 and 3.0 altered this default, though the 3.0 notes frame the change as a breaking update from the previous state.

## Item 78656cf0ad4513f6

**Question (w1):** As of January 2026, what did the Tern documentation recommend for max_retries on Windows agents?

**Obligations:**
- `answer-from-w1` (use): Keys on by default everywhere; max_retries = 5.
- `no-later-knowledge` (isolate): No 3.0 or later source may inform the answer.

**Answer:**

> The provided documentation excerpt does not specify a recommendation for `max_retries` on Windows agents.
> 
> The text states: "We recommend max_retries = 5 for ordinary jobs." It further notes that idempotency keys are enabled by default on "every agent platform," implying the recommendation applies broadly. However, it does not explicitly distinguish between operating systems or provide a specific value for Windows.
> 
> **Uncertainty:** The document does not contain platform-specific retry configurations. The general recommendation of 5 retries applies to "ordinary jobs" across all platforms mentioned, but no Windows-specific override or distinct value is provided in the supplied text.

## Item 870814826d9ed5a8

**Question (w2):** Since Tern 3.0 turned idempotency keys off on every platform, should we turn retries off on Linux too?

**Obligations:**
- `correct-premise` (correct_premise): Only Windows agents changed.

**Answer:**

> No. The premise that Tern 3.0 disabled idempotency keys on every platform is factually incorrect based on the provided release notes.
> 
> **Correction of Premise**
> The Tern 3.0 release notes explicitly state that the breaking change regarding disabled idempotency keys applies **only to the Windows agent**. The notes specify: "Linux and container agents are unchanged and keep keys enabled." Therefore, on Linux, idempotency keys remain enabled by default.
> 
> **Mechanism and Safety on Linux**
> Because idempotency keys are still active on Linux agents, the safety mechanism for retries described in the Tern 2 operations manual remains intact. The manual explains that retries are safe because "every job carries an idempotency key... so the worker discards a duplicate execution." Since this condition holds true for Linux in Tern 3.0, turning off retries is unnecessary and would reduce system resilience without addressing a non-existent safety gap.
> 
> **Recommendation**
> 1.  **Keep Retries Enabled on Linux:** Maintain the recommended `max_retries = 5` for ordinary jobs, as the underlying safety mechanism (idempotency keys) is still functional.
> 2.  **Verify Windows Configuration:** If you are concerned about duplicate side effects, focus your audit on Windows agents. For Windows jobs with side effects, you must either explicitly enable `idempotency_keys` or set `max_retries = 0`, as per the release notes.
> 3.  **Ignore Forum Claim:** The forum post claiming "retries are always unsafe in every job scheduler" is unsourced, lacks version/platform specificity, and contradicts the documented behavior of Tern. It should not inform your configuration decisions.
> 
> **Uncertainty**
> This analysis relies solely on the provided stored documents. No live system check was performed to confirm that your specific Linux agents have not been manually configured to disable idempotency keys. You should verify your local agent configuration to ensure `idempotency_keys` are indeed enabled on your Linux instances.

## Item 914236b3bdd7a2d9

**Question (w2):** Since Tern 3.0 turned idempotency keys off on every platform, should we turn retries off on Linux too?

**Obligations:**
- `correct-premise` (correct_premise): Only Windows agents changed.

**Answer:**

> No. The premise that Tern 3.0 turned idempotency keys off on **every** platform is incorrect.
> 
> According to the Tern 3.0 release notes, idempotency keys are disabled by default **only** on Windows agents. The documentation explicitly states: "Linux and container agents are unchanged and keep keys enabled."
> 
> **Mechanism and Safety**
> Retries are considered safe in Tern because every job carries an idempotency key. When a retry occurs, the worker uses this key to discard duplicate executions, preventing side effects from running twice. Since Linux agents retain enabled idempotency keys by default in Tern 3.0, the safety mechanism for retries remains intact on that platform.
> 
> **Recommendation**
> You should **not** turn retries off on Linux. The Tern 2 operations manual recommends `max_retries = 5` for ordinary jobs, and this recommendation remains applicable to Linux agents in Tern 3.0 because the underlying safety condition (enabled idempotency keys) has not changed.
> 
> **Contrast with Windows**
> The breaking change in Tern 3.0 specifically affects Windows agents because the Windows key store is optional, leading to keys being disabled by default. On Windows agents without explicitly enabled keys, retries can execute side effects twice. For Windows, the release notes advise either enabling `idempotency_keys` explicitly or setting `max_retries = 0` for jobs with side effects. This specific risk does not apply to Linux agents under the default configuration.
> 
> **Uncertainty and Omissions**
> *   **Version Specificity:** This analysis is based on Tern 3.0 release notes and Tern 2 operations manual excerpts. If you are using a version prior to 3.0 or a future version, the defaults may differ.
> *   **Explicit Configuration:** If your Linux agents have been manually configured to disable idempotency keys (overriding the default), then retries would be unsafe, and you should either re-enable keys or disable retries. The default behavior, however, is safe.
> *   **Unverified Claims:** An unsourced forum post claims retries are "always unsafe," but this is contradicted by the official documentation which defines the conditions under which retries are safe (presence of idempotency keys). The forum post provides no version, platform, or measurement to support its absolute claim.
> 
> **Verification**
> To confirm your specific environment:
> 1.  Check the Tern version on your Linux agents.
> 2.  Verify the `idempotency_keys` setting in your agent configuration. If it is not explicitly set to `false`, it should be enabled by default.
> 3.  Review your job definitions to ensure they are compatible with idempotent retries (i.e., they do not rely on non-idempotent side effects that cannot be deduplicated by the key).
> 
> In summary, the breaking change in Tern 3.0 is platform-specific to Windows. Linux agents retain the default safety mechanism for retries, so there is no need to disable them unless you have explicitly disabled idempotency keys or have jobs with non-idempotent side effects that cannot be safely retried.

## Item 95d659aaf0aeb8b8

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> **Short Answer:** No, retries are not inherently safe for payment jobs. They are only safe if the total retry duration is strictly capped below the external payment provider’s deduplication window (typically 24 hours).
> 
> ### Mechanism and Conditions
> 
> The safety of retries depends on the interaction between internal idempotency keys and external provider constraints.
> 
> 1.  **Internal Idempotency:** According to the *Tern 2 operations manual*, every job carries an idempotency key by default. The worker uses this key to discard duplicate executions within the system. This mechanism prevents the internal queue from processing the same job twice.
> 2.  **External Provider Limitations:** The *integration note for payments* clarifies a critical limitation: external payment providers only deduplicate requests within their own specific window, typically 24 hours. If a retry occurs *after* this window has expired, the provider no longer recognizes the idempotency key as a duplicate. Consequently, the provider treats the request as a new transaction, resulting in a double charge.
> 
> **Condition for Safety:**
> Retries are safe **only if** the cumulative time from the initial attempt to the final retry remains **below the provider’s deduplication window** (e.g., < 24 hours). If the backoff strategy or maximum retry count allows the total elapsed time to exceed this window, the retry is unsafe.
> 
> ### Alternatives and Mitigations
> 
> *   **Cap Total Retry Time:** The primary mitigation is to configure the retry policy so that the sum of all backoff intervals plus execution time does not exceed the provider’s window. For example, if the provider window is 24 hours, the `max_retries` and backoff multipliers must be tuned to ensure the last possible retry lands before hour 24.
> *   **Manual Intervention:** For high-value transactions, consider disabling automatic retries after a certain threshold and flagging the job for manual review. This ensures that any potential double-charge risk is handled by a human who can verify the transaction status with the provider before re-attempting.
> *   **Provider-Specific Idempotency:** If the provider supports longer deduplication windows or explicit idempotency token management, use that specific API feature rather than relying solely on the generic job idempotency key.
> 
> ### Verification and Omissions
> 
> *   **Source Conflict:** The *Tern 2 operations manual* recommends `max_retries = 5` for "ordinary jobs" and implies safety via idempotency keys. However, the *integration note* explicitly states that this safety does not extend beyond the provider’s 24-hour window. The manual’s recommendation is **not applicable** to payment jobs without additional time-capping constraints.
> *   **Uncertainty:** The exact deduplication window varies by payment provider (e.g., Stripe, PayPal, Adyen). The "24 hours" figure is cited as a "typical" value in the source material. You must verify the specific window for your provider.
> *   **Omission:** The sources do not specify how to programmatically enforce the "cap total retry time" constraint within the `Tern 2` configuration. You must determine if `max_retries` and backoff settings can be adjusted to meet this requirement or if a custom wrapper is needed.
> 
> ### Conclusion
> 
> Retries are **unsafe** for payment jobs if they can extend beyond the provider’s deduplication window. To make them safe, you must:
> 1.  Identify your provider’s exact deduplication window.
> 2.  Configure the retry policy (backoff + max retries) to ensure the total elapsed time is strictly less than that window.
> 3.  Do not rely on the default `max_retries = 5` recommendation from the general operations manual without verifying it fits within the provider’s time limit.

## Item a346cb5987ff377e

**Question (w3):** At what queue depth should the Tern alarm trigger?

**Obligations:**
- `alarm` (preserve): 1,000 pending jobs, unchanged since the v2 manual.

**Answer:**

> **Tern 2 Operations Manual Recommendation**
> 
> According to the Tern 2 operations manual (Section 9, Monitoring), the queue-depth alarm should trigger at **1,000 pending jobs**.
> 
> **Rationale and Conditions**
> The manual states that below this threshold, backlog clears within one scheduling interval on the reference cluster. This implies that 1,000 is the point where the system’s natural throughput can no longer keep pace with incoming jobs under standard reference conditions.
> 
> **Important Qualifications and Context**
> 1.  **Version Specificity:** This recommendation is explicitly for **Tern 2**. The provided materials do not specify a different threshold for Tern 3.0, though they note that monitoring defaults are unchanged in the 3.0 release.
> 2.  **Platform Dependency:** The "reference cluster" mentioned in the manual likely refers to the standard Linux/container environments where idempotency keys are enabled by default. While the alarm threshold itself is a monitoring metric, the *safety* of the retries that contribute to queue depth varies by platform.
>     *   **Linux/Containers:** Idempotency keys are enabled by default, making retries safe.
>     *   **Windows (Tern 3.0+):** Idempotency keys are disabled by default. Retries can cause duplicate side effects. While this doesn't change the *alarm threshold*, it changes the *risk profile* of the jobs in the queue. If your cluster includes Windows agents, a high queue depth combined with retries poses a higher risk of data inconsistency, potentially warranting a *lower* alarm threshold or stricter retry policies (e.g., `max_retries = 0` for side-effect jobs), even if the manual default remains 1,000.
> 3.  **Payment Jobs:** For jobs calling external payment providers, the manual advises capping total retry time below the provider’s deduplication window (typically 24 hours). This is a constraint on retry *duration*, not queue depth, but it affects how long jobs stay in the queue. If backoff is too long, jobs may linger, contributing to queue depth.
> 4.  **Backoff Cap Dispute:** There is a conflict between the vendor blog (recommending a 60-second backoff cap) and a maintainer comment (suggesting 300 seconds for self-hosted clusters to avoid load amplification). This affects how quickly retries re-enter the queue, thus influencing queue depth dynamics. The 1,000-job alarm threshold is a static trigger, but the *rate* at which the queue fills or drains depends on this backoff setting.
> 
> **Uncertainty and Omissions**
> *   **No Live Check:** This answer is based solely on stored research. No live system check was performed.
> *   **Reference Cluster Definition:** The manual does not define the exact hardware/software configuration of the "reference cluster." If your cluster is significantly smaller or larger, the 1,000-job threshold may be too high or too low.
> *   **Tern 3.0 Monitoring Defaults:** While the release notes state "Monitoring defaults are unchanged," it does not explicitly confirm that the 1,000-job threshold is the *only* default or that it hasn't been adjusted for the new Windows idempotency behavior.
> *   **Forum Post Ignored:** The forum post claiming "retries are always unsafe" is anecdotal, lacks measurement, and contradicts the documented behavior of Tern with idempotency keys. It is not a reliable basis for adjusting the alarm threshold.
> 
> **Actionable Recommendation**
> Set the alarm to **1,000 pending jobs** if you are running Tern 2 or Tern 3.0 on Linux/container agents with default settings. If you are using Windows agents in Tern 3.0, consider lowering the threshold or adding a separate alarm for "jobs with side effects" to account for the increased risk of duplicate executions, even though the manual does not specify a different numeric threshold.

## Item ade5dd2154595cdf

**Question (w2):** A forum post says retries are always unsafe. Should we disable retries on our Linux Tern 3.0 agents?

**Obligations:**
- `keep-advice` (preserve): Linux keeps keys on; retries stay safe.
- `weigh-forum` (use): The post gives no version, platform or measurement.

**Answer:**

> No. The forum post’s claim that retries are “always unsafe” is an overgeneralization that does not apply to your specific configuration. For Linux Tern 3.0 agents, retries are safe by default and should remain enabled.
> 
> **Mechanism and Conditions**
> The safety of retries in Tern depends entirely on the presence of idempotency keys, which prevent duplicate execution of side effects.
> 1.  **Tern 2 Baseline:** The operations manual states that retries are safe because every job carries an idempotency key, enabled by default on all agent platforms. The worker discards duplicate executions using these keys.
> 2.  **Tern 3.0 Change:** The release notes introduce a breaking change specifically for **Windows** agents, where idempotency keys are disabled by default. This creates a risk of double-execution on Windows if retries are enabled without explicitly re-enabling keys.
> 3.  **Linux Exception:** The release notes explicitly state that **Linux and container agents are unchanged and keep keys enabled.** Therefore, the mechanism that makes retries safe (idempotency keys) remains active on your Linux agents.
> 
> **Actionable Recommendation**
> *   **Do not disable retries** on your Linux Tern 3.0 agents.
> *   **Verify Configuration:** Confirm that `idempotency_keys` are still enabled on your Linux agents (they should be by default). If you have explicitly disabled them in a custom configuration, re-enable them before relying on retries.
> *   **Maintain Default Settings:** The manual recommends `max_retries = 5` for ordinary jobs. This setting is appropriate for Linux agents where idempotency is guaranteed.
> *   **Monitor Queue Depth:** Continue using the standard monitoring threshold of 1,000 pending jobs for queue-depth alarms, as monitoring defaults are unchanged in Tern 3.0.
> 
> **Dissent and Uncertainty**
> *   **Dissent:** The forum post’s blanket assertion that retries are “always unsafe” is incorrect for your environment. It likely conflates the Windows-specific risk in Tern 3.0 with all platforms. The supplied evidence shows that the safety mechanism (idempotency keys) is intact on Linux.
> *   **Uncertainty:** This analysis is based on stored research and documentation excerpts. No live check was performed to verify the current configuration of your specific Linux agents. If you have manually disabled idempotency keys on your Linux agents (contrary to the default), retries would become unsafe. Verify your actual agent configuration before finalizing this decision.
> 
> **Verification**
> *   **Source 1 (Tern 2 Manual):** Confirms idempotency keys are enabled by default and make retries safe.
> *   **Source 2 (Tern 3.0 Release Notes):** Confirms Linux agents are unchanged and keep keys enabled, while Windows agents require explicit action.
> *   **Source 3 (Forum Post):** Provides no evidence, version, or platform context; its claim is contradicted by the official documentation for Linux.
> 
> **Conclusion**
> The forum post is not applicable to your Linux Tern 3.0 agents. Retries are safe on your platform because idempotency keys remain enabled by default. Disabling retries would reduce fault tolerance without providing a safety benefit, as the risk of double-execution is already mitigated by the idempotency mechanism.

## Item af5fafecc7aac031

**Question (w2):** Since Tern 3.0 Windows agents have idempotency keys off by default, what should we change there?

**Obligations:**
- `direct-answer` (use): Enable keys or set max_retries = 0 for side effects.

**Answer:**

> **Direct Answer**
> You must explicitly enable idempotency keys or disable retries for jobs with side effects on Tern 3.0 Windows agents. The default behavior in Tern 3.0 for Windows is to disable idempotency keys, which breaks the safety guarantee that retries are idempotent.
> 
> **Mechanism and Conditions**
> In Tern 2, idempotency keys were enabled by default on all platforms, ensuring that if a job failed and was retried, the worker would discard duplicate executions. This made retries safe for jobs with side effects.
> 
> In Tern 3.0, a breaking change was introduced specifically for Windows agents: idempotency keys are disabled by default because the Windows key store is optional. Consequently:
> 1.  **Linux and Container Agents:** Unchanged. Idempotency keys remain enabled by default. Retries remain safe.
> 2.  **Windows Agents:** Idempotency keys are off by default. If a job fails and is retried (using the default `max_retries`), the worker will execute the job’s side effects a second time because it cannot identify the duplicate.
> 
> **Required Changes**
> For any Windows agent running jobs with side effects (e.g., database writes, API calls, file modifications), you must implement one of the following:
> 
> 1.  **Enable Idempotency Keys (Recommended):**
>     *   Configure the Windows agent to explicitly enable `idempotency_keys`.
>     *   This restores the Tern 2 behavior where retries are safe.
>     *   *Condition:* Ensure the Windows key store is available and properly configured, as the release notes indicate the key store is optional on Windows.
> 
> 2.  **Disable Retries:**
>     *   Set `max_retries = 0` for all jobs with side effects on Windows agents.
>     *   This prevents duplicate execution but sacrifices fault tolerance. Jobs will fail permanently on the first error.
> 
> **Alternatives and Trade-offs**
> *   **Enabling Keys:** Preserves fault tolerance (retries) and safety. Requires infrastructure support for the key store on Windows.
> *   **Disabling Retries:** Simplifies configuration (no key store dependency) but reduces reliability. A transient network error will cause a permanent job failure.
> 
> **Verification and Uncertainty**
> *   **Source:** The recommendation is based on the Tern 3.0 release notes [a35efd6c6946719db6d1db7d8e9b4d8b2f1a15f3680f969ab78fa93ae70eaab6], which explicitly states: "Either enable idempotency_keys explicitly or set max_retries = 0 for jobs with side effects."
> *   **Dissent:** A forum post [c32cddbdc83b77bedc8645ac07837904dadf01ab98535b6f4aa1f17091f5ab8f] claims "retries are always unsafe in every job scheduler, so turn them off everywhere." This is **incorrect** and contradicts the Tern documentation. Tern 2 and Tern 3 (Linux/Container) explicitly state retries are safe *because* of idempotency keys. The forum post lacks version, platform, or measurement context and should be ignored.
> *   **Uncertainty:** The release notes state the Windows key store is "optional." It is unclear if enabling `idempotency_keys` automatically provisions the key store or if manual OS-level configuration is required. Verify your Windows environment supports the key store before relying on Option 1.
> 
> **Action Plan**
> 1.  Identify all Windows agents running Tern 3.0.
> 2.  Audit jobs for side effects.
> 3.  For side-effect jobs:
>     *   **Option A:** Enable `idempotency_keys` in the agent configuration. Verify key store functionality.
>     *   **Option B:** Set `max_retries = 0` for these specific jobs.
> 4.  Do not change configuration for Linux or container agents, as they remain safe by default.

## Item b27d33740de91141

**Question (w2):** Since Tern 3.0 Windows agents have idempotency keys off by default, what should we change there?

**Obligations:**
- `direct-answer` (use): Enable keys or set max_retries = 0 for side effects.

**Answer:**

> Based on the Tern 3.0 release notes, the default behavior for Windows agents has changed: idempotency keys are now disabled by default because the Windows key store is optional. This creates a specific risk: without idempotency keys, a retry can execute a job's side effects twice.
> 
> To address this, you must choose one of two configurations for jobs with side effects on Tern 3.0 Windows agents:
> 
> 1.  **Enable idempotency keys explicitly:** Set `idempotency_keys` to enabled. This restores the safety mechanism where the worker discards duplicate executions, allowing you to maintain the recommended `max_retries = 5` for ordinary jobs.
> 2.  **Disable retries for side-effect jobs:** Set `max_retries = 0` for any job that has side effects. This prevents the duplicate execution risk but removes the automatic retry benefit for those specific jobs.
> 
> **Important Distinctions:**
> *   **Platform Specificity:** This change applies **only** to Windows agents. Linux and container agents are unchanged and keep idempotency keys enabled by default. Therefore, you do not need to change configurations for those platforms.
> *   **Scope of Change:** The release notes specify that monitoring defaults are unchanged. The queue-depth alarm threshold (1,000 pending jobs) remains valid.
> *   **Uncertainty:** The provided materials do not specify whether other platforms will change key defaults in later releases, nor do they provide a mechanism to verify if your specific Windows environment has the optional key store installed. You should verify your current `idempotency_keys` setting in your Tern configuration for Windows agents to confirm if they are currently disabled.
> 
> **Action Plan:**
> 1.  Identify all jobs running on Tern 3.0 Windows agents that have side effects.
> 2.  For these jobs, either enable `idempotency_keys` or set `max_retries = 0`.
> 3.  Leave Linux and container agent configurations unchanged.
> 4.  Verify the configuration change by checking the agent logs or configuration file to ensure the intended setting is active.
> 
> **Dissent:**
> An unsourced forum post claims "retries are always unsafe in every job scheduler, so turn them off everywhere." This is a general assertion without version, platform, or measurement data. It conflicts with the Tern documentation, which states retries are safe when idempotency keys are enabled. The Tern documentation is the authoritative source for Tern-specific behavior.

## Item b4d7002276e2900a

**Question (w2):** A forum post says retries are always unsafe. Should we disable retries on our Linux Tern 3.0 agents?

**Obligations:**
- `keep-advice` (preserve): Linux keeps keys on; retries stay safe.
- `weigh-forum` (use): The post gives no version, platform or measurement.

**Answer:**

> **No, do not disable retries globally on Linux Tern 3.0 agents based on that forum post.**
> 
> The forum claim that "retries are always unsafe" is an unsourced, overgeneralized assertion that lacks version, platform, or measurement data. It does not apply to your specific environment.
> 
> **Mechanism and Platform Specifics**
> The risk of unsafe retries (specifically, duplicate side effects) arises when idempotency keys are disabled. In Tern 3.0, this is a **Windows-specific** breaking change.
> *   **Windows Agents:** Idempotency keys are disabled by default because the Windows key store is optional. Without keys, a retry can execute side effects twice.
> *   **Linux Agents:** Idempotency keys remain **enabled by default** and are unchanged in Tern 3.0.
> 
> Because your agents are Linux, they retain idempotency keys by default. This means that for jobs with side effects, the scheduler can use these keys to prevent duplicate execution upon retry. Therefore, the specific failure mode cited in the release notes (double-execution due to missing keys) does not automatically apply to your Linux fleet.
> 
> **Conditions for Safety**
> Retries are safe on your Linux agents provided:
> 1.  You have not explicitly disabled `idempotency_keys` in your configuration.
> 2.  Your jobs are designed to be idempotent or rely on the Tern idempotency key mechanism to deduplicate side effects.
> 
> **Alternatives and Verification**
> *   **Do Not Disable Globally:** Setting `max_retries = 0` everywhere would eliminate resilience against transient network or infrastructure failures, which is a significant operational trade-off not justified by the forum post.
> *   **Targeted Action:** If you have specific jobs that are *not* idempotent and you suspect the idempotency key mechanism is insufficient for them, you should disable retries *only* for those specific job definitions, not the entire agent.
> *   **Verification:**
>     1.  Confirm your Linux agent configuration explicitly shows `idempotency_keys` as enabled (or left at the default).
>     2.  Audit your job definitions to identify any non-idempotent side effects.
>     3.  For those specific non-idempotent jobs, set `max_retries = 0` or implement application-level idempotency.
> 
> **Uncertainty**
> The stored finding confirms Linux keys are enabled by default in 3.0, but it does not verify whether *your specific* Linux agents have been manually configured to disable keys. You must check your local configuration to confirm the default state is active.

## Item b6bde8462e3b777f

**Question (w3):** What backoff cap should we configure for Tern?

**Obligations:**
- `vendor-view` (retain_conflict): Vendor: 60 seconds, hosted.
- `maintainer-view` (retain_conflict): Maintainer: 300 seconds, self-hosted; open.

**Answer:**

> Based on the supplied research, there is no single universal backoff cap for Tern; the correct configuration depends on your deployment platform, job type, and cluster architecture. The sources present conflicting recommendations and critical safety constraints that must be resolved before selecting a value.
> 
> **1. Platform-Specific Safety Constraints (Highest Priority)**
> Before choosing a backoff duration, you must verify idempotency key status, as this determines whether retries are safe at all.
> *   **Linux/Container Agents:** Idempotency keys are enabled by default. Retries are safe because duplicate executions are discarded.
> *   **Windows Agents (Tern 3.0+):** Idempotency keys are **disabled by default**. Retries can execute side effects twice.
>     *   *Action:* If using Windows agents, you must either explicitly enable `idempotency_keys` or set `max_retries = 0` for jobs with side effects. A backoff cap is irrelevant if retries are disabled for safety.
> 
> **2. Job-Type Specific Constraints**
> *   **Payment/External Provider Jobs:** Even with idempotency keys, external providers typically deduplicate only within a 24-hour window.
>     *   *Action:* Cap total retry time (backoff cap × max_retries) well below 24 hours to avoid double-charging. This is a hard upper bound for this job class.
> *   **Ordinary Jobs:** The manual recommends `max_retries = 5`.
> 
> **3. Backoff Cap Recommendations (Conflicting Data)**
> The sources provide two specific, conflicting recommendations for the exponential backoff cap:
> 
> *   **Option A: 60 Seconds**
>     *   *Source:* Vendor engineering blog.
>     *   *Rationale:* Longer caps leave queues idle during short outages.
>     *   *Limitation:* Measured only on vendor-hosted clusters.
> *   **Option B: 300 Seconds**
>     *   *Source:* Maintainer comment on GitHub issue #982.
>     *   *Rationale:* A 60-second cap amplified load during a regional outage.
>     *   *Limitation:* Suggested specifically for **self-hosted clusters**. The issue remains open, and no benchmark settles the difference.
> 
> **Synthesis and Recommendation**
> 
> *   **If you are on Vendor-Hosted Clusters:** Use **60 seconds**. This aligns with the vendor’s measured data for their infrastructure.
> *   **If you are on Self-Hosted Clusters:** Use **300 seconds**. This aligns with the maintainer’s guidance for self-hosted environments to prevent load amplification during outages.
> *   **If you are on Windows Agents:** First, decide if you will enable idempotency keys. If not, set `max_retries = 0`. If yes, apply the cap based on your hosting model (60s or 300s) as above.
> 
> **Verification and Uncertainty**
> *   **Conflict:** The 60s vs. 300s recommendation is unresolved in the source material. The maintainer’s 300s suggestion is tied to a specific outage scenario and self-hosting context, while the vendor’s 60s is tied to hosted cluster performance.
> *   **Omission:** No source provides a formula for calculating the cap based on queue depth or specific SLA requirements. The manual’s recommendation of `max_retries = 5` is independent of the backoff cap value.
> *   **Uncertainty:** The GitHub issue #982 is open, meaning the 300s recommendation is not a finalized standard but a suggested mitigation. The vendor blog’s 60s recommendation is limited to their hosted environment.
> 
> **Action Plan**
> 1.  **Audit Agents:** Identify all Windows agents. Ensure `idempotency_keys` are explicitly enabled or `max_retries` is set to 0 for side-effect jobs.
> 2.  **Classify Jobs:** Identify payment/external provider jobs. Ensure total retry time < 24 hours.
> 3.  **Select Cap:**
>     *   Hosted: Set backoff cap to **60 seconds**.
>     *   Self-Hosted: Set backoff cap to **300 seconds**.
> 4.  **Monitor:** Use the queue-depth alarm at 1,000 pending jobs to detect backlog issues that may indicate the backoff cap is too low (causing idle queues) or too high (causing load amplification).

## Item bcf9ea9ceae52b9b

**Question (w2):** Since Tern 3.0 Windows agents have idempotency keys off by default, what should we change there?

**Obligations:**
- `direct-answer` (use): Enable keys or set max_retries = 0 for side effects.

**Answer:**

> **Direct Answer**
> You must explicitly enable idempotency keys or disable retries for jobs that have side effects. The specific configuration change depends on your risk tolerance for duplicate execution versus job loss.
> 
> **Required Changes**
> 1.  **Enable Idempotency Keys (Recommended):** Set `idempotency_keys = true` (or the equivalent explicit enablement flag) in your Windows agent configuration. This restores the default safety behavior found in Linux and container agents, ensuring that if a job is retried, the side effects are not executed twice.
> 2.  **Disable Retries (Alternative):** Set `max_retries = 0` for specific jobs that have side effects. This prevents the duplicate execution issue by ensuring the job is not retried at all. This is a stricter constraint that may reduce reliability if transient network issues occur.
> 
> **Mechanism & Context**
> *   **Why this is a breaking change:** Tern 3.0 disabled idempotency keys by default on Windows agents because the Windows key store is optional. This differs from Linux and container agents, which still have keys enabled by default.
> *   **The Risk:** Without keys, a retry mechanism can trigger the job’s side effects a second time, leading to duplicate actions (e.g., double-charging, duplicate records).
> *   **Scope:** This change applies specifically to **Windows agents** in **Tern 3.0**. It does not affect Linux or container agents. Monitoring defaults are unchanged.
> 
> **Verification & Uncertainty**
> *   **Source:** This guidance is derived from stored research (Tern 3.0 release notes, passage `a35efd6c6946719db6d1db7d8e9b4d8b2f1a15f3680f969ab78fa93ae70eaab6`).
> *   **Uncertainty:** No live check was performed. The exact syntax for enabling keys (e.g., `idempotency_keys = true` vs. a CLI flag) is not specified in the provided source; consult your specific Tern 3.0 configuration documentation for the precise parameter name. The source states "enable idempotency_keys explicitly," implying a configuration setting, but the exact key name may vary by deployment method.

## Item c175b579295199b2

**Question (w2):** We run Tern 3.0 agents on Windows. Is max_retries = 5 still safe for jobs with side effects?

**Obligations:**
- `use-correction` (use): Keys are off by default on 3.0 Windows agents.
- `keep-mechanism` (preserve): Keys are what make retries safe.
- `scope-linux` (preserve): Linux and container agents are unaffected.

**Answer:**

> **No, `max_retries = 5` is not safe for jobs with side effects on Tern 3.0 Windows agents.**
> 
> **Mechanism and Condition**
> The safety of retries in Tern relies on idempotency keys to discard duplicate executions. In Tern 2, these keys were enabled by default across all platforms, making `max_retries = 5` a recommended standard for ordinary jobs. However, Tern 3.0 introduced a breaking change specifically for Windows agents: idempotency keys are now **disabled by default** because the Windows key store is treated as optional.
> 
> Consequently, on a Tern 3.0 Windows agent, if a job fails and is retried, the worker does not have the default mechanism to detect and discard the duplicate execution. This means a retry can execute the job’s side effects twice. Linux and container agents are unaffected by this change and retain idempotency keys enabled by default.
> 
> **Actionable Alternatives**
> To safely handle jobs with side effects on Tern 3.0 Windows agents, you must explicitly configure one of the following:
> 
> 1.  **Enable Idempotency Keys:** Explicitly set `idempotency_keys` to `true` for your Windows agents. This restores the default safety mechanism present in Tern 2 and other platforms, allowing you to maintain `max_retries = 5` (or other appropriate retry counts) while ensuring duplicate executions are discarded.
> 2.  **Disable Retries for Side-Effect Jobs:** Set `max_retries = 0` for any job that has side effects. This prevents duplicate execution but sacrifices the resilience benefits of automatic retries. You would need to implement manual recovery or alerting for failed jobs.
> 
> **Verification and Omissions**
> *   **Source Scope:** The conclusion is based on the Tern 3.0 release notes, which explicitly state that idempotency keys are disabled by default on Windows agents and that retries can execute side effects twice in this configuration.
> *   **Uncertainty:** This answer assumes your Windows agents are running the default configuration for Tern 3.0. If you have already manually enabled idempotency keys in your agent configuration, `max_retries = 5` would be safe. Verify your current agent configuration to confirm whether `idempotency_keys` is explicitly set to `true`.
> *   **Omission:** No live check of your specific agent configuration was performed. The recommendation to enable keys or set retries to 0 is based on the documented default behavior change in Tern 3.0.

## Item c9b5fb7e3a92aa13

**Question (w1):** As of January 2026, what did the Tern documentation recommend for max_retries on Windows agents?

**Obligations:**
- `answer-from-w1` (use): Keys on by default everywhere; max_retries = 5.
- `no-later-knowledge` (isolate): No 3.0 or later source may inform the answer.

**Answer:**

> Based on the provided stored research, the Tern documentation (specifically the "Tern 2 operations manual, section 7") recommends **max_retries = 5** for ordinary jobs.
> 
> **Important Qualifications and Uncertainties:**
> 
> 1.  **Platform Specificity:** The source text states that idempotency keys are enabled by default on "every agent platform," which implies the recommendation applies universally, including Windows agents. However, the text does not explicitly isolate Windows-specific retry configurations or caveats. It presents `max_retries = 5` as a general recommendation for "ordinary jobs."
> 2.  **Source Reliability:** This answer is derived from "Stored research only; no live check was performed." The source is identified as `docs.tern.example`, which suggests it may be a placeholder, example, or internal documentation rather than a verified public release.
> 3.  **Temporal Validity:** The question asks for the state "As of January 2026." The provided text does not include a publication date or version number that confirms this recommendation was current in January 2026. It is presented as a static finding from the "Tern 2 operations manual."
> 4.  **Mechanism:** The recommendation relies on the presence of idempotency keys, which are stated to be on by default. This ensures that retries are safe because duplicate executions are discarded by the worker.
> 
> **Conclusion:**
> According to the supplied stored finding, the Tern documentation recommends **max_retries = 5**. This is based on the general recommendation for ordinary jobs, assuming the default idempotency key behavior holds on Windows agents. No Windows-specific deviation is noted in the provided text.

## Item d691c9a35361433b

**Question (w2):** We run Tern 3.0 agents on Windows. Is max_retries = 5 still safe for jobs with side effects?

**Obligations:**
- `use-correction` (use): Keys are off by default on 3.0 Windows agents.
- `keep-mechanism` (preserve): Keys are what make retries safe.
- `scope-linux` (preserve): Linux and container agents are unaffected.

**Answer:**

> **No, `max_retries = 5` is not safe for jobs with side effects on Tern 3.0 Windows agents.**
> 
> **Mechanism and Condition**
> The safety of retries in Tern relies on idempotency keys to discard duplicate executions. In Tern 2, these keys were enabled by default on all platforms, making `max_retries = 5` a recommended setting for ordinary jobs. However, the Tern 3.0 release notes specify a breaking change for Windows agents: idempotency keys are **disabled by default** because the Windows key store is optional.
> 
> Consequently, on a Windows agent running Tern 3.0 without explicit configuration, the idempotency mechanism that previously guaranteed safety is absent. If a job fails and is retried, the worker will not detect the duplicate execution via an idempotency key. As stated in the release notes, "a retry can execute a job's side effects twice." Therefore, setting `max_retries = 5` exposes your system to duplicate side effects (e.g., double-charging, duplicate API calls, or repeated file writes) for any job that fails and is subsequently retried.
> 
> **Alternatives**
> To maintain safety for jobs with side effects on Tern 3.0 Windows agents, you must take one of the following actions explicitly recommended in the release notes:
> 1.  **Enable idempotency keys explicitly:** Configure the agent to enable `idempotency_keys`. This restores the duplicate-detection mechanism, allowing you to retain `max_retries = 5` (or another non-zero value) safely.
> 2.  **Set `max_retries = 0`:** Disable retries entirely for jobs with side effects. This prevents duplicate execution but sacrifices the resilience benefits of retrying transient failures.
> 
> **Verification and Uncertainty**
> *   **Source Conflict:** The Tern 2 manual (b1c641fe...) states that idempotency keys are enabled by default on *every* agent platform. This is superseded by the Tern 3.0 release notes (a35efd6c...), which explicitly state that keys are disabled by default on Windows. The release notes take precedence as they describe the current version's behavior.
> *   **Irrelevant Material:** The forum post (c32cddb...) claiming "retries are always unsafe in every job scheduler" is unverified, lacks platform/version specificity, and contradicts the documented behavior of Tern 2 and properly configured Tern 3. It should be ignored.
> *   **Scope Limitation:** This analysis is based solely on the provided stored research. No live check of your specific agent configuration was performed. You must verify whether `idempotency_keys` are currently enabled in your Windows agent configuration. If they are explicitly enabled, `max_retries = 5` may be safe; if they are at the default (disabled), it is unsafe.
> 
> **Actionable Step**
> Check your Tern 3.0 Windows agent configuration for the `idempotency_keys` setting. If it is not explicitly set to `true`, either enable it or reduce `max_retries` to `0` for all jobs with side effects.

## Item d8c873ccc7f87c50

**Question (w2):** Could automatic re-attempts run side effects twice on hosts with the Microsoft OS on release three?

**Obligations:**
- `low-overlap-correction` (use): Yes, without keys on 3.0 Windows agents.

**Answer:**

> Yes. On Windows hosts running the Tern 3.0 agent, automatic re-attempts can execute job side effects twice if idempotency keys are not explicitly enabled.
> 
> **Mechanism**
> In the Tern 3.0 release, idempotency keys are disabled by default on the Windows agent because the Windows key store is treated as optional. Without these keys, the system lacks a mechanism to detect that a specific job execution has already occurred. Consequently, if a job fails and is automatically retried, the retry logic treats the new attempt as a fresh execution rather than a duplicate, causing the side effects to run again. This behavior is specific to the Windows agent; Linux and container agents remain unchanged and keep idempotency keys enabled by default.
> 
> **Conditions**
> The double-execution risk applies when:
> 1.  The host is running the Windows OS.
> 2.  The agent version is Tern 3.0.
> 3.  The job has side effects (e.g., sending emails, creating records, modifying external systems).
> 4.  Idempotency keys are not explicitly enabled for that job or agent configuration.
> 5.  Automatic retries are active (i.e., `max_retries` is greater than 0).
> 
> **Alternatives and Corrections**
> To prevent duplicate side effects on Windows hosts in this release, you must implement one of the following:
> 1.  **Enable Idempotency Keys:** Explicitly configure `idempotency_keys` to be enabled. This restores the deduplication mechanism, allowing the system to recognize and skip retries of already-executed jobs.
> 2.  **Disable Retries for Side-Effect Jobs:** Set `max_retries = 0` for jobs that have non-idempotent side effects. This ensures that if a job fails, it does not automatically retry, thereby preventing double execution.
> 
> **Verification**
> This conclusion is based on the stored finding from the Tern 3.0 release notes (passage `a35efd6c6946719db6d1db7d8e9b4d8b2f1a15f3680f969ab78fa93ae70eaab6`). The source explicitly states: "On a Windows agent without keys, a retry can execute a job's side effects twice." It further confirms that this is a breaking change in this specific release and that Linux/container agents are unaffected. No live check was performed; this answer relies solely on the provided stored research.
> 
> **Uncertainty**
> The primary uncertainty lies in whether "Windows 3.0" in the question refers to the OS version or the agent version. The source material specifies "Tern 3.0 release notes" and "Windows agent," implying the agent version is 3.0. If the question intended to ask about Microsoft Windows OS version 3.0 (which is obsolete), the answer would be irrelevant to modern deployments. However, given the context of "release three" and the specific mention of "Microsoft OS," it is most likely referring to the Tern 3.0 agent running on current Windows versions. Additionally, the source does not specify if this behavior applies to all Windows versions supported by Tern 3.0 or only specific ones, though it implies a general change for the "Windows agent."

## Item e6b7cf5a54e612c3

**Question (w2):** Could automatic re-attempts run side effects twice on hosts with the Microsoft OS on release three?

**Obligations:**
- `low-overlap-correction` (use): Yes, without keys on 3.0 Windows agents.

**Answer:**

> Yes. On the Windows agent in Tern 3.0, automatic re-attempts can execute a job's side effects twice.
> 
> **Mechanism**
> The release notes identify a breaking change specific to the Windows agent: idempotency keys are disabled by default. The stated reason is that the Windows key store is optional. Without idempotency keys, the system lacks the mechanism to detect and prevent duplicate execution of non-idempotent operations during a retry. Consequently, if a job fails and is automatically retried, the side effects (e.g., API calls, database writes, file modifications) may be executed again.
> 
> **Conditions**
> *   **Platform:** Windows agent only. Linux and container agents are unaffected and retain idempotency keys enabled by default.
> *   **Version:** Tern 3.0.
> *   **Configuration:** Idempotency keys are not explicitly enabled.
> *   **Job Type:** Jobs with side effects. Purely read-only or idempotent operations are not subject to this duplication risk.
> 
> **Alternatives / Mitigation**
> The documentation provides two specific remedies for jobs with side effects on Windows agents:
> 1.  **Enable idempotency keys explicitly:** Set `idempotency_keys` to true in the agent or job configuration. This restores the duplicate-prevention mechanism.
> 2.  **Disable retries:** Set `max_retries = 0` for jobs with side effects. This prevents the automatic re-attempt that causes the duplication.
> 
> **Verification**
> *   **Source:** The conclusion is derived directly from the provided reference passage `[a35efd6c6946719db6d1db7d8e9b4d8b2f1a15f3680f969ab78fa93ae70eaab6]` (Tern 3.0 release notes).
> *   **Scope:** The passage explicitly states: "On a Windows agent without keys, a retry can execute a job's side effects twice."
> *   **Limitations:** This is based on stored research only; no live check was performed. The passage does not specify which Windows versions are affected, only that the "Windows key store is optional." It also does not detail how to enable keys (e.g., specific config file syntax), only that it must be done explicitly.
> 
> **Uncertainty**
> The primary uncertainty is whether "Windows agent" refers to all Windows versions or specific ones, as the source does not specify OS version constraints. Additionally, the source does not clarify if "side effects" includes all non-idempotent operations or only specific types, though the general implication is any non-idempotent action.

## Item e6ea32870d0d98a0

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> **Retries are conditionally safe for payment jobs, provided two strict constraints are met: idempotency keys are active, and the total retry duration remains within the payment provider’s deduplication window.**
> 
> ### Mechanisms and Conditions
> 
> 1.  **Idempotency Keys are Mandatory but Platform-Dependent**
>     *   **Mechanism:** Tern workers discard duplicate executions if an idempotency key is present.
>     *   **Condition:** Keys are enabled by default on Linux and container agents. However, on **Windows agents**, keys are **disabled by default** in Tern 3.0+ due to optional key store support.
>     *   **Risk:** On Windows agents without explicit configuration, retries will execute side effects twice, resulting in double charges.
> 
> 2.  **Provider Deduplication Windows**
>     *   **Mechanism:** External payment providers deduplicate requests only within their own window (typically 24 hours).
>     *   **Condition:** If a retry lands *after* this window expires, the provider treats it as a new transaction.
>     *   **Risk:** Retries that extend beyond the provider’s window (e.g., due to long backoff caps or queue delays) can cause double charges even if idempotency keys are active.
> 
> ### Actionable Requirements
> 
> To ensure safety:
> 
> 1.  **Verify Idempotency Key Status:**
>     *   **Linux/Containers:** Confirm keys are enabled (default).
>     *   **Windows:** Explicitly set `idempotency_keys = true` or set `max_retries = 0` for payment jobs. Do not rely on defaults.
> 
> 2.  **Cap Total Retry Time:**
>     *   Ensure the sum of all backoff intervals plus execution time is **strictly less than** the payment provider’s deduplication window (e.g., < 24 hours).
>     *   **Backoff Cap:** The vendor recommends a 60-second backoff cap for hosted clusters. For self-hosted clusters, a 300-second cap is suggested to avoid amplifying load during outages, but this must still fit within the provider’s window. *Note: No benchmark settles the optimal cap; choose based on your outage tolerance and provider window.*
> 
> 3.  **Set `max_retries`:**
>     *   The manual recommends `max_retries = 5` for ordinary jobs. For payment jobs, verify that 5 retries with your chosen backoff cap do not exceed the provider’s deduplication window. If they do, reduce `max_retries`.
> 
> ### Dissent and Uncertainty
> 
> *   **Dissent:** A forum post claims "retries are always unsafe in every job scheduler." This is **not supported** by the provided evidence. The Tern documentation explicitly states retries are safe *if* idempotency keys are enabled and provider windows are respected. The forum post lacks measurement, version, or platform context and is treated as unverified opinion.
> *   **Uncertainty:** The optimal backoff cap (60s vs. 300s) is not settled by benchmarks. The 60s cap is measured on hosted clusters only; the 300s suggestion is for self-hosted clusters during outages. Choose based on your infrastructure and monitor queue depth (alarm at 1,000 pending jobs).
> 
> ### Verification Steps
> 
> 1.  **Check Agent Platform:** Confirm if the agent is Windows, Linux, or container.
> 2.  **Inspect Configuration:** Verify `idempotency_keys` is `true` for payment jobs on all agents.
> 3.  **Calculate Retry Duration:** Sum the maximum possible backoff intervals for `max_retries` and ensure it is < 24 hours (or your provider’s specific window).
> 4.  **Monitor:** Set queue-depth alarms at 1,000 pending jobs to detect backlog that could delay retries beyond the provider window.
> 
> **Material Omission:** No live check was performed. Provider deduplication windows vary; confirm your specific provider’s window. The 24-hour figure is a "typical" value from the integration note, not a universal constant.

## Item e974585968f5b040

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> **Short Answer**
> Retries for payment jobs are **conditionally safe**. They are safe only if two specific conditions are met:
> 1.  **Idempotency keys are enabled** on the agent platform.
> 2.  **Total retry time remains below the payment provider’s deduplication window** (typically 24 hours).
> 
> If either condition fails, retries can result in duplicate charges.
> 
> ### Mechanisms and Conditions
> 
> **1. Idempotency Keys (Worker-Level Safety)**
> According to the Tern 2 operations manual, retries are considered safe because every job carries an idempotency key. The worker uses this key to discard duplicate executions.
> *   **Linux/Container Agents:** Keys are enabled by default.
> *   **Windows Agents (Tern 3.0+):** Keys are **disabled by default** due to the optional nature of the Windows key store. On these agents, retries without explicitly enabling `idempotency_keys` will execute side effects twice.
> 
> **2. Provider Deduplication Windows (External Safety)**
> Even with idempotency keys enabled, external payment providers only deduplicate requests within their own specific window, typically **24 hours**.
> *   **Risk:** If a retry occurs *after* this window expires, the provider will treat it as a new request, resulting in a double charge.
> *   **Requirement:** You must cap the total retry duration (including backoff) to be strictly less than the provider’s deduplication window.
> 
> ### Platform-Specific Guidance
> 
> | Platform | Default Key Status | Safety Condition for Retries |
> | :--- | :--- | :--- |
> | **Linux / Containers** | Enabled | Safe if total retry time < provider window. |
> | **Windows (Tern 3.0+)** | **Disabled** | **Unsafe** unless you explicitly enable `idempotency_keys` OR set `max_retries = 0`. |
> 
> ### Actionable Recommendations
> 
> 1.  **Verify Platform Defaults:** Confirm whether your agents are Linux/Container or Windows. If Windows, explicitly set `idempotency_keys = true` for payment jobs.
> 2.  **Cap Retry Time:** Calculate the maximum possible retry duration (based on `max_retries` and backoff strategy) and ensure it is significantly below the provider’s dedup window (e.g., if the window is 24h, keep total retry time under 12h to be safe).
> 3.  **Avoid Unbounded Retries:** Do not use `max_retries = 5` (the general recommendation for ordinary jobs) for payment jobs if the cumulative backoff time exceeds the provider window. For payment jobs, a lower `max_retries` or shorter backoff intervals may be required.
> 4.  **Monitoring:** Trigger queue-depth alarms at 1,000 pending jobs to detect backlogs that might delay retries beyond safe windows.
> 
> ### Dissent and Uncertainty
> 
> *   **Dissent:** An unsourced forum post claims retries are "always unsafe" and should be disabled everywhere. This is a broad generalization that contradicts the documented behavior of Tern with idempotency keys. It lacks version, platform, or measurement data, so it is not a reliable basis for decision-making.
> *   **Uncertainty:**
>     *   The exact deduplication window varies by payment provider; "24 hours" is a typical value, not a universal constant. You must verify your specific provider’s documentation.
>     *   The safety of retries on agent platforms other than Linux, containers, and Windows is unknown.
>     *   The Tern 2 manual states keys are enabled by default on "every agent platform," but the Tern 3.0 release notes explicitly override this for Windows. Always check the specific version and platform release notes.
> 
> **Conclusion:** Retries are safe for payment jobs **only** when idempotency keys are active and the total retry duration is constrained to be less than the payment provider’s deduplication window. On Windows agents running Tern 3.0+, you must explicitly enable keys or disable retries entirely.

## Item eb36d369c6ec46b0

**Question (w2):** Could automatic re-attempts run side effects twice on hosts with the Microsoft OS on release three?

**Obligations:**
- `low-overlap-correction` (use): Yes, without keys on 3.0 Windows agents.

**Answer:**

> Yes, automatic re-attempts can run side effects twice on Windows hosts in Tern 3.0, but only if idempotency keys are not explicitly enabled.
> 
> **Mechanism and Conditions**
> In Tern 2, retries were considered safe across all platforms because idempotency keys were enabled by default. These keys allowed workers to discard duplicate executions. However, the Tern 3.0 release notes introduce a breaking change specifically for the Windows agent: idempotency keys are disabled by default because the Windows key store is treated as optional. Consequently, on a Windows agent where keys remain disabled, the worker cannot identify a retry as a duplicate. If a job fails and is retried, the side effects will execute again.
> 
> This risk is platform-specific. Linux and container agents in Tern 3.0 retain the default behavior of having idempotency keys enabled, so they remain protected against duplicate side effects during retries.
> 
> **Alternatives and Mitigation**
> To prevent double execution on Windows hosts in Tern 3.0, you must take one of the following actions:
> 1.  **Enable Idempotency Keys Explicitly:** Configure the agent or job to enable `idempotency_keys` despite the new default. This restores the duplicate-detection mechanism.
> 2.  **Disable Retries for Side-Effect Jobs:** Set `max_retries = 0` for any job that performs non-idempotent side effects. This ensures the job runs only once, eliminating the risk of duplication.
> 
> **Verification and Uncertainty**
> The conclusion is directly supported by the Tern 3.0 release notes, which explicitly state: "On a Windows agent without keys, a retry can execute a job's side effects twice." This contradicts the general safety claim found in the Tern 2 operations manual, which assumed keys were always enabled by default. The forum post claiming retries are "always unsafe" is unsupported by version or platform data and is disregarded as it lacks specific evidence.
> 
> The primary uncertainty lies in whether your specific Windows agents have already been configured to explicitly enable idempotency keys. If they have, the risk is mitigated. If they rely on defaults, the risk is active. No live check was performed to verify your current configuration.

## Item ed5f6e95f56d73f3

**Question (w3):** What retry settings should we use for Tern agents on macOS?

**Obligations:**
- `defer-macos` (defer): No source covers macOS agents; say so and scope the answer.

**Answer:**

> **Direct Answer**
> The supplied evidence does not contain specific retry settings for macOS. The documentation and findings provided explicitly cover **Linux**, **containers**, and **Windows** agents, but **macOS is listed as an unknown** in the expert's stored research. Therefore, no specific `max_retries` or backoff cap can be recommended for macOS based on this data.
> 
> **Mechanisms and Conditions**
> 1.  **Idempotency Keys:** Retries are safe only if idempotency keys are enabled, allowing the worker to discard duplicate executions.
>     *   **Linux/Containers:** Keys are enabled by default (Tern 2 and 3.0).
>     *   **Windows (Tern 3.0):** Keys are **disabled** by default. Retries without keys can execute side effects twice.
> 2.  **Backoff Cap:**
>     *   **Hosted Clusters:** Vendor recommends a 60-second cap.
>     *   **Self-Hosted Clusters:** Maintainer suggests a 300-second cap.
>     *   **macOS:** No data provided.
> 3.  **Payment Jobs:** Even with keys, retries must complete within the payment provider’s deduplication window (typically 24 hours) to prevent double-charging.
> 
> **Applicability to macOS**
> *   **Platform Status:** The expert explicitly marks "Retry behaviour on agent platforms other than Linux, containers and Windows" as **Unknown**.
> *   **Assumption Risk:** You cannot assume macOS behaves like Linux (keys enabled) or Windows (keys disabled) without verification. The Tern 3.0 breaking change specifically cites the "Windows key store" as the reason for disabling keys; it does not state whether macOS uses a similar optional key store mechanism.
> 
> **Actionable Steps**
> 1.  **Verify macOS Support:** Check the current Tern documentation or release notes for macOS-specific agent behavior regarding idempotency keys.
> 2.  **If macOS is unsupported/unknown:**
>     *   Treat macOS as a **high-risk** platform for retries.
>     *   Set `max_retries = 0` for any job with side effects (including payments) until you can verify idempotency key behavior.
>     *   If you must use retries, explicitly enable `idempotency_keys` if the configuration allows it, and test for duplicate side effects.
> 3.  **Backoff Cap:** Since no macOS-specific benchmark exists, use the **60-second** cap if your macOS agents are part of a hosted cluster, or **300 seconds** if self-hosted, but recognize this is extrapolated from other platforms.
> 
> **Uncertainty**
> The primary uncertainty is the **default state of idempotency keys on macOS**. The provided sources do not address macOS, and the expert’s research explicitly flags this as unknown. Do not assume Linux defaults apply.

## Item ef355e4e86cdee1e

**Question (w3):** Are retries safe for payment jobs?

**Obligations:**
- `payment-window` (use): Cap retry time below the provider window.
- `keys-mechanism` (preserve): Keys still protect within the window.

**Answer:**

> Retries for payment jobs are **not inherently safe** and can result in duplicate charges if not strictly constrained. Safety depends entirely on the interaction between your internal idempotency logic and the external payment provider’s deduplication window.
> 
> ### Mechanism of Risk
> The core issue is a mismatch between internal state and external state.
> 1.  **Internal Idempotency:** Your job queue (e.g., Tern) uses idempotency keys to prevent the *same worker* from executing the same job twice. This is enabled by default and ensures that if a job fails and is retried within the same system, the duplicate is discarded.
> 2.  **External Provider Limits:** Payment providers (e.g., Stripe, PayPal) only deduplicate requests within their own specific window, typically **24 hours**. If a retry occurs *after* this window has expired, the provider treats it as a new, valid request.
> 3.  **The Failure Mode:** If a payment job fails, is stuck in a queue, or is retried with a backoff strategy that exceeds the provider’s 24-hour window, the provider will process the charge again. Your internal idempotency key does not protect against this because the provider has already "forgotten" the previous request.
> 
> ### Conditions for Safety
> Retries are safe **only if** the total time from the initial attempt to the final retry remains **below the provider’s deduplication window** (typically 24 hours).
> 
> *   **Safe:** Retry logic with exponential backoff that caps total retry duration at, for example, 4 hours.
> *   **Unsafe:** Retry logic that allows a job to sit in a queue for 25 hours before being retried, or a backoff schedule that pushes the 5th retry past the 24-hour mark.
> 
> ### Actionable Recommendations
> 1.  **Cap Total Retry Time:** Do not rely solely on `max_retries`. Explicitly configure a **maximum total retry duration** for payment jobs that is significantly less than the provider’s window (e.g., cap at 4–6 hours if the provider window is 24 hours).
> 2.  **Monitor Queue Depth:** High queue depth can delay retries. If a job is stuck in the queue for >20 hours, it is at risk. Trigger alerts if payment job queue depth exceeds safe thresholds (e.g., the 1,000 pending jobs alarm mentioned in the source, though this is a general cluster metric, not payment-specific).
> 3.  **Verify Provider-Specific Windows:** Do not assume 24 hours for all providers. Check the specific deduplication window for each payment gateway you integrate with. Some may be shorter (e.g., 15 minutes) or longer.
> 4.  **Reconcile, Don’t Just Retry:** Implement a reconciliation process that checks the provider’s transaction history before retrying. If the provider shows a successful charge for the idempotency key, mark the job as complete, even if your local state says "failed."
> 
> ### Uncertainty and Omissions
> *   **Provider Variance:** The 24-hour window is a "typical" value from the source. Actual windows vary by provider and may change. **You must verify the specific window for each payment provider you use.**
> *   **No Live Check:** This analysis is based on stored research and documentation. No live testing of retry behavior against specific providers was performed.
> *   **Queue Behavior:** The source mentions a queue-depth alarm at 1,000 jobs, but does not specify how this interacts with payment job priority or aging. You must monitor the *age* of payment jobs in the queue, not just the count.
> 
> **Conclusion:** Retries are safe for payment jobs **only if** you enforce a total retry time cap that is strictly less than the payment provider’s deduplication window. Without this cap, retries are a direct cause of duplicate charges.

## Item f301bcf293622bce

**Question (w3):** What retry settings should we use for Tern agents on macOS?

**Obligations:**
- `defer-macos` (defer): No source covers macOS agents; say so and scope the answer.

**Answer:**

> I cannot provide specific retry settings for "Tern agents" on macOS because the supplied contributor material does not contain this information.
> 
> The single expert contributor, "oracle," is explicitly marked as providing "Stored research only; no live check was performed for this answer." However, the actual content of that stored research is not included in the prompt. There are no quoted sources, specific configuration values, code snippets, or documented mechanisms provided in the input to base a recommendation on.
> 
> Consequently:
> 1.  **No Mechanisms or Conditions:** There is no data to explain how Tern agents handle retries, what triggers them, or what specific macOS conditions (e.g., network state, process lifecycle) affect them.
> 2.  **No Alternatives:** Without knowing the current default or recommended settings, I cannot suggest alternatives.
> 3.  **No Verification:** I cannot verify any claims because no claims were supplied.
> 4.  **No Quantitative Analysis:** No thresholds, timeouts, or backoff factors were provided.
> 
> **Material Uncertainty and Omission:**
> The primary omission is the complete absence of the actual "stored research" content from the contributor. The prompt states that "oracle" has stored research, but does not provide the text of that research. Therefore, any specific recommendation (e.g., "use exponential backoff with a 5-second base") would be an invention not supported by the supplied evidence.
> 
> **Actionable Next Step:**
> To answer this question, you must provide the actual content of the "oracle" expert's stored research or documentation regarding Tern agent configuration. Specifically, look for:
> *   Default retry counts and intervals.
> *   Documentation on macOS-specific behavior (e.g., sleep/wake handling, network interface changes).
> *   Any vendor-recommended best practices for agent resilience.
> 
> Without this specific data, I cannot formulate a safe or accurate configuration recommendation.

## Item f3ec26895595b73e

**Question (w3):** On Tern 2 Windows agents, are idempotency keys on by default?

**Obligations:**
- `v2-default` (use): Yes: the change applies to 3.0 only.
- `v3-scope` (preserve): The 3.0 change does not apply to v2.

**Answer:**

> **Yes.** On Tern 2 Windows agents, idempotency keys are enabled by default.
> 
> **Mechanism and Evidence**
> The Tern 2 operations manual (Section 7) explicitly states that "idempotency keys are enabled by default on every agent platform." This includes Windows agents. The mechanism relies on every job carrying an idempotency key, which allows the worker to discard duplicate executions during retries. This default behavior ensures that retries (up to `max_retries` times with exponential backoff) are safe against duplicate side effects.
> 
> **Important Version Distinction**
> A stored finding regarding **Tern 3.0** indicates a breaking change where idempotency keys are *disabled* by default on Windows agents due to the optional nature of the Windows key store. However, this change does not apply to Tern 2. The question specifically concerns Tern 2, where the default remains **on**.
> 
> **Verification and Omissions**
> *   **Source:** The conclusion is derived from the retained passage in the Tern 2 operations manual (docs.tern.example).
> *   **Uncertainty:** This answer is based on stored research only; no live check was performed. If you are running a hybrid environment or have applied custom configuration overrides, verify your specific agent configuration, as defaults can be overridden by explicit settings.
> *   **Recommendation:** While keys are on by default in Tern 2, the manual recommends `max_retries = 5` for ordinary jobs to balance reliability and safety.

## Item f3f65a79eb19f257

**Question (w3):** What backoff cap should we configure for Tern?

**Obligations:**
- `vendor-view` (retain_conflict): Vendor: 60 seconds, hosted.
- `maintainer-view` (retain_conflict): Maintainer: 300 seconds, self-hosted; open.

**Answer:**

> There is no single universal backoff cap for Tern; the correct value depends on your deployment model and job type. Based on the available evidence, you should configure the cap as follows:
> 
> **1. For Self-Hosted Clusters: 300 Seconds**
> The maintainer of Tern suggests a **300-second** cap for self-hosted clusters. This recommendation stems from an incident where a 60-second cap amplified load during a regional outage. However, this is not a settled fact: the GitHub issue thread remains open, and no benchmark currently exists to definitively compare the 60-second and 300-second caps under identical conditions. If you are self-hosting, 300 seconds is the more conservative, maintainer-endorsed choice to prevent load amplification, but it is an unresolved recommendation rather than a verified optimum.
> 
> **2. For Vendor-Hosted Clusters: 60 Seconds**
> The vendor’s engineering blog recommends a **60-second** cap for their hosted clusters. They argue that longer caps leave queues idle during short outages. This measurement was performed exclusively on the vendor’s hosted infrastructure. If you are using the vendor’s hosted service, 60 seconds is the documented recommendation, but it may not translate to self-hosted environments where network latency and failure modes differ.
> 
> **3. Critical Constraint for Payment Jobs: Cap Total Retry Time**
> Regardless of the per-retry backoff cap, if your jobs call external payment providers, you must ensure the **total retry time** (backoff + execution time across all retries) remains below the provider’s deduplication window (typically 24 hours). Even with idempotency keys enabled, providers only deduplicate within their own window. A retry landing after this window can result in double charges. Therefore, for payment jobs, the backoff cap must be low enough that `max_retries` (recommended as 5) does not push the total elapsed time beyond 24 hours.
> 
> **Safety Context: Idempotency Keys**
> Retries are safe only if idempotency keys are enabled.
> *   **Linux/Container Agents (Tern 2 & 3.0):** Keys are enabled by default. Retries are safe.
> *   **Windows Agents (Tern 3.0):** Keys are **disabled** by default. Retries are **unsafe** for jobs with side effects unless you explicitly enable `idempotency_keys` or set `max_retries = 0`. If you are using Windows agents in Tern 3.0, do not rely on the default backoff configuration for side-effectful jobs without first enabling keys.
> 
> **Recommendation**
> *   **Self-Hosted:** Configure a **300-second** backoff cap.
> *   **Vendor-Hosted:** Configure a **60-second** backoff cap.
> *   **Payment Jobs:** Verify that `5 retries * (backoff cap + avg job duration)` is significantly less than 24 hours.
> *   **Windows (Tern 3.0):** Explicitly enable `idempotency_keys` or set `max_retries = 0` for side-effectful jobs.
> 
> **Material Uncertainty**
> The 300-second recommendation for self-hosted clusters is based on a maintainer’s anecdotal observation of an outage, not a controlled benchmark. The 60-second recommendation is vendor-specific. No independent test confirms which cap is superior for a given self-hosted topology. Additionally, the "safe" status of retries on Windows agents in Tern 3.0 is conditional on manual configuration; the default state is unsafe for side effects.

