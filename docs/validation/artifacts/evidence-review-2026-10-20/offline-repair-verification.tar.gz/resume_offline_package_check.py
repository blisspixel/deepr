"""Resume after an observed missing public package cache entry, preserving locks."""
from pathlib import Path
import hashlib,json,os,subprocess,time
from zipfile import ZipFile
R=Path('/home/pueo/Work/deepr');T=Path(__file__).resolve().parent;E=T/'offline-package-check-v2';V=E/'core installed';W=E/'working';UV=R/'.agent/dependency-audit-2026-10-20/uv-tool/bin/uv'
wheel=E/'dist/deepr_research-2.50.43-py3-none-any.whl'
env={k:v for k,v in os.environ.items() if k in ('PATH','HOME','LANG','LC_ALL')}
env.update(PATH=str(V/'bin')+':'+env['PATH'],PYTHON_DOTENV_DISABLED='1',DEEPR_ENV_FILE=str(W/'absent.env'),DEEPR_DATA_DIR=str(W/'data'),DEEPR_EXPERTS_PATH=str(W/'experts'),DEEPR_REPORTS_PATH=str(W/'reports'),DEEPR_COST_DATA_DIR=str(W/'costs'),DEEPR_QUEUE_DB_PATH=str(W/'queue.db'),DEEPR_BUDGET_FILE=str(W/'budget.json'),PYYAML_FORCE_LIBYAML='0')
checks=json.loads((E/'checks.json').read_text());assert checks['build']['exit']==checks['frontend-package']['exit']==checks['core-venv']['exit']==0 and checks['core-install']['exit']!=0
with ZipFile(wheel) as archive:
 for name in ('deepr/experts/consult_response.py','deepr/evals/correction_survival_review.py','deepr/experts/brief_selection.py'):assert archive.read(name)==(R/'src'/name).read_bytes()
def run(label,args,cwd=W):
 log=E/(label+'.log');started=time.monotonic()
 with log.open('x') as f:result=subprocess.run([str(v) for v in args],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 checks[label]={'command':[str(v) for v in args],'cwd':str(cwd),'exit':result.returncode,'seconds':round(time.monotonic()-started,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 (E/'checks-resumed.json').write_text(json.dumps(checks,indent=2)+'\n');print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
run('core-install-pinned-public',[UV,'pip','install','--python',V/'bin/python','--default-index','https://pypi.org/simple','--constraint',E/'core-constraints.txt',wheel])
run('identity',[V/'bin/python','-I','-c',"import deepr,sys;from pathlib import Path;print(sys.version);print(deepr.__file__);assert deepr.__version__=='2.50.43';assert 'site-packages' in Path(deepr.__file__).parts;import deepr.experts.consult_response,deepr.evals.correction_survival_review"])
run('conformance',[V/'bin/deepr','mcp','conformance','--json'])
run('plugin-stdio',[V/'bin/python',R/'scripts/check_agent_plugin_install.py','--package-root',R/'packages/deepr-agent-plugin','--data-root',E/'plugin data','--command',V/'bin/deepr-mcp'])
run('host-profile',[V/'bin/python',R/'scripts/check_host_profile_install.py','--fixture',R/'tests/fixtures/hosts/openclaw/v2026.7.1-2/profile.json','--data-root',E/'host data','--mcp-command',V/'bin/deepr-mcp','--deepr-command',V/'bin/deepr'])
(E/'receipt.json').write_text(json.dumps({'candidate_only':True,'published_release_claim':False,'version_metadata':'2.50.43','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'source_manifest_sha256':hashlib.sha256((E/'source-manifest.json').read_bytes()).hexdigest(),'checks':checks,'initial_environment_failures':'Unisolated full/dev environment lacks setuptools; corrected to declared isolated uv build. Offline clean install lacked pinned charset-normalizer3.4.9; fetched exact locked requirements from public PyPI without changing constraints. Failed logs preserved.','paid_provider_calls':0,'native_generations':0},indent=2)+'\n')
print('Unreleased core wheel packaging, conformance, stdio and host checks passed.',flush=True)
