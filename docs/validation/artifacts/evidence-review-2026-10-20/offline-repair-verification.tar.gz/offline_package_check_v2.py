"""Build and inspect an unreleased candidate wheel, never a release artifact."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
from zipfile import ZipFile
R=Path('/home/pueo/Work/deepr');T=Path(__file__).resolve().parent;E=T/'offline-package-check-v2';E.mkdir(exist_ok=False)
S=E/'source';S.mkdir();V=E/'core installed';W=E/'working';W.mkdir();UV=R/'.agent/dependency-audit-2026-10-20/uv-tool/bin/uv';PY=R/'.venv/bin/python'
env={k:v for k,v in os.environ.items() if k in ('PATH','HOME','LANG','LC_ALL')}
env.update(PATH=str(R/'.venv/bin')+':'+env['PATH'],PYTHON_DOTENV_DISABLED='1',DEEPR_ENV_FILE=str(W/'absent.env'),DEEPR_DATA_DIR=str(W/'data'),DEEPR_EXPERTS_PATH=str(W/'experts'),DEEPR_REPORTS_PATH=str(W/'reports'),DEEPR_COST_DATA_DIR=str(W/'costs'),DEEPR_QUEUE_DB_PATH=str(W/'queue.db'),DEEPR_BUDGET_FILE=str(W/'budget.json'),PYYAML_FORCE_LIBYAML='0')
paths=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0');paths=[p for p in paths if p]
paths+=['src/deepr/evals/correction_survival_review.py','src/deepr/experts/consult_response.py','tests/unit/test_evals/test_correction_survival_evidence.py']
source_hashes={}
for name in paths:
    assert not name.startswith(('research_notes/','.agent/','.git/'))
    source=R/name;assert source.is_file() and not source.is_symlink(),name
    target=S/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    source_hashes[name]=hashlib.sha256(target.read_bytes()).hexdigest()
(E/'source-manifest.json').write_text(json.dumps({'meaning':'Unreleased working-tree candidate, metadata remains2.50.43; not published v2.50.43 source. Export uses only tracked files and three explicit intended new files, never unrelated research notes.','files':source_hashes},indent=2)+'\n')
checks={}
def run(label,args,cwd=W):
    log=E/(label+'.log');started=time.monotonic()
    with log.open('x') as f:result=subprocess.run([str(v) for v in args],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    checks[label]={'command':[str(v) for v in args],'cwd':str(cwd),'exit':result.returncode,'seconds':round(time.monotonic()-started,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    (E/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(label,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
run('locked-core-constraints',[UV,'export','--frozen','--offline','--no-dev','--no-emit-project','--no-hashes','--format','requirements-txt','--output-file',E/'core-constraints.txt'],S)
run('build',[UV,'build','--offline','--python',PY,'--out-dir',E/'dist'],S)
wheel=E/'dist/deepr_research-2.50.43-py3-none-any.whl';sdist=E/'dist/deepr_research-2.50.43.tar.gz'
run('frontend-package',[PY,R/'scripts/check_wheel_frontend.py',wheel,sdist])
with ZipFile(wheel) as archive:
    for name in ('deepr/experts/consult_response.py','deepr/evals/correction_survival_review.py','deepr/experts/brief_selection.py'):
        assert archive.read(name)==(R/'src'/name).read_bytes(),name
run('core-venv',[UV,'venv','--python',PY,V])
run('core-install',[UV,'pip','install','--offline','--python',V/'bin/python','--constraint',E/'core-constraints.txt',wheel])
run('identity',[V/'bin/python','-I','-c',"import deepr,sys;from pathlib import Path;print(sys.version);print(deepr.__file__);assert deepr.__version__=='2.50.43';assert 'site-packages' in Path(deepr.__file__).parts;import deepr.experts.consult_response,deepr.evals.correction_survival_review"])
run('conformance',[V/'bin/deepr','mcp','conformance','--json'])
run('plugin-stdio',[V/'bin/python',R/'scripts/check_agent_plugin_install.py','--package-root',R/'packages/deepr-agent-plugin','--data-root',E/'plugin data','--command',V/'bin/deepr-mcp'])
run('host-profile',[V/'bin/python',R/'scripts/check_host_profile_install.py','--fixture',R/'tests/fixtures/hosts/openclaw/v2026.7.1-2/profile.json','--data-root',E/'host data','--mcp-command',V/'bin/deepr-mcp','--deepr-command',V/'bin/deepr'])
(E/'receipt.json').write_text(json.dumps({'candidate_only':True,'published_release_claim':False,'version_metadata':'2.50.43','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'source_manifest_sha256':hashlib.sha256((E/'source-manifest.json').read_bytes()).hexdigest(),'checks':checks,'paid_provider_calls':0,'native_generations':0},indent=2)+'\n')
print('Unreleased core wheel packaging, conformance, stdio and host checks passed.',flush=True)
