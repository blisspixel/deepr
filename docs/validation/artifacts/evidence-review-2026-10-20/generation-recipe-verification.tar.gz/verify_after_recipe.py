"""Record checks on the exact candidate with frozen environments."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
T=Path(__file__).resolve().parent/'recipe-verification';T.mkdir(exist_ok=True);ROOT=Path('/home/pueo/Work/deepr');D=ROOT/'.agent/dependency-audit-2026-10-20'
PY=ROOT/'.venv/bin/python';NODE='/home/pueo/.local/share/mise/installs/node/24.22.0/bin'
ENV={k:v for k,v in os.environ.items() if k in ('HOME','LANG','LC_ALL','PATH')};ENV['PATH']=f"{ROOT/'.venv/bin'}:{D/'node-tools/node_modules/.bin'}:{NODE}:"+ENV['PATH'];ENV['PYTHON_DOTENV_DISABLED']='1'
ISLANDS='core providers mcp security queue storage tools routing worker webhooks a2a skills backends agents evals observability services'.split()
def run(label,args,env=ENV,cwd=ROOT):
 log=T/(label+'.log');assert not log.exists(),label
 start=time.monotonic()
 with log.open('w') as out:r=subprocess.run([str(v) for v in args],cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 (T/(label+'.json')).write_text(json.dumps({'command':[str(v) for v in args],'cwd':str(cwd),'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2)+'\n')
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
mode=sys.argv[1]
if mode=='gates':
 for label,args in [('ruff',['-m','ruff','check','src/deepr/']),('format',['-m','ruff','format','--check','src/deepr/']),('size',['scripts/check_file_sizes.py']),('ratchets',['scripts/check_ratchets.py']),('paid',['scripts/check_paid_api_boundaries.py']),('docs',['scripts/check_docs_consistency.py'])]:run(label,[PY,*args])
elif mode=='unit':
 tmp=T/'unit-tmp';tmp.mkdir(exist_ok=False);env=dict(ENV,TMPDIR=str(tmp),COVERAGE_FILE=str(T/'candidate.coverage'))
 run('unit',[PY,'-m','pytest','tests/unit/','--ignore=tests/data','-q','--cov=deepr','--cov-report=term'],env=env)
 run('coverage',[PY,'-m','coverage','report'],env=env)
elif mode in ('native','floor'):
 python=PY if mode=='native' else D/'floor-venv/bin/python'
 run(mode+'-identity',[python,'-c',"import sys,deepr,importlib.metadata; print(sys.version); print(deepr.__file__); assert deepr.__version__==importlib.metadata.version('deepr-research')=='2.50.44'"])
 run(mode+'-audit',[python.parent/'pip-audit','--skip-editable'])
 run(mode+'-strict',[PY,'-m','mypy',*(['--python-version','3.15'] if mode=='native' else ['--python-executable',str(python)]),'--strict','--no-warn-unused-ignores','--ignore-missing-imports',*['src/deepr/'+v for v in ISLANDS]])
