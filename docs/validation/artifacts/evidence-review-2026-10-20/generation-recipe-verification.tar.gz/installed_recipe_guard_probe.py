"""Exercise the recipe boundary from installed bytes, using mocked answers only."""
import asyncio,hashlib,json,sys,tempfile
from pathlib import Path
from deepr.evals import correction_survival as cs
assert 'site-packages' in Path(cs.__file__).parts
original_file=cs.__file__;installed_root=Path(original_file).resolve().parents[2]
mutations=[('deepr/experts/council.py','_LOCAL_SYNTHESIS_OUTPUT_TOKENS = 8000','_LOCAL_SYNTHESIS_OUTPUT_TOKENS = 7999'),('deepr/experts/council_synthesis_runtime.py','LOCAL_SYNTHESIS_CONTEXT_TOKENS = 16384','LOCAL_SYNTHESIS_CONTEXT_TOKENS = 8192'),('deepr/evals/correction_survival_local.py','user_prompt=prompt,','user_prompt=prompt + "changed",')]
proof=[]
with tempfile.TemporaryDirectory(prefix='deepr-installed-recipe-') as temporary:
 root=Path(temporary);overlay=root/'source'
 for relative in cs._RECIPE_MODULES:
  target=overlay/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((installed_root/relative).read_bytes())
 cs.__file__=str(overlay/'deepr/evals/correction_survival.py')
 try:
  case=next(case for case in cs.CASES if case.case_id=='historical');runroot=root/'run';run=asyncio.run(cs.run_diagnostic(runroot,cases=(case,),code_identity='Unreleased installed-wheel mock recipe verification'))
  pin=run['recipe_sha256'];before={str(p.relative_to(runroot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in runroot.rglob('*') if p.is_file()}
  for owner,old,new in mutations:
   target=overlay/owner;raw=target.read_bytes();text=raw.decode();assert old in text;target.write_text(text.replace(old,new,1),encoding='utf-8')
   assert cs.recipe_sha256()!=pin
   try:cs.load_run(runroot)
   except cs.RunNotReusableError:pass
   else:raise AssertionError('Changed installed generation recipe admitted')
   restored=cs.load_run(runroot,expected_recipe_sha256=pin);assert cs.build_report(restored)['recipe_matches_current'] is False
   assert {str(p.relative_to(runroot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in runroot.rglob('*') if p.is_file()}==before
   proof.append({'owner':owner,'changed_current_recipe_refused':True,'explicit_read_only_original_pin_succeeded':True,'artifacts_unchanged':True});target.write_bytes(raw)
 finally:cs.__file__=original_file
Path(sys.argv[1]).write_text(json.dumps({'installed_from':original_file,'owned_modules':len(cs._RECIPE_MODULES),'current_recipe_sha256':cs.recipe_sha256(),'mutations':proof,'real_model_calls':0,'paid_provider_calls':0,'unreleased_candidate_only':True},indent=2)+'\n');print('Installed recipe mutation and historical pin guards passed with no model calls.')
