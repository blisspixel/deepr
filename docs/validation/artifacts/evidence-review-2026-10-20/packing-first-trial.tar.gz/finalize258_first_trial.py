"""Freeze qualified blinded labels before opening original comparison key."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
import hashlib,json,os
T=Path(__file__).resolve().parent;D=T/'packing-fixtures-v3';h=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
f=json.loads((T/'review258-complete-independent-freeze.json').read_text());a={};key=lambda r:(r['item_id'],r['obligation_id'])
for w in ('R1','R2'):
 p=T/f'reviewers/{w}/review258-complete-sources.json';assert h(p.read_bytes())==f['reviewer_sha256'][w];a[w]={key(r):r for r in json.loads(p.read_text())}
c={key(r):r for r in json.loads((T/'reviewers/R3/review258-complete-adjudication.json').read_text())};assert set(c)=={k for k in a['R1'] if a['R1'][k]['label']!=a['R2'][k]['label']}
packet={i['item_id']:i for i in json.loads((T/'review258-complete-sources-packet.json').read_text())};labels=[]
for k in sorted(a['R1']):
 r=dict(c.get(k,a['R1'][k]));item=packet[k[0]];assert r['answer_sha256']==item['answer_sha256'];assert not r['answer_quote'] or r['answer_quote'] in item['answer'];assert set(r['source_ids'])<={s['source_id'] for s in item['sources']};r['reviewer']='R3 blind adjudication' if k in c else 'R1+R2';r['reviewer_notes']={w:a[w][k]['note'] for w in a};labels.append(r)
assert len(labels)==36
write(T/'review258-first-final-labels.json',labels)
write(T/'review258-first-final-blind-freeze.json',{'frozen_at':datetime.now(timezone.utc).isoformat(),'labels_sha256':h((T/'review258-first-final-labels.json').read_bytes()),'labels':36,'agreements':33,'blind_adjudications':3,'assignment_key_opened':False,'fixture_audit_sha256':h((T/'reviewers/R3/fixture258-complete-source-audit.json').read_bytes()),'accepted_clean_policy_contrast':False,'limits':'Planning-note scope ambiguity, delivery-dependent renewal branch lacks delivered-context evidence, warning-vs-disagreement ambiguity and one truncated brief. Qualified descriptive labels only; preserve first incomplete-source judgments separately.'})
# All labels, rationales and limiting fixture audit durable before first key read.
p=D/'assignment-key-unopened/key.json';assign=json.loads(p.read_text());assert set(assign)==set(packet)
pairs=defaultdict(dict)
for iid,item in packet.items():
 info=assign[iid];rows=[r for r in labels if r['item_id']==iid];pairs[info['pair']][info['arm']]={'item_id':iid,'status':item['status'],'answer_sha256':item['answer_sha256'],'labels':{r['obligation_id']:r['label'] for r in rows},'notes':{r['obligation_id']:r['note'] for r in rows}}
assert len(pairs)==8 and all(set(x)=={'old','current'} for x in pairs.values())
report={'key_opened_at':datetime.now(timezone.utc).isoformat(),'labels_frozen_before_key':True,'assignment_key_sha256':h(p.read_bytes()),'scheduled_answers':16,'completed_answers':15,'truncated_answers':1,'reviewed_obligations':36,'accepted_clean_policy_contrast':False,'pairs':dict(pairs),'limits':'Do not infer a policy winner or accept #258 from this first flawed contrast. Original generated inputs/answers and both review rounds preserved. Prospectively clarify source/obligation scope and expose delivered evidence before any new collection.'}
write(T/'review258-first-reviewed-comparison.json',report)
print(json.dumps({name:{arm:{'status':r['status'],'labels':r['labels']} for arm,r in pair.items()} for name,pair in pairs.items()},indent=2))
