"""Repair reviewer evidence without altering generation, answers or initial judgments."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
T=Path(__file__).resolve().parent;D=T/'packing-fixtures-v3';h=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
entries=[json.loads(line) for line in (D/'corpus/index.jsonl').read_text().splitlines()][1:]
by_sha={row['sha256']:row for row in entries};by_origin={row['origin_key']:row for row in entries}
packet=json.loads((D/'blinded-review.json').read_text());completed=[]
def source(entry,sid):
 sha=entry['sha256'];p=D/'corpus/sources'/sha[:2]/(sha+'.md');raw=p.read_bytes();assert h(raw)==sha
 return {'source_id':sid,'text':raw.decode('utf-8'),'text_sha256':sha,'origin_key':entry['origin_key'],'trust_class':entry['trust_class'],'observed_at':entry['fetched_at']}
for item in packet:
 sources=[source(by_sha[h(s['text'].encode())],s['source_id']) for s in item['sources']]
 if item['kind']=='consult':
  for i in range(14):sources.append(source(by_origin[f'filler-{i}.example'],f'filler-{i}'))
  assert len(sources)==19
 else:assert len(sources) in (16,156)
 assert len({s['source_id'] for s in sources})==len(sources)
 completed.append(item|{'sources':sources})
write(T/'review258-complete-sources-packet.json',completed)
write(T/'review258-source-handoff-repair-receipt.json',{'exported_at':datetime.now(timezone.utc).isoformat(),'assignment_key_opened':False,'initial_packet_sha256':h((D/'blinded-review.json').read_bytes()),'complete_packet_sha256':h((T/'review258-complete-sources-packet.json').read_bytes()),'answers_unchanged':16,'obligations_unchanged':36,'consult_source_inventory':'Five primary decision sources plus all14tertiary planning-note distractors; exact retained bytes and metadata, checked against corpus index. Brief sources were already complete and verified.','initial_reviews':'R1/review258.json and R2/review258.json remain frozen, superseded as final acceptance because source handoff was incomplete. Initial31/36agreement and5disagreements retained. R3 stopped before writing initial adjudications.','reproducibility_limit':'Same independent reviewers re-read with complete sources, so carryover from their initial incomplete review is possible. No new answer generation, source alteration, obligation change or key access.'})
print('Source-complete packet exported, all16answers/36obligations unchanged; key withheld.')
