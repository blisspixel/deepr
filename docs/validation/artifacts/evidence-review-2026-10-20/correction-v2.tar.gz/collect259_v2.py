"""Prospectively bounded fresh v2 collection through production local dispatch."""
import asyncio, hashlib, json, os, time
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path('/home/pueo/Work/deepr'); T=Path(__file__).resolve().parent
safe={k:v for k,v in os.environ.items() if k in ('PATH','HOME','LANG','LC_ALL')}
safe.update(PYTHON_DOTENV_DISABLED='1',DEEPR_ENV_FILE=str(T/'absent.env'),DEEPR_DATA_DIR=str(T/'runtime/data'),DEEPR_EXPERTS_PATH=str(T/'runtime/experts'),DEEPR_REPORTS_PATH=str(T/'runtime/reports'),DEEPR_COST_DATA_DIR=str(T/'runtime/costs'),TMPDIR=str(T/'tmp'))
os.environ.clear();os.environ.update(safe)
from filelock import FileLock
from deepr.evals import correction_survival as cs
from deepr.evals.correction_survival_cases import CASES, CASE_SET_VERSION, case_set_sha256
from deepr.evals.correction_survival_local import LocalAnswerer
from deepr.experts.council import LOCAL_SYNTHESIS_OUTPUT_TOKENS, SYNTHESIS_SYSTEM_PROMPT
from deepr.experts.council_synthesis_runtime import LOCAL_SYNTHESIS_CONTEXT_TOKENS
from deepr.utils.atomic_io import atomic_write_json
h=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):atomic_write_json(p,x,fsync=True,overwrite=False)
def now():return datetime.now(timezone.utc).isoformat()

async def main():
 assert (T/'packing-fixtures-v3/answers-complete.json').exists(), 'No simultaneous real model jobs'
 candidate=json.loads((T/'v2-fixture-candidate-final.json').read_text()); audit=json.loads((T/'reviewers/R3/v2-fixture-audit-final.json').read_text())
 assert audit['admitted'] is True
 assert h((T/'v2-fixture-candidate-final.json').read_bytes())==audit['candidate_file_sha256_computed']
 assert case_set_sha256()==audit['case_set_sha256_declared']
 assert cs.recipe_sha256()==audit['recipe_sha256_declared']
 protocol=json.loads((T/'review-protocol.json').read_text())
 generator={'model':'qwen3.8:27b','digest':'aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813','timeout_seconds':600,'num_ctx':LOCAL_SYNTHESIS_CONTEXT_TOKENS,'output_tokens':LOCAL_SYNTHESIS_OUTPUT_TOKENS,'temperature':0.3,'think':False,'seed':'production default, unspecified'}
 paths=list(cs._RECIPE_MODULES)+['deepr/evals/correction_survival_local.py','deepr/experts/council.py','deepr/experts/council_synthesis_runtime.py']
 hashes={p:h((ROOT/'src'/p).read_bytes()) for p in paths}
 freeze={'frozen_at':now(),'source_commit':'47bd37b4079054b6bf7fd6508ca199a491ec5c2a','code_identity':'deepr 2.50.43 editable prospective v2 patch on 47bd37b; exact module hashes retained','case_set_version':CASE_SET_VERSION,'case_set_sha256':case_set_sha256(),'recipe_sha256':cs.recipe_sha256(),'fixture_audit_sha256':h((T/'reviewers/R3/v2-fixture-audit-final.json').read_bytes()),'module_sha256':hashes,'generator':generator,'system_prompt_sha256':h(SYNTHESIS_SYSTEM_PROMPT.encode()),'scheduled_attempts':36,'obligations':60,'distractors':0,'routing':'production lexical default; no embedding contrast','arms':list(cs.ARMS),'materialization':'fixed fixture brief synthesis; no inference during study or maintenance','repeated_compression':'two cycles over unchanged fixture evidence, not a learned update loop','global_call_ceiling':100,'original_global_wall_start':protocol['created_at'],'global_wall_seconds':10800,'paid_api_ceiling':0,'automatic_retry':False,'predeclared_acceptance':'Complete bounded measurement, immutable identities, source-grounded blinded labels and all terminal attempts. Negative results valid. No performance threshold, S0 acceptance or default promotion.'}
 write(T/'review259-v2-policy-freeze.json',freeze)
 snap=T/'v2-source-snapshot';snap.mkdir(exist_ok=False)
 for p in paths:
  target=snap/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/'src'/p).read_bytes())
 answerer=LocalAnswerer(generator['model'],digest=generator['digest'],timeout_seconds=600);await answerer.attest()
 class BudgetedAnswerer:
  @property
  def calls(self):return answerer.calls
  async def __call__(self,prompt):
   assert all(h((ROOT/'src'/p).read_bytes())==sha for p,sha in hashes.items()),'recipe changed mid-run'
   with FileLock(str(T/'call-budget.lock')):
    count=len(list((T/'calls').glob('*.request.json')))
    assert count<100
    assert (datetime.now(timezone.utc)-datetime.fromisoformat(protocol['created_at'])).total_seconds()<10800
    request=T/'calls'/f'{count+1:03d}.answer259v2.request.json'
    write(request,{'phase':'answer259v2','generator':generator,'system':SYNTHESIS_SYSTEM_PROMPT,'user':prompt,'policy_sha256':h((T/'review259-v2-policy-freeze.json').read_bytes()),'created_at':now()})
   started=time.perf_counter()
   try:
    answer=await answerer(prompt)
    record={'answer':answer,'answer_sha256':h(answer.encode()),'dispatch':answerer.calls[-1],'status':'returned','elapsed_s':time.perf_counter()-started}
    write(request.with_name(request.name.replace('.request.json','.response.json')),record)
    if answerer.calls[-1].get('stop_reason')=='length':raise RuntimeError('truncated answer retained in call response')
    return answer
   except Exception as error:
    response=request.with_name(request.name.replace('.request.json','.response.json'))
    if not response.exists():write(response,{'status':'failed','error_type':type(error).__name__,'error':str(error),'elapsed_s':time.perf_counter()-started})
    raise
 def progress(attempt,done,total):print(f'Fresh v2 answer {done}/{total}: {attempt["status"]}',flush=True)
 run=await cs.run_diagnostic(T/'correction-survival-v2',completion=BudgetedAnswerer(),code_identity=freeze['code_identity'],model_identity=answerer.identity,on_attempt=progress)
 assert len(run['attempts'])==36
 cs.load_run(T/'correction-survival-v2')
 import secrets
 items,key=cs.blinded_review_packet(run,salt=secrets.token_hex(32))
 private=T/'review259-v2-key-unopened';private.mkdir(mode=0o700);write(private/'key.json',key);(private/'key.json').chmod(0o600)
 by_id={a['attempt_id']:a for a in run['attempts']};packet=[]
 for item in items:
  attempt=by_id[key[item['item_id']]]
  answer=json.loads((T/'correction-survival-v2/attempts'/attempt['attempt_id']/'answer.json').read_text())['answer']
  assert h(answer.encode())==item['answer_sha256']
  packet.append(item|{'answer':answer})
 write(T/'review259-v2-blinded-packet.json',packet)
 write(T/'review259-v2-collection-receipt.json',{'completed_at':now(),'run_sha256':h((T/'correction-survival-v2/run.json').read_bytes()),'packet_sha256':h((T/'review259-v2-blinded-packet.json').read_bytes()),'scheduled_answers':36,'terminal_answers':len(run['attempts']),'reviewable_answers':len(packet),'completed':sum(a['status']=='completed' for a in run['attempts']),'failed':sum(a['status']!='completed' for a in run['attempts']),'assignment_key_opened_for_review':False,'module_hashes_unchanged':all(h((ROOT/'src'/p).read_bytes())==sha for p,sha in hashes.items())})
 print('Fresh v2 collection complete; review assignment key withheld.',flush=True)

if __name__=='__main__':
 with FileLock(str(T/'runner.lock'),timeout=0):asyncio.run(main())
