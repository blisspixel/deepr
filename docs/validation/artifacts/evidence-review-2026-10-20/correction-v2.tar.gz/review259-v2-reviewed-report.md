# Correction survival diagnostic (correction-survival-v2)

- Model: local:qwen3.8:27b@aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813; paid calls: 0; distractor sources per world: 0; configured finding routing: lexical
- Cases: full set; attempts: 36 of 36 scheduled; reviewed obligations: 60
- Recorded code: deepr 2.50.43 editable prospective v2 patch on 47bd37b; exact module hashes retained; recorded recipe: de5d1978bfe53439c5da032abdd4b986603d4697a00469de23b7331a82af4f84
- Current recipe: c9057fff3aced4f39caada27c6c7a01fd431e4872268780451183a67ae108521; recorded/current match: False (None means unknown).

## production
12 completed, 0 failed, 107979 prompt characters
Elapsed ms: answer 1526114.859, routing 0.0, total attempt 1526133.952 (None means unknown).
Effective routes: {'lexical': 12}; routing states: {'not_configured': 12}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, presented 18 |
| retrieval | not_applicable 2, selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | appropriately_deferred 1, used_correctly 19 |

## oracle_packet
12 completed, 0 failed, 33645 prompt characters
Elapsed ms: answer 1503158.298, routing 0.0, total attempt 1503161.078 (None means unknown).
Effective routes: {'not_used_by_arm': 12}; routing states: {'not_used_by_arm': 12}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, represented 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, oracle_selected 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | misapplied 4, used_correctly 16 |

## fresh_sources
12 completed, 0 failed, 45576 prompt characters
Elapsed ms: answer 1470356.774, routing 0.0, total attempt 1470363.042 (None means unknown).
Effective routes: {'not_used_by_arm': 12}; routing states: {'not_used_by_arm': 12}; embedding calls: 0 (0 with unknown token usage, 0 with unsettled accounting).

| Stage | States |
|---|---|
| source | not_applicable 2, present 18 |
| study | not_applicable 2, not_used_by_arm 18 |
| briefing | not_applicable 2, not_used_by_arm 18 |
| retrieval | not_applicable 2, provided 18 |
| delivery | delivered 18, not_applicable 2 |
| answer | appropriately_deferred 1, misapplied 1, used_correctly 18 |

Historical isolation: 3 isolated, 0 leaked.

Mechanical stage receipts only. Answer use is unreviewed unless a bound label says otherwise. Mock answers establish transport and accounting, not answer quality. elapsed_ms is answer-only; total_elapsed_ms includes routing and packet assembly through the answer, excluding shared world/study/brief setup and artifact writes. Legacy routing/total timing is unknown.
