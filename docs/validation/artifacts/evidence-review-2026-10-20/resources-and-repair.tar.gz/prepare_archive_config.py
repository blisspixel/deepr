"""Prepare an explicit allowlist after final blind review and material assessment."""
from pathlib import Path
import json
R=Path('/home/pueo/Work/deepr');T=Path(__file__).resolve().parent
assert json.loads((T/'review258-pair-quality-final-blind-freeze.json').read_text())['all_three_reviews_frozen_before_key'] is True
archives={k:{} for k in ('protocol-and-review.tar.gz','correction-v1.tar.gz','correction-v2.tar.gz','packing-trials.tar.gz','resources-and-repair.tar.gz')}
def put(archive,path,member=None):
 path=Path(path);assert path.is_file() and not path.is_symlink();name=member or str(path.relative_to(T));assert name not in archives[archive];archives[archive][name]=str(path)
def tree(archive,path,prefix):
 assert path.is_dir()
 for p in sorted(path.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   assert not p.is_symlink();put(archive,p,prefix+'/'+str(p.relative_to(path)))
def names(archive,items):
 for name in items.split():put(archive,T/name)
for pattern in ('*calibration*.json','calibration*.log','review-protocol*.json','review-instructions*.txt'):
 for p in sorted(T.glob(pattern)):put('protocol-and-review.tar.gz',p)
tree('protocol-and-review.tar.gz',T/'reviewers','reviewers')
names('protocol-and-review.tar.gz','comparison-review-admission.json prepare_agent_calibration.py prepare_review.py prepare_review_v2.py review_runner.py review_runner_v2.py runner-freeze.json runner-freeze-v2.json compare_final_reviews.py finalize_review.py')
O=R/'.agent/correction-survival-2026-10-19';tree('correction-v1.tar.gz',O/'local-d0','original-run')
for name in ('review-packet.md','labels-template.json','review-key-DO-NOT-OPEN-BEFORE-LABELS/key.json','local-d0.progress.log','local-d0.report.json'):put('correction-v1.tar.gz',O/name,'original/'+name)
for pattern in ('review259-v1-*','review259-final-*','review259-frozen-*','review259-independent-*','review259-source-*','review259-adjudication-*','review259-disagreements.json'):
 for p in sorted(T.glob(pattern)):put('correction-v1.tar.gz',p)
names('correction-v1.tar.gz','retained259-before-review.json v1-recipe-release-provenance.json export_source_appendix.py finalize259_v1.py')
tree('correction-v2.tar.gz',T/'correction-survival-v2','original-run');tree('correction-v2.tar.gz',T/'v2-source-snapshot','collection-source-snapshot');tree('correction-v2.tar.gz',T/'review259-v2-key-unopened','assignment-key-after-freeze')
for p in sorted(T.glob('review259-v2-*')):
 if p.is_file():put('correction-v2.tar.gz',p)
names('correction-v2.tar.gz','collect259_v2.py issue259-semantic-assessment.json v2-fixture-candidate.json v2-fixture-candidate-final.json v2-collector-identity-observation.json answers259-v2.log')
for folder in ('packing-fixtures','packing-fixtures-v2','packing-fixtures-v3','packing-fixtures-v4'):tree('packing-trials.tar.gz',T/folder,folder)
put('packing-trials.tar.gz',R/'.agent/evidence-delivery-2026-10-19/old_consult_prompt.py','legacy-source/consult_prompt.py')
manifest=json.loads((T/'packing-fixtures-v4/manifest.json').read_text())
import hashlib
for path,sha in manifest['current_modules'].items():
 source=T/'packing-v4-source-snapshot'/path;assert hashlib.sha256(source.read_bytes()).hexdigest()==sha;put('packing-trials.tar.gz',source,'current-source/'+path)
tree('packing-trials.tar.gz',T/'brief-assembly-probe','brief-assembly-probe')
for p in sorted(T.glob('review258*')):
 if p.is_file():put('packing-trials.tar.gz',p)
names('packing-trials.tar.gz','packing-v4-source-reconstruction-receipt.json original_brief.py packing_fixtures.py packing_fixtures_v2.py packing_fixtures_v3.py packing_fixtures_v4.py prepare_packing_v4.py packing-v4-precollection-audit-inputs.json packing-v4-runner-freeze.json packing-v4-orchestrator.log answer_runner.py answer_runner_v3.py answer_runner_v4.py answer-runner-freeze.json answer-runner-freeze-v3.json export258_complete_sources.py finalize258_first_trial.py issue258-semantic-assessment.json audit_brief_assembly.py brief-assembly-receipt.json prepare_pair_quality.py finalize_pair_quality.py answers258.log answers258-v4.log')
tree('resources-and-repair.tar.gz',T/'calls','native-calls')
put('resources-and-repair.tar.gz',T/'runtime/costs/cost_ledger.jsonl','native-cost-ledger.jsonl')
tree('resources-and-repair.tar.gz',T/'final-source-snapshot','repair-source-snapshot')
names('resources-and-repair.tar.gz','native-resource-audit.json native-request-ledger-join-audit.json audit_native_resources.py build_evidence_archive.py prepare_archive_config.py review-evidence-regression-before.log review-evidence-regression-before.json distractor-review-before-fix.log distractor-review-before-fix.json distractor-review-missing-inventory-before-fix.log artifact-newlines-before-fix.log source-substitution-before-fix.log handoff-inventory-focused.log handoff-inventory-strict.log root-handoff-focused.log handoff-inventory-final.patch handoff-inventory-final-patch-freeze.json handoff-root-application-receipt.json final-method-wording-receipt.json final-method-wording-receipt-v2.json final-executable-identity.json final-source-mock60-receipt.json final-source-mock60-report.json probe_final_source.py')
p=T/'evidence-archive-config.json'
with p.open('x') as f:json.dump(archives,f,indent=2);f.write('\n')
print({k:len(v) for k,v in archives.items()})
