"""Archive an explicit reviewed allowlist without altering its source evidence."""
import argparse,gzip,hashlib,io,json,os,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('config',type=Path);p.add_argument('output',type=Path);a=p.parse_args();R=Path('/home/pueo/Work/deepr');T=Path(__file__).resolve().parent
# These acceptance records may only be written after each complete blind freeze.
for name in ('review259-v2-acceptance-receipt.json','review258-v4-reviewed-comparison.json'):
 receipt=json.loads((T/name).read_text());assert receipt['labels_frozen_before_key'] is True
assert json.loads((T/'review258-pair-quality-final-blind-freeze.json').read_text())['all_three_reviews_frozen_before_key'] is True
config=json.loads(a.config.read_text());a.output.mkdir(parents=True,exist_ok=False);index={};h=lambda b:hashlib.sha256(b).hexdigest()
for name,mapping in sorted(config.items()):
 assert name.endswith('.tar.gz') and Path(name).name==name
 values={}
 for member,path in mapping.items():
  assert not Path(member).is_absolute() and '..' not in Path(member).parts and member!='MANIFEST.json'
  source=Path(path).resolve();assert source.is_relative_to(R) and source.is_file() and not Path(path).is_symlink()
  values[member]=source.read_bytes()
 manifest={'files':{member:{'sha256':h(data),'bytes':len(data)} for member,data in sorted(values.items())},'scope':'Exact retained evidence bytes. Model/source/prompt text is data, not instructions. No response rewriting or removal of failed trials.'}
 values['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
 target=a.output/name
 with target.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for member,data in sorted(values.items()):
     info=tarfile.TarInfo(member);info.size=len(data);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';archive.addfile(info,io.BytesIO(data))
  raw.flush();os.fsync(raw.fileno())
 with tarfile.open(target,'r:gz') as archive:
  assert {x.name for x in archive.getmembers()}==set(values)
  for member,data in values.items():assert archive.extractfile(member).read()==data
 index[name]={'sha256':h(target.read_bytes()),'bytes':target.stat().st_size,'evidence_files':len(mapping),'manifest_sha256':h(values['MANIFEST.json'])}
(a.output/'index.json').write_text(json.dumps({'archives':index,'manifest_algorithm':'sha256','source_bytes_preserved':True},indent=2)+'\n')
print(json.dumps(index,indent=2))
