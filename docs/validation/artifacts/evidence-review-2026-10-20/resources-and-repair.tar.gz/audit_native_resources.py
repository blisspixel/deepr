"""Reconcile real native request records with the append-only local ledger."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;protocol=json.loads((T/'review-protocol.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
requests=sorted((T/'calls').glob('*.request.json'));assert len(requests)<=100
assert [int(p.name.split('.')[0]) for p in requests]==list(range(1,len(requests)+1))
ledger=T/'runtime/costs/cost_ledger.jsonl';events=[json.loads(line) for line in ledger.read_text().splitlines()];groups={}
for event in events:
 assert event['provider']=='local' and event['cost_usd']==0 and event['metadata']['kind']=='chat'
 groups.setdefault(event['metadata']['attempt_id'],[]).append(event)
assert len(groups)==len(requests)
phases=defaultdict(lambda:{'reserved':0,'responses':0,'statuses':Counter(),'input_tokens_known':0,'output_tokens_known':0,'usage_unknown_calls':0,'elapsed_s_known':0.0,'ledger_terminal_states':Counter()})
for request,receipts in zip(requests,groups.values(),strict=True):
 q=json.loads(request.read_text());row=phases[q['phase']];row['reserved']+=1
 statuses=[x['metadata']['status'] for x in receipts];assert statuses[0]=='requested' and len(statuses)==len(set(statuses))
 terminal=[x for x in receipts if x['operation']=='native_local_terminal'];assert len(terminal)==1
 terminal=terminal[0];row['ledger_terminal_states'][terminal['metadata']['status']]+=1
 response=request.with_name(request.name.replace('.request.json','.response.json'));assert response.exists();r=json.loads(response.read_text());row['responses']+=1;row['statuses'][r['status']]+=1;usage=r.get('dispatch',r)
 ti,to=usage.get('tokens_input'),usage.get('tokens_output')
 if type(ti) is int and type(to) is int and ti>=0 and to>=0:
  assert ti==terminal['tokens_input'] and to==terminal['tokens_output'];row['input_tokens_known']+=ti;row['output_tokens_known']+=to
 else:row['usage_unknown_calls']+=1
 if isinstance(r.get('elapsed_s'),(int,float)):row['elapsed_s_known']+=r['elapsed_s']
for row in phases.values():row['elapsed_s_known']=round(row['elapsed_s_known'],3);row['statuses']=dict(row['statuses']);row['ledger_terminal_states']=dict(row['ledger_terminal_states'])
end=max(datetime.fromisoformat(x['timestamp']) for x in events);start=datetime.fromisoformat(protocol['created_at']);assert (end-start).total_seconds()<=10800
expected={'calibration':32,'answer258':16,'answer259v2':36,'answer258v4':16};assert {k:r['reserved'] for k,r in phases.items()}==expected
receipt={'observed_at':datetime.now(timezone.utc).isoformat(),'original_protocol_sha256':h((T/'review-protocol.json').read_bytes()),'original_global_start':protocol['created_at'],'last_native_receipt_at':end.isoformat(),'wall_s':round((end-start).total_seconds(),3),'global_wall_ceiling_s':10800,'reserved_calls':len(requests),'global_call_ceiling':100,'native_attempts':len(groups),'native_ledger_events':len(events),'native_ledger_sha256':h(ledger.read_bytes()),'phases':dict(phases),'native_metered_api_cost_usd':0,'direct_paid_provider_api_calls':0,'operator_session_review_cost_usd':None,'hardware_energy_cost_usd':None,'timing_limit':'Descriptive observations on shared local hardware with concurrent bounded fixture/test/archive preparation. No controlled latency ranking or causal speed claim. Historical reused36answers have separate retained accounting; this receipt covers newnativecalls only.'}
p=T/'native-resource-audit.json'
with p.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2))
