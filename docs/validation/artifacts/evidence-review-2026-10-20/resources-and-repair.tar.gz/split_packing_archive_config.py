from pathlib import Path
import json
T=Path(__file__).resolve().parent;R=T.parents[1]
config=json.loads((T/'evidence-archive-config.json').read_text())
packing=config.pop('packing-trials.tar.gz');first={};corrected={}
for member,path in packing.items():
 target=first if member.startswith(('packing-fixtures/','packing-fixtures-v2/','packing-fixtures-v3/','review258-first','review258-complete','review258-source')) or Path(member).name in {'packing_fixtures.py','packing_fixtures_v2.py','packing_fixtures_v3.py','answer_runner.py','answer_runner_v3.py','answer-runner-freeze.json','answer-runner-freeze-v3.json','answers258.log','export258_complete_sources.py','finalize258_first_trial.py'} else corrected
 target[member]=path
assert set(first).isdisjoint(corrected) and set(first)|set(corrected)==set(packing)
config['packing-first-trial.tar.gz']=first;config['packing-corrected-trial.tar.gz']=corrected
config['resources-and-repair.tar.gz']['split_packing_archive_config.py']=str(Path(__file__).resolve())
out=T/'evidence-archive-config-split.json';assert not out.exists();out.write_text(json.dumps(config,indent=2)+'\n')
original=R/'docs/validation/artifacts/evidence-review-2026-10-20';saved=T/'archive-build-first'
assert not saved.exists();original.rename(saved)
print({'packing_first_files':len(first),'packing_corrected_files':len(corrected),'oversized_initial_build_preserved':str(saved)})
