import asyncio,hashlib,json,os
from pathlib import Path
from deepr.evals import correction_survival as cs
T=Path(__file__).resolve().parent
run=asyncio.run(cs.run_diagnostic(T/'final-source-mock60',distractors=60,code_identity='prospective release44 source review and Windows repair'))
report=cs.build_report(run);items,_=cs.blinded_review_packet(cs.load_run(T/'final-source-mock60'),salt='final-source-complete-probe')
for item in items:
 c=item['review_context'];assert c['source_inventory_sha256']==run['source_inventory_sha256'][c['world_id']]
 assert all(hashlib.sha256(s['text'].encode()).hexdigest()==s['text_sha256'] for s in c['sources'])
 assert len(c['sources'])==60+({'w1':1,'w2':3,'w3':6}[c['world_id']])
 if item['case_id']=='historical':assert len(c['sources'])==61 and all(s['source_id'] not in ('release-v3','payments-note') for s in c['sources'])
assert run['paid_calls']==0 and len(run['attempts'])==36
assert report['arms']['production']['stages']['retrieval']=={'selected':18,'not_applicable':2}
assert report['arms']['production']['stages']['delivery']=={'delivered':18,'not_applicable':2}
assert all(r['status']=='isolated' for r in report['historical_isolation'])
p=T/'final-source-mock60-report.json';p.write_text(json.dumps(report,indent=2)+'\n')
r={'case_set_sha256':run['case_set_sha256'],'recipe_sha256':cs.recipe_sha256(),'attempts':36,'real_model_calls':0,'complete_source_worlds':True,'source_inventory_fingerprints':run['source_inventory_sha256'],'production_retrieval':report['arms']['production']['stages']['retrieval'],'production_delivery':report['arms']['production']['stages']['delivery'],'historical_isolation':[x['status'] for x in report['historical_isolation']],'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'meaning':'Changed fixture; transport-only observations, not paired routing improvement or semantic quality.'}
(T/'final-source-mock60-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
