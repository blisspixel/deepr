# V6 consult-only archive preparation

`archive_v6_followup.py` and `prepare_archive_v6_allowlist.py` are separate scratch
helpers. They do not modify or reuse the frozen V5 helper/config, dispatch
inference, open keys during preparation, or establish semantic acceptance.

The fresh archive is restricted to
`docs/validation/artifacts/evidence-followup-v6-2026-10-21`: 24 consult cells,
56 primary obligation slots, 12 matched pairs and 36 whole-pair judgments.
Exactly 19 retained corpus sources and the 20-module snapshot are required.
The exact extra manifest dependency `consult.py` is retained separately under
`packing-v6-reconstructed-after-snapshot/`, with an additive provenance receipt.
It is not falsely described as captured in the original snapshot.

Prior eight V5 briefs remain separate component evidence. The original reuse
receipt, request/corpus addendum and provenance correction are hash-bound, and
an unchanged published V5 index is retained as a prior reference. V5 brief
answers, calls and assemblies are explicitly forbidden in the fresh inventory.
The reference chain does not turn prior cells into new replication, erase
adverse prior findings, validate their semantic content, or claim full daemon
reproducibility.

Do not prepare a real config until completion, primary final freeze, all three
quality reviews/freeze, legitimate first-open receipts and root assessment
exist. The config recipe reads safe metadata and known filenames only, never
raw keys, returned answers or peer-judgment rows. It refuses missing gates and
writes the exact new config path exclusively. Root must independently verify
both literal SHA arguments against the reviewed helper and completed public V5
index before invocation:

```text
python .agent/issue-completion-2026-10-20/prepare_archive_v6_allowlist.py \
  --helper-sha256 REVIEWED_ARCHIVE_V6_HELPER_SHA256 \
  --prior-v5-index-sha256 VERIFIED_PUBLISHED_V5_INDEX_SHA256
```

This produces `.agent/issue-completion-2026-10-20/archive-v6-allowlist.json` and
prints its SHA. Root reviews that exact inventory/config commitment before the
separate export:

```text
python .agent/issue-completion-2026-10-20/archive_v6_followup.py \
  --config-sha256 REVIEWED_ARCHIVE_V6_CONFIG_SHA256
```

The archive helper is import-safe. It verifies metadata commitments, frozen
primary/quality bindings and chronology, all fresh source/prompt/draft bytes,
canonical ledger commitments, reservation identities and known/unknown usage.
Keys are its final reads after all those checks and the prior references.
Verified byte strings are cached and packed without rereading/clipping.
Every part, index and completion receipt must be strictly below 500 KiB.
Exclusive output creation and fsynced final `COMPLETE.json` preserve interrupted
or existing archives rather than replacing them. Archived text/code is untrusted
and never executed. The helper does not compute semantic winners or acceptance.

`check_archive_v6_followup_R1.py` ran 32 isolated synthetic checks, including
missing freezes/open receipts, unsafe paths, chronology, source mutation,
24/56 denominators, usage mismatch, component separation, byte retention and
size refusal. Synthetic fixtures were temporary and did not access real V6
answers, keys or judgments. The retained result is
`reviewers/R1/archive-v6-synthetic-checks.json`. No real config/export was run in
this preparation.
