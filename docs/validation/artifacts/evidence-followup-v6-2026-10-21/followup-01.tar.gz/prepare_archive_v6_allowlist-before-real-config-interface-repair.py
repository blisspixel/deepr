"""Prepare an exact V6 archive inventory from safe metadata and filenames only.

Operator-run after both freezes and legitimate first-open receipts exist. Never
reads keys, answer records, reviewer rows or source-world text. No inference.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,runpy,sys
from datetime import datetime
from pathlib import Path

T=Path(__file__).resolve().parent
REPO=Path('/home/pueo/Work/deepr')
FIXED=(
 'review-instructions-v3.txt','quality-review-v6-instructions.txt','v6-review-protocol.json','v6-operator-authorization.json',
 'v6-collector-freeze.json','v6-native-resource-audit.json','packing-v6-precollection-audit-inputs.json',
 'reviewers/R3/packing-v6-precollection-audit.json','packing-v6-source-recipe-proof.json',
 'packing-v6-source-snapshot-receipt.json','packing-v6-additional-manifest-modules-receipt.json',
 'v6-reused-brief-component.json','v6-reused-brief-component-addendum.json','v6-reused-brief-provenance-correction.json',
 'reviewer-v6-calibration-admission.json','quality-v6-calibration-admission.json',
 'review258-v6-adjudication-inputs.json','review258-v6-disagreements.json','review258-v6-reviewed-comparison.json',
 'material-review-v6/reviewed-whole-pairs.json','answers258-v6.log','packing_fixtures_v6.py','answer_runner_v6.py',
 'audit_native_resources_v6.py','review258_v6_primary.py','prepare_v6_material_review.py','freeze_pair_quality_v6.py',
 'v6-focused.json','v6-focused.log','v6-focused-invocation-failure.json',
 'v6-guidance-regression-with-prior-instructions.json','v6-guidance-regression-with-prior-instructions.log',
 'archive_v6_followup.py','prepare_archive_v6_allowlist.py','check_archive_v6_followup_R1.py',
 'archive-v6-followup-usage.md','reviewers/R1/archive-v6-preparation-receipt.json','reviewers/R1/archive-v6-synthetic-checks.json',
)


def require(value,reason):
 if not value:raise ValueError(reason)


def h(raw):return hashlib.sha256(raw).hexdigest()


def build(root,helper_sha,index_sha,out):
 scope=runpy.run_path(str(T/'archive_v6_followup.py'),run_name='safe_archive_inventory_contract')
 require(root.resolve()==root and root.is_dir(),'Canonical task root required')
 # Require all key gates BEFORE data inventories. Only metadata bytes are read.
 metadata={}
 for name in sorted(scope['PINNED']):
  scope['safe_name'](name)
  path=scope['regular'](root/name,root)
  metadata[name]=path.read_bytes()
 def read(name):
  scope['safe_name'](name)
  if name not in metadata:metadata[name]=scope['regular'](root/name,root).read_bytes()
  return scope['parse'](metadata[name])
 primary=read('review258-v6-final-blind-freeze.json');quality=read('material-review-v6/quality-freeze/FREEZE.json')
 p_open=read('material-review-v6/primary-key-open-receipt.json');q_open=read('material-review-v6/quality-key-open-receipt.json')
 require(primary['stage']=='final_blind' and primary['assignment_key_opened'] is False
         and primary['scheduled_cells']==24 and primary['resolved_rows']==56,'Complete primary freeze required')
 require(quality['independent_review_inputs']==3 and quality['pairs_per_reviewer']==12
         and set(quality['snapshots'])==scope['SNAPSHOTS'],'Complete quality freeze required')
 require(p_open['primary_freeze_sha256']==h(metadata['review258-v6-final-blind-freeze.json'])
         and q_open['quality_freeze_sha256']==h(metadata['material-review-v6/quality-freeze/FREEZE.json'])
         and p_open['primary_labels_frozen_before_key'] is True and q_open['all_three_reviews_frozen_before_key'] is True,
         'Legitimate first-open receipt commitments required')
 require(scope['instant'](primary['frozen_at'])<=scope['instant'](p_open['opened_at'])<=scope['instant'](quality['frozen_at'])
         <=scope['instant'](q_open['opened_at']),'Pre-key chronology differs')
 helper=scope['regular'](root/'archive_v6_followup.py',root)
 require(h(helper.read_bytes())==scope['digest'](helper_sha),'Reviewed archive helper changed')
 manifest=read('packing-fixtures-v6/manifest.json');completion=read('packing-fixtures-v6/answers-complete.json')
 snapshot=read('packing-v6-source-snapshot-receipt.json');extra=read('packing-v6-additional-manifest-modules-receipt.json')
 resource=read('v6-native-resource-audit.json')
 ids={row['item_id'] for row in manifest['jobs']}
 require(len(ids)==len(manifest['jobs'])==manifest['answers_scheduled']==completion['terminal_answers']==24,'All24 terminal cells required')
 require({row['item_id'] for row in completion['results']}==ids and len(completion['results'])==24,'Completion inventory differs')
 require(all(row['status'] in scope['TERMINAL'] for row in completion['results']),'Nonterminal status')
 require(len(snapshot['files'])==20 and set(manifest['current_modules'])-set(snapshot['files'])==set(extra['files']),
         'Captured-plus-additive source closure differs')
 files=set(scope['CORE'])|set(FIXED)
 for iid in ids:
  require(re.fullmatch('[0-9a-f]{16}',iid),'Invalid opaque item ID')
  files.update((f'packing-fixtures-v6/{iid}.input.json',f'packing-fixtures-v6/answers/{iid}.json'))
 for path in snapshot['files']:files.add('packing-v6-source-snapshot/'+path)
 for path,row in extra['files'].items():
  require(row['path']=='packing-v6-reconstructed-after-snapshot/'+path,'Unexpected additive source path')
  files.add(row['path'])
 for who in ('R1','R2'):files.add(f'reviewers/{who}/review258-v6.json')
 if primary['adjudication_sha256'] is not None:files.add('reviewers/R3/review258-v6-adjudication.json')
 for name in scope['SNAPSHOTS']:files.add('material-review-v6/quality-freeze/'+name)
 corpus=[]
 for path in (root/'packing-fixtures-v6/corpus/sources').rglob('*.md'):
  name=path.relative_to(root).as_posix()
  require(re.fullmatch(r'packing-fixtures-v6/corpus/sources/[0-9a-f]{2}/[0-9a-f]{64}\.md',name),'Unexpected corpus filename')
  corpus.append(name)
 require(len(corpus)==19,'Exactly19 corpus filenames required');files.update(corpus)
 for path in (root/'packing-fixtures-v6/raw-prompt-audit').iterdir():
  require(path.is_file() and re.fullmatch(r'[A-Za-z0-9_.-]+\.json',path.name),'Unexpected raw prompt audit filename')
  files.add(path.relative_to(root).as_posix())
 for number,row in enumerate(resource['attempt_joins'],1):
  require(row['item_id'] in ids,'Unknown reserved item')
  prefix=f"v6-runtime/calls/{number:03d}.{row['item_id']}"
  files.update((prefix+'.request.json',prefix+'.response.json'))
  if row['transport_sha256'] is not None:files.add(prefix+'.transport.json')
  if (root/(prefix+'.native.json')).is_file():files.add(prefix+'.native.json')
 for name in files:
  scope['safe_name'](name,keys=name in scope['KEYS'])
  scope['regular'](root/name,root)  # metadata check only, never read these bytes
 index=REPO/'docs/validation/artifacts/evidence-followup-v5-2026-10-21/index.json'
 require(index.is_file() and (index.parent/'COMPLETE.json').is_file(),'Published complete priorV5 archive required')
 index_raw=index.read_bytes();require(h(index_raw)==scope['digest'](index_sha),'PriorV5 public index changed')
 config={'schema':'deepr.v6-public-archive-allowlist.v1','task_root':str(root),'public_output':str(out),
  'builder_sha256':helper_sha,'files':sorted(files),
  'metadata_sha256':{name:h(metadata[name]) for name in sorted(scope['PINNED'])},
  'current_recipe_paths':sorted(snapshot['files']),'additional_manifest_paths':sorted(extra['files']),
  'legacy_consult_source':str(REPO/'.agent/evidence-delivery-2026-10-19/old_consult_prompt.py'),
  'prior_v5_public_index':{'path':str(index),'sha256':index_sha},
  'scope':'Exactly24freshconsultcells/56primaryslots/12pairs/36wholepairjudgments and19corpus sources. PriorV5brief component receipts remain separate hash-bound references; no priorbrief answer or assembly is copied as a freshV6cell. No inference or acceptance authority.'}
 return scope['encode'](config)


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--root',type=Path,default=T)
 parser.add_argument('--helper-sha256',required=True)
 parser.add_argument('--prior-v5-index-sha256',required=True)
 parser.add_argument('--output',type=Path,default=T/'archive-v6-allowlist.json')
 args=parser.parse_args();root=args.root.resolve()
 require(args.output.absolute().parent==root and args.output.name=='archive-v6-allowlist.json','Config output must be the exact new task-owned path')
 require(not args.output.exists(),'Never replace a prepared archive config')
 out=REPO/'docs/validation/artifacts/evidence-followup-v6-2026-10-21'
 raw=build(root,args.helper_sha256,args.prior_v5_index_sha256,out)
 with args.output.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 print(json.dumps({'config':str(args.output),'config_sha256':h(raw),'model_calls':0,'keys_read':False,'answer_or_judgment_bytes_read':False}))


if __name__=='__main__':
 try:main()
 except (ValueError,OSError,KeyError,TypeError) as error:
  print(json.dumps({'status':'refused','reason':str(error),'semantic_acceptance':None}),file=sys.stderr);raise SystemExit(2)
