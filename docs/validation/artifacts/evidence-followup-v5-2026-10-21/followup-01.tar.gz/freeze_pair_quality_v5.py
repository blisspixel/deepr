"""Offline mechanical freeze only. Never read a method key or select a policy."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DISPOSITIONS = {"no_material_difference", "A_materially_worse", "B_materially_worse", "uncertain"}
TERMINAL_STATUSES = {
    "completed", "truncated", "empty_answer", "form_failed", "malformed_brief", "failed", "cancelled",
    "refused_followup_bound", "refused_followup_integrity",
}
ATTESTATIONS = (
    "independent_session",
    "reviewed_without_primary_method_mapping",
    "reviewed_without_quality_method_mapping",
    "reviewed_without_peer_judgments",
    "all_pairs_reviewed",
)


class AdmissionError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AdmissionError(message)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha(value: Any, name: str) -> str:
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None, f"Invalid {name}")
    return value


def text(value: Any, name: str) -> str:
    require(isinstance(value, str) and bool(value.strip()), f"Missing {name}")
    return value


def timestamp(value: Any, name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(text(value, name).replace("Z", "+00:00"))
    except ValueError as error:
        raise AdmissionError(f"Invalid {name}") from error
    require(parsed.tzinfo is not None and parsed.utcoffset() is not None, f"Timezone required for {name}")
    return parsed


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        require(key not in value, f"Duplicate JSON key: {key}")
        value[key] = item
    return value


def load(path: Path) -> tuple[bytes, Any]:
    # No key path is an accepted argument. Also refuse known key/private names
    # if supplied in another input slot, before reading their bytes.
    for candidate in (path, path.resolve()):
        for part in candidate.parts:
            lowered = part.lower()
            require(
                not ("assignment-key" in lowered or "method-key" in lowered or "key-unopened" in lowered or lowered == "key.json"
                     or lowered.startswith("private") or lowered == "s0"),
                "Protected key/private input path refused",
            )
    require(path.is_file(), f"Missing input: {path}")
    raw = path.read_bytes()
    try:
        return raw, json.loads(raw, object_pairs_hook=reject_duplicate_keys)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise AdmissionError(f"Invalid JSON input: {path}") from error


def validate_packet(packet: Any) -> dict[str, dict[str, Any]]:
    require(isinstance(packet, list) and len(packet) == 16, "Packet must contain all 16 pairs")
    indexed: dict[str, dict[str, Any]] = {}
    for pair in packet:
        require(isinstance(pair, dict), "Pair must be an object")
        pair_id = text(pair.get("pair_id"), "pair_id")
        require(pair_id not in indexed, "Duplicate pair_id")
        text(pair.get("question"), "question")
        require(pair.get("kind") in {"consult", "brief"}, "Unsupported pair kind")
        sources = pair.get("sources")
        require(isinstance(sources, list) and bool(sources), "Complete sources must be supplied")
        source_ids = [text(source.get("source_id"), "source_id") for source in sources if isinstance(source, dict)]
        require(len(source_ids) == len(sources) == len(set(source_ids)), "Invalid or duplicate source identifiers")
        for side in ("A", "B"):
            answer = pair.get(side)
            require(isinstance(answer, dict), f"Missing {side} side")
            require(answer.get("status") in TERMINAL_STATUSES, f"Unknown or nonterminal {side} status")
            # Failed, cancelled, malformed, truncated and form-failed drafts stay
            # in the denominator. Explicit absence has no invented answer hash.
            if "answer" in answer:
                require(isinstance(answer["answer"], str), "Retained answer must be text")
                expected = sha(answer.get("answer_sha256"), "answer hash")
                require(digest(answer["answer"].encode("utf-8")) == expected, "Answer hash mismatch")
                require(not answer.get("answer_absence"), "Answer and absence cannot both be supplied")
            else:
                text(answer.get("answer_absence"), "explicit answer absence")
                require(answer.get("answer_sha256") is None, "Absent answer must have no hash")
            prompt = answer.get("delivered_prompt")
            require(isinstance(prompt, str), "Exact delivered prompt must be supplied")
            require(digest(prompt.encode("utf-8")) == sha(answer.get("prompt_sha256"), "prompt hash"), "Prompt hash mismatch")
            if "assembled_markdown" in answer:
                require(isinstance(answer["assembled_markdown"], str), "Assembled Markdown must be text")
                expected = sha(answer.get("assembled_markdown_sha256"), "assembled Markdown hash")
                require(digest(answer["assembled_markdown"].encode("utf-8")) == expected, "Assembly hash mismatch")
            if pair["kind"] == "brief":
                text(answer.get("assembly_status"), "brief assembly status")
                require("assembled_markdown" in answer or bool(text(answer.get("assembly_absence"), "assembly absence")),
                        "Brief needs actual assembly or explicit assembly absence")
        indexed[pair_id] = pair
    return indexed


def validate_review(
    envelope: Any, reviewer: str, packet: dict[str, dict[str, Any]], packet_hash: str,
    input_hash: str, earliest: datetime, now: datetime,
) -> str:
    require(isinstance(envelope, dict), "Review must be an envelope with rows and session attestation")
    require(envelope.get("reviewer") == reviewer, "Reviewer identity mismatch")
    require(envelope.get("packet_sha256") == packet_hash, "Review packet hash mismatch")
    require(envelope.get("input_freeze_sha256") == input_hash, "Review input-freeze hash mismatch")
    session = text(envelope.get("review_session_id"), "independent review session ID")
    attestations = envelope.get("independence_attestation")
    require(isinstance(attestations, dict) and all(attestations.get(key) is True for key in ATTESTATIONS),
            "Complete explicit reviewer independence/blinding attestations required")
    completed = timestamp(envelope.get("completed_at"), "review completed_at")
    require(earliest <= completed <= now, "Review timestamp is outside the declared pre-freeze sequence")
    rows = envelope.get("rows")
    require(isinstance(rows, list) and len(rows) == 16, "Every reviewer must judge all 16 pairs")
    seen: set[str] = set()
    for row in rows:
        require(isinstance(row, dict), "Review row must be an object")
        pair_id = text(row.get("pair_id"), "review pair_id")
        require(pair_id in packet and pair_id not in seen, "Unknown or duplicate review pair")
        seen.add(pair_id)
        require(row.get("reviewer") == reviewer, "Row reviewer mismatch")
        require(row.get("disposition") in DISPOSITIONS, "Invalid closed-set disposition")
        text(row.get("note"), "source-grounded rationale")
        text(row.get("abstention_assessment"), "abstention assessment")
        pair = packet[pair_id]
        source_ids = row.get("source_ids")
        require(isinstance(source_ids, list) and all(isinstance(value, str) for value in source_ids), "Invalid source IDs")
        require(len(source_ids) == len(set(source_ids)) and set(source_ids) <= {source["source_id"] for source in pair["sources"]},
                "Review source binding mismatch")
        for side in ("A", "B"):
            answer = pair[side]
            require(f"{side}_answer_sha256" in row and row[f"{side}_answer_sha256"] == answer.get("answer_sha256"),
                    "Review answer hash mismatch")
            quote = row.get(f"{side}_quote")
            require(isinstance(quote, str), "Quote must be a string or empty")
            require(not quote or quote in answer.get("answer", "") or quote in answer.get("assembled_markdown", ""),
                    "Quote is not an exact supplied substring")
    require(seen == set(packet), "Incomplete review coverage")
    return session


def validate_primary_freeze(primary: Any, labels_raw: bytes, labels: Any) -> tuple[datetime, str]:
    """Bind the actual primary helper's final receipt, without regrading labels."""
    require(isinstance(primary, dict), "Primary freeze must be an object")
    require(primary.get("schema") == "deepr.scratch.review258-v5.blind-freeze.v2"
            and primary.get("stage") == "final_blind", "Actual V5 final-blind primary receipt required")
    require(primary.get("assignment_key_opened") is False and primary.get("key_access_implemented") is False,
            "Primary receipt must declare pre-key finalization")
    outputs = primary.get("output_sha256")
    label_name = "review258-v5-final-labels.json"
    require(isinstance(outputs, dict) and set(outputs) == {label_name}, "Primary final-label output map mismatch")
    expected = sha(outputs[label_name], "primary final-label hash")
    require(digest(labels_raw) == expected, "Primary final-label bytes differ from final receipt output map")
    require(isinstance(labels, list) and bool(labels) and all(isinstance(row, dict) and "label" in row for row in labels),
            "Primary final-label rows are absent or malformed")
    rows = primary.get("resolved_rows")
    assessed = primary.get("resolved_labels")
    require(isinstance(rows, int) and not isinstance(rows, bool) and rows == len(labels), "Primary resolved-row count mismatch")
    require(isinstance(assessed, int) and not isinstance(assessed, bool)
            and assessed == sum(row["label"] is not None for row in labels), "Primary resolved-label count mismatch")
    require(primary.get("rows_per_reviewer") == rows
            and primary.get("reviewable_obligation_slots") == assessed
            and primary.get("unassessable_obligation_slots") == rows - assessed,
            "Primary assessed/absence slot counts mismatch")
    require(primary.get("items") == 32 and primary.get("scheduled_cells") == 32,
            "Primary final receipt must retain all 32 scheduled cells")
    require(primary.get("candidate_accepted") is None, "Primary freeze must not declare candidate acceptance")
    return timestamp(primary.get("frozen_at"), "primary frozen_at"), expected


def sync_directory(path: Path) -> None:
    # Directory fsync is supported by the current Linux preparation host.
    # Refuse to certify durability if the platform/filesystem cannot do it.
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_exclusive(path: Path, raw: bytes) -> None:
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def freeze(args: argparse.Namespace) -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    packet_hash = sha(args.packet_sha256, "expected packet hash")
    key_hash = sha(args.quality_key_sha256, "withheld quality-key hash")
    primary_hash = sha(args.primary_freeze_sha256, "expected primary-freeze hash")
    packet_raw, packet_value = load(args.packet)
    require(digest(packet_raw) == packet_hash, "Packet bytes differ from supplied hash")
    packet = validate_packet(packet_value)
    primary_raw, primary = load(args.primary_freeze)
    require(digest(primary_raw) == primary_hash, "Primary freeze hash mismatch")
    require(args.primary_labels.name == "review258-v5-final-labels.json", "Use the actual named primary final-label file")
    labels_raw, labels = load(args.primary_labels)
    primary_at, primary_labels_hash = validate_primary_freeze(primary, labels_raw, labels)
    input_raw, input_freeze = load(args.input_freeze)
    require(isinstance(input_freeze, dict), "Input freeze must be an object")
    require(input_freeze.get("packet_sha256") == packet_hash and input_freeze.get("pairs") == 16, "Input packet binding mismatch")
    require(input_freeze.get("withheld_quality_key_sha256") == key_hash, "Withheld quality-key SHA mismatch")
    require(input_freeze.get("primary_freeze_sha256") == primary_hash, "Input primary-freeze binding mismatch")
    require(input_freeze.get("assignment_key_opened") is False and input_freeze.get("primary_labels_unchanged") is True,
            "Separate withheld quality key and unchanged primary labels must be declared")
    created = timestamp(input_freeze.get("created_at"), "quality input created_at")
    require(primary_at <= created <= now, "Quality packet must follow primary review freeze")
    require(len(args.review) == 3, "Exactly three complete independent review inputs required")
    snapshots = {
        "packet.json": packet_raw, "primary-freeze.json": primary_raw, "input-freeze.json": input_raw,
        "review258-v5-final-labels.json": labels_raw,
    }
    reviewers: dict[str, Any] = {}
    sessions: set[str] = set()
    paths: set[Path] = set()
    for specification in args.review:
        reviewer, separator, filename = specification.partition("=")
        require(bool(separator) and re.fullmatch(r"[A-Za-z0-9_-]{1,32}", reviewer) is not None, "Use --review ID=PATH")
        require(reviewer not in reviewers, "Duplicate reviewer ID")
        path = Path(filename)
        require(path.resolve() not in paths, "Review input path reused")
        paths.add(path.resolve())
        raw, envelope = load(path)
        session = validate_review(envelope, reviewer, packet, packet_hash, digest(input_raw), created, now)
        require(session not in sessions, "Independent session ID reused")
        sessions.add(session)
        snapshots[f"review-{reviewer}.json"] = raw
        reviewers[reviewer] = {"sha256": digest(raw), "session_id": session, "pairs": 16}
    out = args.out.resolve()
    require(out.is_relative_to(ROOT) and out != ROOT, "Output must be a new directory under this scratch root")
    require(not out.exists() and out.parent.is_dir(), "Output exists or its parent is missing")
    script_raw = Path(__file__).read_bytes()
    snapshots["validator.py"] = script_raw
    receipt = {
        "kind": "deepr.pair-quality-pre-key-freeze.v1", "frozen_at": now.isoformat(),
        "status": "mechanical_bindings_and_coverage_frozen", "pairs_per_reviewer": 16,
        "independent_review_inputs": 3, "packet_sha256": packet_hash,
        "primary_freeze_sha256": primary_hash, "primary_labels_sha256": primary_labels_hash,
        "input_freeze_sha256": digest(input_raw),
        "withheld_quality_key_sha256": key_hash, "key_opened_by_validator": False,
        "reviewers": reviewers, "snapshots": {name: digest(raw) for name, raw in snapshots.items()},
        "semantic_acceptance": None, "semantic_verdict_emitted": False,
        "limits": [
            "Blinding, independent sessions and pre-key chronology are supplied attestations, not independently proven facts.",
            "Nonempty rationales and exact quotes do not establish sound semantic judgments.",
            "All dispositions and disagreements remain unchanged; no majority rule or winner is computed.",
            "Review service exact model snapshot, usage and cost are unobserved; these are not human reviews.",
            "Development fixtures do not qualify held-out transfer, S0, general advice or default promotion.",
            "No generation, operator authorization, budget extension or key-opening authority is created.",
        ],
    }
    # All admission finishes before creating output. A crash may leave a partial
    # directory; only the last-written durable FREEZE.json denotes a freeze.
    out.mkdir()
    sync_directory(out.parent)
    for name, raw in snapshots.items():
        write_exclusive(out / name, raw)
    sync_directory(out)
    write_exclusive(out / "FREEZE.json", (json.dumps(receipt, indent=2) + "\n").encode("utf-8"))
    sync_directory(out)
    sync_directory(out.parent)
    return {"status": receipt["status"], "freeze": str(out / "FREEZE.json"), "semantic_acceptance": None}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("packet", "input-freeze", "primary-freeze", "primary-labels", "out"):
        parser.add_argument(f"--{flag}", type=Path, required=True)
    for flag in ("packet-sha256", "quality-key-sha256", "primary-freeze-sha256"):
        parser.add_argument(f"--{flag}", required=True)
    parser.add_argument("--review", action="append", required=True, metavar="ID=PATH")
    args = parser.parse_args()
    try:
        print(json.dumps(freeze(args)))
    except (AdmissionError, OSError, TypeError, KeyError, OverflowError) as error:
        print(json.dumps({"status": "refused", "reason": str(error), "semantic_acceptance": None}), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
