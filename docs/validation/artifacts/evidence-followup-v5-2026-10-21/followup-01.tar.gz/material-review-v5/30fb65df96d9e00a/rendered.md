# Fenn cache applicability: brief

## In sixty seconds

Studied sources (recorded attribution): Fenn catalogue caching can reduce repeated reads only for immutable public replies.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): Authenticated replies need tenant-scoped keys and revocation tracking.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): The inventory facts in the source corpus establish no cache policy beyond the specific conditions noted.
Cited findings (study binding: not checked in this view): synopsis-1, orientation-0, orientation-1, mechanism-1, failure-0, failure-1, contention-1, implication-0, implication-1, analogy-0, analogy-1, question-0, question-1

## Where I land, and why

1. **When is it safe to cache Fenn catalogue replies?**
   - Stance: Caching is safe only for immutable public replies. Caching authenticated replies is unsafe unless tenant-scoped keys and revocation tracking are verified.
   - Because: The synopsis explicitly limits caching benefits to immutable public replies and mandates tenant-scoped keys and revocation tracking for authenticated ones. The contention finding confirms that without these controls, account-specific replies leaked across tenants, while public immutable replies were unaffected.
   - Likelihood it holds: almost certain (95-99%)
   - Confidence in that basis: high (Direct observation of leakage in the operator trial (contention-0) and explicit qualification in the synopsis (synopsis-0).)
   - **Does not resolve**: None. The findings are consistent on the requirement for tenant-scoped keys and revocation tracking for authenticated replies.
   - Would change my mind: If a new version of Fenn introduces a verified, built-in mechanism for tenant-isolated caching of authenticated replies that does not require external revocation tracking, or if a test demonstrates that tenant-scoped keys alone (without revocation tracking) prevent leakage in all observed scenarios.
   - Check on 2026-11-20: A documented Fenn release note or a reproducible test case showing that authenticated replies do not leak across tenants when cached with only tenant-scoped keys and no revocation tracking.
   - Rests on: Fenn synopsis-0 (synopsis-0); Fenn contention-0 (contention-0)
   - Evidential depth: 2 source(s), 2 publisher(s)

2. **Does the source corpus define a general cache renewal policy?**
   - Stance: No. The findings do not establish a general cache policy or renewal conditions beyond the specific constraints for public vs. authenticated replies.
   - Because: Multiple findings across different lenses (synopsis, orientation, mechanism, failure, contention, implication, analogy, question) explicitly state that the inventory facts establish no cache policy. The mechanism finding mentions a synthetic trial but repeats that it records timing and inventory without establishing a policy.
   - Likelihood it holds: almost certain (95-99%)
   - Confidence in that basis: high (Consistent explicit statements across all non-synopsis findings that no cache policy is established.)
   - **Does not resolve**: None. All findings consistently state that no cache policy is established by the inventory facts.
   - Would change my mind: If a specific document or finding in the corpus explicitly defines TTL values, renewal triggers, or invalidation strategies for Fenn cache entries.
   - Check on 2026-11-20: Discovery of a finding or source document that specifies concrete cache renewal conditions (e.g., TTL, event-based invalidation) for Fenn.
   - Rests on: Fenn synopsis-1 (synopsis-1); Fenn orientation-0 (orientation-0); Fenn orientation-1 (orientation-1); When may a cache entry be renewed? (mechanism-0)
   - Evidential depth: 14 source(s), 14 publisher(s)

## Settled, live, unknown

**Settled (skip these)**
- Caching is applicable only to immutable public replies.
- Authenticated replies require tenant-scoped keys and revocation tracking to prevent leakage.
- The source corpus does not establish a general cache policy or renewal conditions.

**Live**
- Whether future Fenn versions will introduce built-in tenant-isolated caching for authenticated replies.
- The specific implementation details of revocation tracking required for safe caching.

**Genuinely unknown**
- Performance impact of caching on Fenn throughput beyond the synthetic trial mentioned.
- Specific TTL or invalidation strategies if a policy were to be defined.

## What people try that does not work

- Attempting to cache authenticated replies without tenant-scoped keys, which leads to cross-tenant leakage.
- Assuming that the absence of a stated cache policy in the inventory facts means that caching is universally safe or unsafe, rather than recognizing the specific conditions for public vs. authenticated replies.

## Questions I expect

**Is it possible that the leakage observed in the operator trial was due to a configuration error rather than a fundamental limitation of Fenn's caching?** (this one costs me something)
The contention finding states that the leakage occurred when tenant keys were absent, implying that the absence of tenant keys is the cause. However, it does not explicitly rule out configuration errors. The synopsis mandates tenant-scoped keys, suggesting that their absence is a known risk factor.
_Asked because: To challenge the assumption that the leakage is a fundamental limitation rather than a specific failure mode._

**What are the specific requirements for revocation tracking to be considered 'verified'?**
The findings do not specify the technical requirements for revocation tracking. They only state that it is necessary for caching authenticated replies.
_Asked because: To understand the practical implementation challenges of the recommended stance._

## Who this rests on

| Origin | Sources | Trust | Note |
|---|---|---|---|
| fenn-hosted.example | 1 | primary | - |
| fenn-manual.example | 1 | primary | - |
| fenn-monitor.example | 1 | primary | - |
| fenn-release.example | 1 | primary | - |
| fenn-self.example | 1 | primary | - |
| filler-0.example | 1 | tertiary | - |
| filler-1.example | 1 | tertiary | - |
| filler-10.example | 1 | tertiary | - |
| filler-11.example | 1 | tertiary | - |
| filler-12.example | 1 | tertiary | - |
| filler-13.example | 1 | tertiary | - |
| filler-2.example | 1 | tertiary | - |
| filler-3.example | 1 | tertiary | - |
| filler-4.example | 1 | tertiary | - |
| filler-5.example | 1 | tertiary | - |
| filler-6.example | 1 | tertiary | - |
| filler-7.example | 1 | tertiary | - |
| filler-8.example | 1 | tertiary | - |
| filler-9.example | 1 | tertiary | - |
| lens-cap-analogy-0.example | 1 | primary | - |
| lens-cap-analogy-1.example | 1 | primary | - |
| lens-cap-analogy-2.example | 1 | primary | - |
| lens-cap-analogy-3.example | 1 | primary | - |
| lens-cap-contention-0.example | 1 | primary | - |
| lens-cap-contention-1.example | 1 | primary | - |
| lens-cap-contention-2.example | 1 | primary | - |
| lens-cap-contention-3.example | 1 | primary | - |
| lens-cap-failure-0.example | 1 | primary | - |
| lens-cap-failure-1.example | 1 | primary | - |
| lens-cap-failure-10.example | 1 | primary | - |
| lens-cap-failure-11.example | 1 | primary | - |
| lens-cap-failure-12.example | 1 | primary | - |
| lens-cap-failure-13.example | 1 | primary | - |
| lens-cap-failure-14.example | 1 | primary | - |
| lens-cap-failure-15.example | 1 | primary | - |
| lens-cap-failure-16.example | 1 | primary | - |
| lens-cap-failure-17.example | 1 | primary | - |
| lens-cap-failure-18.example | 1 | primary | - |
| lens-cap-failure-19.example | 1 | primary | - |
| lens-cap-failure-2.example | 1 | primary | - |
| lens-cap-failure-20.example | 1 | primary | - |
| lens-cap-failure-21.example | 1 | primary | - |
| lens-cap-failure-22.example | 1 | primary | - |
| lens-cap-failure-23.example | 1 | primary | - |
| lens-cap-failure-24.example | 1 | primary | - |
| lens-cap-failure-25.example | 1 | primary | - |
| lens-cap-failure-26.example | 1 | primary | - |
| lens-cap-failure-27.example | 1 | primary | - |
| lens-cap-failure-28.example | 1 | primary | - |
| lens-cap-failure-29.example | 1 | primary | - |
| lens-cap-failure-3.example | 1 | primary | - |
| lens-cap-failure-30.example | 1 | primary | - |
| lens-cap-failure-31.example | 1 | primary | - |
| lens-cap-failure-32.example | 1 | primary | - |
| lens-cap-failure-33.example | 1 | primary | - |
| lens-cap-failure-34.example | 1 | primary | - |
| lens-cap-failure-4.example | 1 | primary | - |
| lens-cap-failure-5.example | 1 | primary | - |
| lens-cap-failure-6.example | 1 | primary | - |
| lens-cap-failure-7.example | 1 | primary | - |
| lens-cap-failure-8.example | 1 | primary | - |
| lens-cap-failure-9.example | 1 | primary | - |
| lens-cap-implication-0.example | 1 | primary | - |
| lens-cap-implication-1.example | 1 | primary | - |
| lens-cap-implication-2.example | 1 | primary | - |
| lens-cap-implication-3.example | 1 | primary | - |
| lens-cap-mechanism-0.example | 1 | primary | - |
| lens-cap-mechanism-1.example | 1 | primary | - |
| lens-cap-mechanism-10.example | 1 | primary | - |
| lens-cap-mechanism-11.example | 1 | primary | - |
| lens-cap-mechanism-12.example | 1 | primary | - |
| lens-cap-mechanism-13.example | 1 | primary | - |
| lens-cap-mechanism-14.example | 1 | primary | - |
| lens-cap-mechanism-15.example | 1 | primary | - |
| lens-cap-mechanism-16.example | 1 | primary | - |
| lens-cap-mechanism-17.example | 1 | primary | - |
| lens-cap-mechanism-18.example | 1 | primary | - |
| lens-cap-mechanism-19.example | 1 | primary | - |
| lens-cap-mechanism-2.example | 1 | primary | - |
| lens-cap-mechanism-20.example | 1 | primary | - |
| lens-cap-mechanism-21.example | 1 | primary | - |
| lens-cap-mechanism-22.example | 1 | primary | - |
| lens-cap-mechanism-23.example | 1 | primary | - |
| lens-cap-mechanism-24.example | 1 | primary | - |
| lens-cap-mechanism-25.example | 1 | primary | - |
| lens-cap-mechanism-26.example | 1 | primary | - |
| lens-cap-mechanism-27.example | 1 | primary | - |
| lens-cap-mechanism-28.example | 1 | primary | - |
| lens-cap-mechanism-29.example | 1 | primary | - |
| lens-cap-mechanism-3.example | 1 | primary | - |
| lens-cap-mechanism-30.example | 1 | primary | - |
| lens-cap-mechanism-31.example | 1 | primary | - |
| lens-cap-mechanism-32.example | 1 | primary | - |
| lens-cap-mechanism-33.example | 1 | primary | - |
| lens-cap-mechanism-34.example | 1 | primary | - |
| lens-cap-mechanism-4.example | 1 | primary | - |
| lens-cap-mechanism-5.example | 1 | primary | - |
| lens-cap-mechanism-6.example | 1 | primary | - |
| lens-cap-mechanism-7.example | 1 | primary | - |
| lens-cap-mechanism-8.example | 1 | primary | - |
| lens-cap-mechanism-9.example | 1 | primary | - |
| lens-cap-orientation-0.example | 1 | primary | - |
| lens-cap-orientation-1.example | 1 | primary | - |
| lens-cap-orientation-10.example | 1 | primary | - |
| lens-cap-orientation-11.example | 1 | primary | - |
| lens-cap-orientation-12.example | 1 | primary | - |
| lens-cap-orientation-13.example | 1 | primary | - |
| lens-cap-orientation-14.example | 1 | primary | - |
| lens-cap-orientation-15.example | 1 | primary | - |
| lens-cap-orientation-16.example | 1 | primary | - |
| lens-cap-orientation-17.example | 1 | primary | - |
| lens-cap-orientation-18.example | 1 | primary | - |
| lens-cap-orientation-19.example | 1 | primary | - |
| lens-cap-orientation-2.example | 1 | primary | - |
| lens-cap-orientation-20.example | 1 | primary | - |
| lens-cap-orientation-21.example | 1 | primary | - |
| lens-cap-orientation-22.example | 1 | primary | - |
| lens-cap-orientation-23.example | 1 | primary | - |
| lens-cap-orientation-24.example | 1 | primary | - |
| lens-cap-orientation-25.example | 1 | primary | - |
| lens-cap-orientation-26.example | 1 | primary | - |
| lens-cap-orientation-27.example | 1 | primary | - |
| lens-cap-orientation-28.example | 1 | primary | - |
| lens-cap-orientation-29.example | 1 | primary | - |
| lens-cap-orientation-3.example | 1 | primary | - |
| lens-cap-orientation-30.example | 1 | primary | - |
| lens-cap-orientation-31.example | 1 | primary | - |
| lens-cap-orientation-32.example | 1 | primary | - |
| lens-cap-orientation-33.example | 1 | primary | - |
| lens-cap-orientation-34.example | 1 | primary | - |
| lens-cap-orientation-4.example | 1 | primary | - |
| lens-cap-orientation-5.example | 1 | primary | - |
| lens-cap-orientation-6.example | 1 | primary | - |
| lens-cap-orientation-7.example | 1 | primary | - |
| lens-cap-orientation-8.example | 1 | primary | - |
| lens-cap-orientation-9.example | 1 | primary | - |
| lens-cap-question-0.example | 1 | primary | - |
| lens-cap-question-1.example | 1 | primary | - |
| lens-cap-question-2.example | 1 | primary | - |
| lens-cap-question-3.example | 1 | primary | - |
| lens-cap-synopsis-0.example | 1 | primary | - |
| lens-cap-synopsis-1.example | 1 | primary | - |
| lens-cap-synopsis-10.example | 1 | primary | - |
| lens-cap-synopsis-11.example | 1 | primary | - |
| lens-cap-synopsis-12.example | 1 | primary | - |
| lens-cap-synopsis-13.example | 1 | primary | - |
| lens-cap-synopsis-14.example | 1 | primary | - |
| lens-cap-synopsis-15.example | 1 | primary | - |
| lens-cap-synopsis-16.example | 1 | primary | - |
| lens-cap-synopsis-17.example | 1 | primary | - |
| lens-cap-synopsis-18.example | 1 | primary | - |
| lens-cap-synopsis-19.example | 1 | primary | - |
| lens-cap-synopsis-2.example | 1 | primary | - |
| lens-cap-synopsis-20.example | 1 | primary | - |
| lens-cap-synopsis-21.example | 1 | primary | - |
| lens-cap-synopsis-22.example | 1 | primary | - |
| lens-cap-synopsis-23.example | 1 | primary | - |
| lens-cap-synopsis-24.example | 1 | primary | - |
| lens-cap-synopsis-25.example | 1 | primary | - |
| lens-cap-synopsis-26.example | 1 | primary | - |
| lens-cap-synopsis-27.example | 1 | primary | - |
| lens-cap-synopsis-28.example | 1 | primary | - |
| lens-cap-synopsis-29.example | 1 | primary | - |
| lens-cap-synopsis-3.example | 1 | primary | - |
| lens-cap-synopsis-30.example | 1 | primary | - |
| lens-cap-synopsis-31.example | 1 | primary | - |
| lens-cap-synopsis-32.example | 1 | primary | - |
| lens-cap-synopsis-33.example | 1 | primary | - |
| lens-cap-synopsis-34.example | 1 | primary | - |
| lens-cap-synopsis-4.example | 1 | primary | - |
| lens-cap-synopsis-5.example | 1 | primary | - |
| lens-cap-synopsis-6.example | 1 | primary | - |
| lens-cap-synopsis-7.example | 1 | primary | - |
| lens-cap-synopsis-8.example | 1 | primary | - |
| lens-cap-synopsis-9.example | 1 | primary | - |
| trailing-condition-mechanism-0.example | 1 | primary | - |

---

Derived from study findings over a retained corpus. Positions are the expert's reading of that evidence, not verified fact; each states what would overturn it.
