# Fenn cache applicability: brief

## In sixty seconds

Studied sources (recorded attribution): Fenn catalogue caching can reduce repeated reads only for immutable public replies.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): Authenticated replies need tenant-scoped keys and revocation tracking.
Cited findings (study binding: not checked in this view): synopsis-0
Studied sources (recorded attribution): The inventory facts in the source corpus establish no general cache policy.
Cited findings (study binding: not checked in this view): synopsis-1, orientation-0, orientation-1, mechanism-1, failure-0, failure-1, contention-1, implication-0, implication-1, analogy-0, analogy-1, question-0, question-1

## Where I land, and why

1. **When may a cache entry be renewed for authenticated replies?**
   - Stance: Do not cache authenticated replies until tenant keys and revocation tracking are verified.
   - Because: An operator trial found account-specific replies leaked across tenants when tenant keys were absent. Public immutable replies were unaffected, indicating the risk is specific to authenticated data without proper scoping.
   - Confidence in that basis: high (Direct observation of leakage in an operator trial and explicit qualification in the source.)
   - Would change my mind: Evidence that tenant-scoped keys and revocation tracking are implemented and verified to prevent cross-tenant leakage in the specific Fenn environment.
   - Rests on: Fenn contention-0 (contention-0); Fenn synopsis-0 (synopsis-0)
   - Evidential depth: 2 source(s), 2 publisher(s)

2. **Is caching applicable to immutable public replies?**
   - Stance: Yes, caching can reduce repeated reads for immutable public replies.
   - Because: The source explicitly states that caching reduces repeated reads for this category and notes that public immutable replies were unaffected by the tenant leakage issue.
   - Confidence in that basis: high (Explicit statement in the source regarding the applicability of caching to this specific data type.)
   - Would change my mind: Evidence that public immutable replies are not actually immutable or that caching them causes other integrity issues not covered in the source.
   - Rests on: Fenn synopsis-0 (synopsis-0); Fenn contention-0 (contention-0)
   - Evidential depth: 2 source(s), 2 publisher(s)

3. **Does the source corpus define a general cache policy for Fenn?**
   - Stance: No, the inventory facts establish no general cache policy.
   - Because: Multiple findings across different lenses (synopsis, orientation, mechanism, failure, contention, implication, analogy, question) explicitly state that the inventory facts do not establish a cache policy. The only specific guidance is the restriction on authenticated replies and the allowance for public immutable ones.
   - Confidence in that basis: high (Consistent explicit statement across all non-specific findings.)
   - Would change my mind: Discovery of a separate document or section in the source corpus that explicitly defines a general cache policy beyond the specific constraints mentioned.
   - Rests on: Fenn synopsis-1 (synopsis-1); Fenn orientation-0 (orientation-0); Fenn orientation-1 (orientation-1); Fenn mechanism-1 (mechanism-1)
   - Evidential depth: 13 source(s), 13 publisher(s)

## Settled, live, unknown

**Settled (skip these)**
- Caching is applicable to immutable public replies.
- Caching authenticated replies is prohibited without verified tenant keys and revocation tracking.
- The source corpus does not contain a general cache policy definition.

**Live**
- Verification of tenant keys and revocation tracking in specific deployments.

**Genuinely unknown**
- Specific performance metrics for cache hits on public replies.
- Implementation details of the revocation tracking mechanism.

## What people try that does not work

- Attempting to cache authenticated replies without verifying tenant keys and revocation tracking, which leads to cross-tenant data leakage.
- Assuming that the absence of a general cache policy in the inventory facts means caching is universally allowed or prohibited, rather than recognizing the specific constraints on reply types.

## Questions I expect

**Why is this brief so limited if the source corpus is large?** (this one costs me something)
The majority of the findings explicitly state that they are inventory facts that do not establish a cache policy. The only substantive content is the specific constraint on authenticated replies and the allowance for public immutable ones. The brief reflects the actual content of the provided findings, not an assumption of missing data.
_Asked because: To challenge the completeness of the analysis._

**What is the difference between 'likelihood' and 'confidence' in this context?**
Likelihood refers to how probable the stance is true, while confidence refers to how sound the basis for the stance is. In this brief, likelihood is empty because the stances are not probabilistic forecasts but rather conditional rules or established facts. Confidence is high because the basis is direct citation from the source findings.
_Asked because: To clarify the distinction between the two metrics._

## Who this rests on

| Origin | Sources | Trust | Note |
|---|---|---|---|
| fenn-hosted.example | 1 | primary | - |
| fenn-manual.example | 1 | primary | - |
| fenn-monitor.example | 1 | primary | - |
| fenn-release.example | 1 | primary | - |
| fenn-self.example | 1 | primary | - |
| filler-0.example | 1 | tertiary | - |
| filler-1.example | 1 | tertiary | - |
| filler-10.example | 1 | tertiary | - |
| filler-11.example | 1 | tertiary | - |
| filler-12.example | 1 | tertiary | - |
| filler-13.example | 1 | tertiary | - |
| filler-2.example | 1 | tertiary | - |
| filler-3.example | 1 | tertiary | - |
| filler-4.example | 1 | tertiary | - |
| filler-5.example | 1 | tertiary | - |
| filler-6.example | 1 | tertiary | - |
| filler-7.example | 1 | tertiary | - |
| filler-8.example | 1 | tertiary | - |
| filler-9.example | 1 | tertiary | - |
| lens-cap-analogy-0.example | 1 | primary | - |
| lens-cap-analogy-1.example | 1 | primary | - |
| lens-cap-analogy-2.example | 1 | primary | - |
| lens-cap-analogy-3.example | 1 | primary | - |
| lens-cap-contention-0.example | 1 | primary | - |
| lens-cap-contention-1.example | 1 | primary | - |
| lens-cap-contention-2.example | 1 | primary | - |
| lens-cap-contention-3.example | 1 | primary | - |
| lens-cap-failure-0.example | 1 | primary | - |
| lens-cap-failure-1.example | 1 | primary | - |
| lens-cap-failure-10.example | 1 | primary | - |
| lens-cap-failure-11.example | 1 | primary | - |
| lens-cap-failure-12.example | 1 | primary | - |
| lens-cap-failure-13.example | 1 | primary | - |
| lens-cap-failure-14.example | 1 | primary | - |
| lens-cap-failure-15.example | 1 | primary | - |
| lens-cap-failure-16.example | 1 | primary | - |
| lens-cap-failure-17.example | 1 | primary | - |
| lens-cap-failure-18.example | 1 | primary | - |
| lens-cap-failure-19.example | 1 | primary | - |
| lens-cap-failure-2.example | 1 | primary | - |
| lens-cap-failure-20.example | 1 | primary | - |
| lens-cap-failure-21.example | 1 | primary | - |
| lens-cap-failure-22.example | 1 | primary | - |
| lens-cap-failure-23.example | 1 | primary | - |
| lens-cap-failure-24.example | 1 | primary | - |
| lens-cap-failure-25.example | 1 | primary | - |
| lens-cap-failure-26.example | 1 | primary | - |
| lens-cap-failure-27.example | 1 | primary | - |
| lens-cap-failure-28.example | 1 | primary | - |
| lens-cap-failure-29.example | 1 | primary | - |
| lens-cap-failure-3.example | 1 | primary | - |
| lens-cap-failure-30.example | 1 | primary | - |
| lens-cap-failure-31.example | 1 | primary | - |
| lens-cap-failure-32.example | 1 | primary | - |
| lens-cap-failure-33.example | 1 | primary | - |
| lens-cap-failure-34.example | 1 | primary | - |
| lens-cap-failure-4.example | 1 | primary | - |
| lens-cap-failure-5.example | 1 | primary | - |
| lens-cap-failure-6.example | 1 | primary | - |
| lens-cap-failure-7.example | 1 | primary | - |
| lens-cap-failure-8.example | 1 | primary | - |
| lens-cap-failure-9.example | 1 | primary | - |
| lens-cap-implication-0.example | 1 | primary | - |
| lens-cap-implication-1.example | 1 | primary | - |
| lens-cap-implication-2.example | 1 | primary | - |
| lens-cap-implication-3.example | 1 | primary | - |
| lens-cap-mechanism-0.example | 1 | primary | - |
| lens-cap-mechanism-1.example | 1 | primary | - |
| lens-cap-mechanism-10.example | 1 | primary | - |
| lens-cap-mechanism-11.example | 1 | primary | - |
| lens-cap-mechanism-12.example | 1 | primary | - |
| lens-cap-mechanism-13.example | 1 | primary | - |
| lens-cap-mechanism-14.example | 1 | primary | - |
| lens-cap-mechanism-15.example | 1 | primary | - |
| lens-cap-mechanism-16.example | 1 | primary | - |
| lens-cap-mechanism-17.example | 1 | primary | - |
| lens-cap-mechanism-18.example | 1 | primary | - |
| lens-cap-mechanism-19.example | 1 | primary | - |
| lens-cap-mechanism-2.example | 1 | primary | - |
| lens-cap-mechanism-20.example | 1 | primary | - |
| lens-cap-mechanism-21.example | 1 | primary | - |
| lens-cap-mechanism-22.example | 1 | primary | - |
| lens-cap-mechanism-23.example | 1 | primary | - |
| lens-cap-mechanism-24.example | 1 | primary | - |
| lens-cap-mechanism-25.example | 1 | primary | - |
| lens-cap-mechanism-26.example | 1 | primary | - |
| lens-cap-mechanism-27.example | 1 | primary | - |
| lens-cap-mechanism-28.example | 1 | primary | - |
| lens-cap-mechanism-29.example | 1 | primary | - |
| lens-cap-mechanism-3.example | 1 | primary | - |
| lens-cap-mechanism-30.example | 1 | primary | - |
| lens-cap-mechanism-31.example | 1 | primary | - |
| lens-cap-mechanism-32.example | 1 | primary | - |
| lens-cap-mechanism-33.example | 1 | primary | - |
| lens-cap-mechanism-34.example | 1 | primary | - |
| lens-cap-mechanism-4.example | 1 | primary | - |
| lens-cap-mechanism-5.example | 1 | primary | - |
| lens-cap-mechanism-6.example | 1 | primary | - |
| lens-cap-mechanism-7.example | 1 | primary | - |
| lens-cap-mechanism-8.example | 1 | primary | - |
| lens-cap-mechanism-9.example | 1 | primary | - |
| lens-cap-orientation-0.example | 1 | primary | - |
| lens-cap-orientation-1.example | 1 | primary | - |
| lens-cap-orientation-10.example | 1 | primary | - |
| lens-cap-orientation-11.example | 1 | primary | - |
| lens-cap-orientation-12.example | 1 | primary | - |
| lens-cap-orientation-13.example | 1 | primary | - |
| lens-cap-orientation-14.example | 1 | primary | - |
| lens-cap-orientation-15.example | 1 | primary | - |
| lens-cap-orientation-16.example | 1 | primary | - |
| lens-cap-orientation-17.example | 1 | primary | - |
| lens-cap-orientation-18.example | 1 | primary | - |
| lens-cap-orientation-19.example | 1 | primary | - |
| lens-cap-orientation-2.example | 1 | primary | - |
| lens-cap-orientation-20.example | 1 | primary | - |
| lens-cap-orientation-21.example | 1 | primary | - |
| lens-cap-orientation-22.example | 1 | primary | - |
| lens-cap-orientation-23.example | 1 | primary | - |
| lens-cap-orientation-24.example | 1 | primary | - |
| lens-cap-orientation-25.example | 1 | primary | - |
| lens-cap-orientation-26.example | 1 | primary | - |
| lens-cap-orientation-27.example | 1 | primary | - |
| lens-cap-orientation-28.example | 1 | primary | - |
| lens-cap-orientation-29.example | 1 | primary | - |
| lens-cap-orientation-3.example | 1 | primary | - |
| lens-cap-orientation-30.example | 1 | primary | - |
| lens-cap-orientation-31.example | 1 | primary | - |
| lens-cap-orientation-32.example | 1 | primary | - |
| lens-cap-orientation-33.example | 1 | primary | - |
| lens-cap-orientation-34.example | 1 | primary | - |
| lens-cap-orientation-4.example | 1 | primary | - |
| lens-cap-orientation-5.example | 1 | primary | - |
| lens-cap-orientation-6.example | 1 | primary | - |
| lens-cap-orientation-7.example | 1 | primary | - |
| lens-cap-orientation-8.example | 1 | primary | - |
| lens-cap-orientation-9.example | 1 | primary | - |
| lens-cap-question-0.example | 1 | primary | - |
| lens-cap-question-1.example | 1 | primary | - |
| lens-cap-question-2.example | 1 | primary | - |
| lens-cap-question-3.example | 1 | primary | - |
| lens-cap-synopsis-0.example | 1 | primary | - |
| lens-cap-synopsis-1.example | 1 | primary | - |
| lens-cap-synopsis-10.example | 1 | primary | - |
| lens-cap-synopsis-11.example | 1 | primary | - |
| lens-cap-synopsis-12.example | 1 | primary | - |
| lens-cap-synopsis-13.example | 1 | primary | - |
| lens-cap-synopsis-14.example | 1 | primary | - |
| lens-cap-synopsis-15.example | 1 | primary | - |
| lens-cap-synopsis-16.example | 1 | primary | - |
| lens-cap-synopsis-17.example | 1 | primary | - |
| lens-cap-synopsis-18.example | 1 | primary | - |
| lens-cap-synopsis-19.example | 1 | primary | - |
| lens-cap-synopsis-2.example | 1 | primary | - |
| lens-cap-synopsis-20.example | 1 | primary | - |
| lens-cap-synopsis-21.example | 1 | primary | - |
| lens-cap-synopsis-22.example | 1 | primary | - |
| lens-cap-synopsis-23.example | 1 | primary | - |
| lens-cap-synopsis-24.example | 1 | primary | - |
| lens-cap-synopsis-25.example | 1 | primary | - |
| lens-cap-synopsis-26.example | 1 | primary | - |
| lens-cap-synopsis-27.example | 1 | primary | - |
| lens-cap-synopsis-28.example | 1 | primary | - |
| lens-cap-synopsis-29.example | 1 | primary | - |
| lens-cap-synopsis-3.example | 1 | primary | - |
| lens-cap-synopsis-30.example | 1 | primary | - |
| lens-cap-synopsis-31.example | 1 | primary | - |
| lens-cap-synopsis-32.example | 1 | primary | - |
| lens-cap-synopsis-33.example | 1 | primary | - |
| lens-cap-synopsis-34.example | 1 | primary | - |
| lens-cap-synopsis-4.example | 1 | primary | - |
| lens-cap-synopsis-5.example | 1 | primary | - |
| lens-cap-synopsis-6.example | 1 | primary | - |
| lens-cap-synopsis-7.example | 1 | primary | - |
| lens-cap-synopsis-8.example | 1 | primary | - |
| lens-cap-synopsis-9.example | 1 | primary | - |
| trailing-condition-mechanism-0.example | 1 | primary | - |

## Read this brief knowing

- No position records unresolved dissent. That is possible, and it is also what a brief looks like when disagreement has been averaged away; check the study findings for contention the brief did not carry forward.

---

Derived from study findings over a retained corpus. Positions are the expert's reading of that evidence, not verified fact; each states what would overturn it.
