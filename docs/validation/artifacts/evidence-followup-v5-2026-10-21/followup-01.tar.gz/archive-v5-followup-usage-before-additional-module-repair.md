# V5 negative-trial archive helper

The exact reviewed inventory is `archive-v5-allowlist.json`. Its root and public
output are fixed to this task and the new
`docs/validation/artifacts/evidence-followup-v5-2026-10-21` directory. V6 and all
old published archives are separate. Existing or interrupted output is refused.

The helper is import-safe, stdlib-only, and dispatches no inference. It captures
approved bytes once, checks frozen metadata and both first-open chronologies,
then checks complete primary/quality judgments, every scheduled cell, source
world, prompt, native accounting and actual rendered briefs. It opens the two
already-opened method keys only after those guards. Archived code and generated
text are untrusted data; none is executed during validation or packing.

The baseline is the exact legacy brief and explicitly approved external legacy
consult file, bound to the V5 manifest. The current recipe is the exact 20-file
snapshot inventory. The unchanged prior public index is retained as a hash-bound
reference for earlier recipe/dependency provenance; this does not claim complete
runtime/daemon reproducibility. The root's negative assessment is retained as
`issue258-v5-semantic-assessment.json`; the archiver grants no acceptance.

The operator may run the export only with the independently reviewed config
SHA-256 supplied as a literal argument:

```text
python .agent/issue-completion-2026-10-20/archive_v5_followup.py \
  --config-sha256 REVIEWED_CONFIG_SHA256
```

The helper never discovers extra files through globs. Missing required evidence,
changed commitments, private paths, symlinks, or unsafe snapshot references fail
closed. All failed/form-failed drafts and explicit no-return records remain in
the 32-cell denominator. Every archive part, index and completion receipt must
be strictly below 500 KiB; a single oversized source causes refusal, never
clipping or dropping. Exact tar membership and bytes are checked in memory
before exclusive output creation. Files and directories are fsynced; only the
last-written `COMPLETE.json` plus its matching index/parts denotes completion.
Partial output is preserved and blocks retry rather than overwriting evidence.

`check_archive_v5_followup_R1.py` uses a temporary isolated synthetic tree. Its
checks do not load any real key, returned answer or peer judgment, or run the
real export. Synthetic archived code is never executed. The latest retained
check receipt is `reviewers/R1/archive-v5-synthetic-checks-v3.json`.
