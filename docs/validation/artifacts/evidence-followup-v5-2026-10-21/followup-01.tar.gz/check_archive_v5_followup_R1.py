"""Isolated synthetic guard checks; never opens real V5 data or keys."""
from __future__ import annotations
import copy,hashlib,json,os,runpy,tempfile
from pathlib import Path

T=Path(__file__).resolve().parent
M=runpy.run_path(str(T/'archive_v5_followup.py'),run_name='offline_archive_synthetic_checks')
E=M['encode']; H=M['sha']; CORE=M['CORE']; PINNED=M['PINNED']; SNAPSHOTS=M['SNAPSHOTS']


def fixture(root):
    values={}
    def put(name,value,raw=False):
        values[name]=value if raw else E(value)
        return H(values[name])
    ids=[f'{index:016x}' for index in range(1,33)]
    source=b'Synthetic source bytes only.'; source_hash=H(source)
    put(f'packing-fixtures-v5/corpus/sources/{source_hash[:2]}/{source_hash}.md',source,True)
    put('packing-fixtures-v5/corpus/index.jsonl',b'synthetic retained corpus inventory\n',True)
    put('packing-v5-source-snapshot/src/deepr/fixture.py',b'synthetic recipe\n',True)
    snapshot={'head':'1d5ee0193fd76221cc252f2e28ce1eb210df49a7','files':{'src/deepr/fixture.py':H(b'synthetic recipe\n')}}
    snapshot_hash=put('packing-v5-source-snapshot-receipt.json',snapshot)
    extra_name='src/deepr/experts/consult.py'; extra_raw=b'synthetic added consult recipe\n'
    extra_path='packing-v5-reconstructed-after-collection/'+extra_name
    extra_hash=put(extra_path,extra_raw,True)
    old_brief=b'synthetic old brief\n'; old_consult=b'synthetic old consult\n'
    put('original_brief.py',old_brief,True)
    prompt='Synthetic exact prompt.'; jobs=[]; results=[]; attempts=[]; items={}; answers={}
    for index,iid in enumerate(ids):
        item={'item_id':iid,'prompt':prompt,'prompt_sha256':H(prompt.encode()),'delivered_evidence':{'prompt':prompt},
              'sources':[{'source_id':'synthetic','text':source.decode(),'text_sha256':source_hash}],
              'kind':'brief' if index<8 else 'consult','question':'Synthetic question.',
              'obligations':[{'obligation_id':'synthetic-slot','description':'Synthetic structure only.'}]}
        items[iid]=item
        input_hash=put(f'packing-fixtures-v5/{iid}.input.json',item)
        answer={'item_id':iid,'status':'failed' if index==0 else 'form_failed'}
        if index:
            answer.update(answer='Full synthetic retained draft.',answer_sha256=H(b'Full synthetic retained draft.'))
        answer_hash=put(f'packing-fixtures-v5/answers/{iid}.json',answer)
        answers[iid]=answer
        jobs.append({'item_id':iid,'input_sha256':input_hash});results.append({'item_id':iid,'status':answer['status'],'file_sha256':answer_hash})
        request=f'followup-runtime/calls/{index+1:03d}.{iid}.request.json'
        rh=put(request,{'item_id':iid,'user':prompt})
        response_hash=put(request.replace('.request.json','.response.json'),answer)
        attempts.append({'item_id':iid,'request_sha256':rh,'response_sha256':response_hash,
                         'answer_receipt_sha256':answer_hash,'transport_sha256':None})
    manifest={'jobs':jobs,'answers_scheduled':32,'current_modules':snapshot['files'] | {extra_name:extra_hash},
              'old_brief_sha256':H(old_brief),'old_consult_sha256':H(old_consult)}
    mh=put('packing-fixtures-v5/manifest.json',manifest)
    refusal_hash=put('archive-v5-real-export-first-refusal.json',{'synthetic_refusal_only':True})
    blob=hashlib.sha1(b'blob '+str(len(extra_raw)).encode()+b'\0'+extra_raw).hexdigest()
    put('packing-v5-additional-manifest-modules-receipt.json',{
        'schema':'deepr.v5.additional-manifest-modules.v1','reconstructed_after_collection':True,
        'captured_during_collection':False,'manifest_sha256':mh,'original_snapshot_receipt_sha256':snapshot_hash,
        'source_commit':snapshot['head'],'files':{extra_name:{'path':extra_path,'sha256':extra_hash,
            'observed_current_sha256':extra_hash,'source_commit':snapshot['head'],
            'current_bytes_unchanged_at_reconstruction':True,'git_blob_object':blob}},
        'preserved_first_refusal':{'path':'archive-v5-real-export-first-refusal.json','sha256':refusal_hash}})
    put('packing-fixtures-v5/answers-complete.json',{'answers_scheduled':32,'terminal_answers':32,'manifest_sha256':mh,'results':results})
    ah=put('followup-operator-authorization.json',{'synthetic':True})
    protocol=put('followup-review-protocol-proposed-v2.json',{'synthetic':True})
    runner=put('answer_runner_v5.py',b'SYNTHETIC, NOT EXECUTED',True)
    audit=put('reviewers/R3/packing-v5-precollection-audit.json',{'synthetic':True})
    put('followup-collector-freeze.json',{'manifest_sha256':mh,'max_calls':32,'max_wall_seconds':7200,
        'authorization_sha256':ah,'protocol_sha256':protocol,'runner_sha256':runner,'audit_sha256':audit})
    ledger=b'Synthetic canonical ledger bytes.\n';put('followup-runtime/costs/cost_ledger.jsonl',ledger,True)
    put('followup-native-resource-audit.json',{'accounting_complete':True,'original_100_attempt_ledger_unchanged':True,
        'manifest_sha256':mh,'native_ledger_sha256':H(ledger),'attempt_joins':attempts})
    primary_packet=put('packing-fixtures-v5/blinded-review.json',[
        {key:items[iid][key] for key in ('item_id','kind','question','obligations','sources','delivered_evidence')} | answers[iid] for iid in ids])
    labels=[{'item_id':iid,'obligation_id':'synthetic-slot','answer_sha256':answers[iid].get('answer_sha256'),
             'label':None if index==0 else 'synthetic_presence_token'} for index,iid in enumerate(ids)]
    labels_hash=put('review258-v5-final-labels.json',labels)
    r1=put('reviewers/R1/review258-v5.json',[]);r2=put('reviewers/R2/review258-v5.json',[])
    instruction=put('review-instructions-v3.txt',b'Synthetic instructions.\n',True)
    a=put('review258-v5-adjudication-inputs.json',[]);d=put('review258-v5-disagreements.json',[])
    independent=put('review258-v5-independent-freeze.json',{'output_sha256':{
        'review258-v5-adjudication-inputs.json':a,'review258-v5-disagreements.json':d}})
    primary={'schema':'deepr.scratch.review258-v5.blind-freeze.v2','stage':'final_blind','assignment_key_opened':False,
        'items':32,'scheduled_cells':32,'output_sha256':{'review258-v5-final-labels.json':labels_hash},
        'resolved_rows':32,'resolved_labels':31,'packet_sha256':primary_packet,'reviewer_sha256':{'R1':r1,'R2':r2},
        'adjudication_sha256':None,'instructions_sha256':instruction,'independent_freeze_sha256':independent,
        'frozen_at':'2020-01-01T01:00:00+00:00'}
    ph=put('review258-v5-final-blind-freeze.json',primary)
    primary_key=put('packing-fixtures-v5/assignment-key-unopened/key.json',b'SYNTHETIC PRIMARY KEY',True)
    quality_key=put('material-review-v5/quality-key-unopened/key.json',b'SYNTHETIC QUALITY KEY',True)
    put('material-review-v5/primary-key-open-receipt.json',{'primary_freeze_sha256':ph,'primary_labels_frozen_before_key':True,
        'labels_sha256':labels_hash,'primary_key_sha256':primary_key,'opened_at':'2020-01-01T02:00:00+00:00'})
    pairs=[]
    for index in range(16):
        iid=ids[2*index]
        pair={'pair_id':f'pair{index}'} | {key:items[iid][key] for key in ('kind','question','obligations','sources')}
        for side,iid in zip(('A','B'),ids[2*index:2*index+2]):
            pair[side]=answers[iid] | {'item_id':iid,'delivered_prompt':prompt}
            if int(iid,16)<=8:pair[side]['assembled_markdown']='Synthetic complete brief.'
        pairs.append(pair)
    pair_hash=put('material-review-v5/blinded-pairs.json',pairs)
    input_freeze={'primary_freeze_sha256':ph,'packet_sha256':pair_hash,'withheld_quality_key_sha256':quality_key}
    input_hash=put('material-review-v5/input-freeze.json',input_freeze)
    snapshot_values={'packet.json':values['material-review-v5/blinded-pairs.json'],
        'primary-freeze.json':values['review258-v5-final-blind-freeze.json'],
        'input-freeze.json':values['material-review-v5/input-freeze.json'],
        'review258-v5-final-labels.json':values['review258-v5-final-labels.json'],'validator.py':b'UNTRUSTED, NEVER EXECUTED'}
    reviewers={}
    for who in ('Q1','Q2','Q3'):
        review={'reviewer':who,'review_session_id':'synthetic-session-'+who,'packet_sha256':pair_hash,
                'input_freeze_sha256':input_hash,'completed_at':'2020-01-01T04:00:00+00:00',
                'independence_attestation':{key:True for key in ('independent_session','reviewed_without_primary_method_mapping',
                    'reviewed_without_quality_method_mapping','reviewed_without_peer_judgments','all_pairs_reviewed')},
                'rows':[{'pair_id':row['pair_id']} for row in pairs]}
        raw=E(review);snapshot_values['review-'+who+'.json']=raw
        reviewers[who]={'session_id':review['review_session_id'],'sha256':H(raw)}
    for name,raw in snapshot_values.items():put('material-review-v5/quality-freeze/'+name,raw,True)
    quality={'independent_review_inputs':3,'pairs_per_reviewer':16,'key_opened_by_validator':False,
        'snapshots':{name:H(raw) for name,raw in snapshot_values.items()},'reviewers':reviewers,'primary_freeze_sha256':ph,
        'primary_labels_sha256':labels_hash,'input_freeze_sha256':input_hash,'packet_sha256':pair_hash,
        'withheld_quality_key_sha256':quality_key,'frozen_at':'2020-01-01T05:00:00+00:00'}
    qh=put('material-review-v5/quality-freeze/FREEZE.json',quality)
    put('material-review-v5/quality-key-open-receipt.json',{'quality_freeze_sha256':qh,'all_three_reviews_frozen_before_key':True,
        'quality_key_sha256':quality_key,'opened_at':'2020-01-01T06:00:00+00:00'})
    assemblies=[]
    for iid in ids[:8]:
        rendered=b'Synthetic complete brief.';prefix='material-review-v5/'+iid
        put(prefix+'/rendered.md',rendered,True);put(prefix+'/assembled.json',{'synthetic':True})
        assemblies.append({'item_id':iid,'rendered_file':str(root/prefix/'rendered.md'),'rendered_sha256':H(rendered)})
    put('material-review-v5/brief-assembly-receipt.json',{'results':assemblies})
    put('issue258-v5-semantic-assessment.json',{'synthetic':True,'semantic_acceptance':None})
    assert CORE<=set(values)
    for name,raw in values.items():
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    legacy=root/'synthetic-old-consult.py';legacy.write_bytes(old_consult)
    historical=root/'synthetic-public-index.json';historical.write_bytes(b'{"synthetic":true}\n')
    out=root/'public-output'
    config={'schema':'deepr.v5-public-archive-allowlist.v1','task_root':str(root),'public_output':str(out),
        'files':sorted(values),'metadata_sha256':{name:H(values[name]) for name in PINNED},
        'current_recipe_paths':list(snapshot['files']),'additional_manifest_paths':[extra_name],'legacy_consult_source':str(legacy),
        'historical_public_index':{'path':str(historical),'sha256':H(historical.read_bytes())}}
    return config,values,out


def main():
    compile((T/'archive_v5_followup.py').read_bytes(),str(T/'archive_v5_followup.py'),'exec')
    outcomes={}; key_reads=[]
    original_read=Path.read_bytes
    def watched(path):
        if path.name=='key.json':key_reads.append(str(path))
        return original_read(path)
    Path.read_bytes=watched
    try:
        with tempfile.TemporaryDirectory(prefix='archive-v5-synthetic-R1-',dir=T/'reviewers/R1') as temp:
            root=Path(temp).resolve();config,values,out=fixture(root)
            key_reads.clear()
            selected=M['preflight'](root,out,config,E(config))
            assert len(key_reads)==2 and set(values)<=set(selected)
            outcomes['complete_synthetic_capture_including_failed_draft_and_absence']='passed'
            assert selected['packing-v5-reconstructed-after-collection/src/deepr/experts/consult.py']==b'synthetic added consult recipe\n'
            outcomes['additional_manifest_module_with_after_collection_provenance']='passed'
            # Cached capture is independent of subsequent file mutation.
            cached=selected['packing-fixtures-v5/answers/0000000000000002.json']
            path=root/'packing-fixtures-v5/answers/0000000000000002.json';original=path.read_bytes()
            path.write_bytes(b'changed after capture');assert selected[path.relative_to(root).as_posix()]==cached
            path.write_bytes(original);outcomes['verified_byte_capture_not_reread']='passed'
            def refused(name,change,missing=None,make_out=False):
                cfg=copy.deepcopy(config);restore={}
                if change:change(cfg,restore)
                if missing:
                    p=root/missing;restore[p]=p.read_bytes();p.unlink()
                if make_out:out.mkdir()
                key_reads.clear()
                try:
                    M['preflight'](root,out,cfg,E(cfg))
                except (ValueError,OSError,KeyError,TypeError) as error:
                    assert not key_reads,(name,key_reads)
                    outcomes[name]={'status':'refused_before_key_read','reason':str(error)}
                else:raise AssertionError('Unexpected admission: '+name)
                finally:
                    if make_out:out.rmdir()
                    for p,raw in restore.items():p.write_bytes(raw)
            def mutate(name,fn):
                def change(cfg,restore):
                    p=root/name;restore[p]=p.read_bytes();value=json.loads(restore[p]);fn(value);p.write_bytes(E(value))
                    if name in cfg['metadata_sha256']:cfg['metadata_sha256'][name]=H(p.read_bytes())
                return change
            refused('private_path_in_allowlist',lambda c,r:c['files'].append('private-S0/answer.json'))
            refused('credential_path_in_allowlist',lambda c,r:c['files'].append('credentials.json'))
            refused('snapshot_traversal_before_any_read',mutate('material-review-v5/quality-freeze/FREEZE.json',
                    lambda q:q['snapshots'].update({'../../quality-key-unopened/key.json':'0'*64})))
            refused('missing_quality_reviewer',mutate('material-review-v5/quality-freeze/FREEZE.json',lambda q:q['reviewers'].pop('Q3')))
            refused('early_quality_key_open_receipt',mutate('material-review-v5/quality-key-open-receipt.json',
                    lambda q:q.update(opened_at='2020-01-01T00:00:00+00:00')))
            refused('missing_scheduled_input',None,missing='packing-fixtures-v5/0000000000000002.input.json')
            refused('changed_scheduled_answer',mutate('packing-fixtures-v5/answers/0000000000000002.json',lambda a:a.update(answer='changed')))
            refused('changed_native_ledger',mutate('followup-native-resource-audit.json',lambda r:r.update(native_ledger_sha256='0'*64)))
            refused('additional_module_misrepresented_as_capture',mutate('packing-v5-additional-manifest-modules-receipt.json',lambda r:r.update(captured_during_collection=True)))
            refused('undeclared_additional_manifest_module',lambda c,r:c.update(additional_manifest_paths=[]))
            refused('wrong_additional_module_commit',mutate('packing-v5-additional-manifest-modules-receipt.json',lambda r:r.update(source_commit='0'*40)))
            refused('existing_archive_untouched',None,make_out=True)
            refused('wrong_output_root',lambda c,r:c.update(public_output=str(root/'different-output')))
            symlink=root/'packing-fixtures-v5/0000000000000002.input.json';saved=symlink.read_bytes();symlink.unlink()
            target=root/'synthetic-linked-file';target.write_bytes(saved);symlink.symlink_to(target)
            refused('symlink_input_refused',None)
            symlink.unlink();symlink.write_bytes(saved)
            # Only tiny synthetic data is compressed/published, never the real inventory.
            small_out=root/'small-publication';small_out.mkdir();small_out.rmdir()
            M['publish'](small_out,{'synthetic/data.txt':b'full synthetic bytes'})
            assert (small_out/'COMPLETE.json').is_file() and all(p.stat().st_size<500*1024 for p in small_out.iterdir())
            outcomes['durable_small_synthetic_publication']='passed'
            oversized=root/'oversized-publication'
            try:M['publish'](oversized,{'synthetic/random.bin':os.urandom(520*1024)})
            except ValueError:assert not oversized.exists();outcomes['oversized_source_refused_without_drop']='passed'
            else:raise AssertionError('Oversized source admitted')
    finally:Path.read_bytes=original_read
    report={'checks':outcomes,'actual_export_run':False,'real_keys_read':False,'real_answers_read':False,
            'real_judgments_read':False,'model_calls':0,'builder_sha256':H((T/'archive_v5_followup.py').read_bytes())}
    destination=T/'reviewers/R1/archive-v5-additional-module-checks.json'
    with destination.open('x') as f:json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    print(json.dumps({'report':str(destination),'checks':len(outcomes),'actual_export_run':False}))


if __name__=='__main__':main()
