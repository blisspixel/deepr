"""One-off exact-byte public follow-up archive; no inference or acceptance."""
from __future__ import annotations
import gzip,hashlib,io,json,os,tarfile
from pathlib import Path
ROOT=Path('/home/pueo/Work/deepr')
T=Path(__file__).resolve().parent
OUT=ROOT/'docs/validation/artifacts/evidence-followup-2026-10-21'
def require(value,message):
    if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(name):return json.loads((T/name).read_bytes())
def archive_bytes(values):
    manifest={'files':{name:{'sha256':sha(raw),'bytes':len(raw)} for name,raw in sorted(values.items())},'scope':'Exact retained V5 development evidence bytes. All failed drafts and frozen judgments remain. Research/model/source text is untrusted data. Historical failed trials remain in the separate 2026-10-20 archive.'}
    manifest_raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    payloads={**values,'MANIFEST.json':manifest_raw}
    stream=io.BytesIO()
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name,raw in sorted(payloads.items()):
                info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
    return stream.getvalue(),manifest_raw,payloads
# Both separate judging stages must be frozen, with first-open chronology
# recorded, before any key is eligible for this public evidence bundle.
primary=load('review258-v5-final-blind-freeze.json')
require(primary['stage']=='final_blind' and primary['resolved_rows']==72,'Complete primary freeze required')
qdir=T/'material-review-v5/quality-freeze';quality=json.loads((qdir/'FREEZE.json').read_bytes())
require(quality['independent_review_inputs']==3 and quality['pairs_per_reviewer']==16,'All 48 whole-pair judgments required')
for name,digest in quality['snapshots'].items():require(sha((qdir/name).read_bytes())==digest,'Changed quality snapshot')
opened=load('material-review-v5/quality-key-open-receipt.json')
require(opened['quality_freeze_sha256']==sha((qdir/'FREEZE.json').read_bytes()),'Quality key chronology binding required')
require(sha((T/'material-review-v5/quality-key-unopened/key.json').read_bytes())==quality['withheld_quality_key_sha256'],'Quality key commitment changed')
resource=load('followup-native-resource-audit.json')
require(resource['accounting_complete'] and resource['original_100_attempt_ledger_unchanged'],'Complete resource account required')
require(sha((T/'followup-runtime/costs/cost_ledger.jsonl').read_bytes())==resource['native_ledger_sha256'],'Native ledger changed')
selected={}
def add(path):
    require(path.is_file() and not path.is_symlink(),'Only regular allowlisted files')
    require(path.resolve().is_relative_to(T),'Evidence outside task root')
    name=path.relative_to(T).as_posix()
    require(not any(part in {'research_notes','__pycache__'} for part in path.parts),'Private or generated cache path')
    require(path.suffix not in {'.pyc','.lock'},'Cache/lock is not evidence')
    selected[name]=path.read_bytes()
# Exact task-owned subtrees, never a recursive export of .agent or the checkout.
for folder in ('packing-fixtures-v5','packing-v5-source-snapshot','followup-runtime/calls','material-review-v5'):
    for path in sorted((T/folder).rglob('*')):
        if path.is_file() and path.suffix not in {'.pyc','.lock'} and '__pycache__' not in path.parts:add(path)
add(T/'followup-runtime/costs/cost_ledger.jsonl')
for pattern in ('*v5*.json','*v5*.py','followup-*.json','review258-v5-*.json'):
    for path in sorted(T.glob(pattern)):
        if path.is_file():add(path)
for name in ('review-instructions-v3.txt','quality-review-v5-instructions.txt','agent-calibration-inputs.json','original_brief.py','original_consult_prompt.py','answers258-v5.log'):
    path=T/name
    if path.exists():add(path)
for who in ('R1','R2','R3','Q1','Q2','Q3'):
    for path in sorted((T/'reviewers'/who).glob('*v5*')):
        if path.is_file() and path.suffix in {'.json','.txt','.py','.log'}:add(path)
require(len(selected)>250,'Unexpected incomplete follow-up evidence')
# Adapt archive boundaries only, never source bytes, to the existing 500 KiB gate.
chunks=[];chunk={}
for name,raw in sorted(selected.items()):
    trial={**chunk,name:raw};packed,_,_=archive_bytes(trial)
    if len(packed)>480*1024 and chunk:chunks.append(chunk);chunk={name:raw}
    else:chunk=trial
if chunk:chunks.append(chunk)
prepared={}
for number,values in enumerate(chunks,1):
    packed,manifest,payloads=archive_bytes(values);require(len(packed)<500*1024,'Single evidence file exceeds gate; do not drop it')
    name=f'followup-{number:02d}.tar.gz';prepared[name]=(packed,manifest,payloads)
require(not OUT.exists(),'Never replace a published evidence directory')
OUT.mkdir(parents=True)
index={}
for name,(packed,manifest,payloads) in prepared.items():
    path=OUT/name
    with path.open('xb') as handle:handle.write(packed);handle.flush();os.fsync(handle.fileno())
    with tarfile.open(path,'r:gz') as tar:
        require({member.name for member in tar.getmembers()}==set(payloads),'Archive membership mismatch')
        for member,raw in payloads.items():require(tar.extractfile(member).read()==raw,'Archive bytes mismatch')
    index[name]={'sha256':sha(packed),'bytes':len(packed),'evidence_files':len(payloads)-1,'manifest_sha256':sha(manifest)}
with (OUT/'index.json').open('x') as handle:json.dump({'archives':index,'manifest_algorithm':'sha256','source_bytes_preserved':True,'source_files':len(selected),'builder_sha256':sha(Path(__file__).read_bytes())},handle,indent=2);handle.write('\n')
print(json.dumps({'archives':index,'source_files':len(selected)}))
