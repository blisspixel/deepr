"""Archive one explicitly inventoried negative V5 trial. No inference or acceptance.

The real export is operator-run only. Importing this module has no side effects.
Every source is captured once and all checks consume those same retained bytes.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import re
import stat
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

T = Path(__file__).resolve().parent
REPO = Path('/home/pueo/Work/deepr')
LIMIT = 500 * 1024
KEYS = {'packing-fixtures-v5/assignment-key-unopened/key.json', 'material-review-v5/quality-key-unopened/key.json'}
SNAPSHOTS = {'packet.json', 'primary-freeze.json', 'input-freeze.json', 'review258-v5-final-labels.json',
             'validator.py', 'review-Q1.json', 'review-Q2.json', 'review-Q3.json'}
TERMINAL = {'completed', 'truncated', 'empty_answer', 'form_failed', 'malformed_brief', 'failed', 'cancelled',
            'refused_followup_bound', 'refused_followup_integrity'}
CORE = {'packing-fixtures-v5/manifest.json', 'packing-fixtures-v5/answers-complete.json',
        'packing-fixtures-v5/blinded-review.json', 'review258-v5-final-blind-freeze.json',
        'review258-v5-final-labels.json', 'review258-v5-independent-freeze.json',
        'material-review-v5/quality-freeze/FREEZE.json', 'material-review-v5/input-freeze.json',
        'material-review-v5/blinded-pairs.json', 'material-review-v5/primary-key-open-receipt.json',
        'material-review-v5/quality-key-open-receipt.json', 'material-review-v5/brief-assembly-receipt.json',
        'followup-collector-freeze.json', 'followup-native-resource-audit.json',
        'followup-runtime/costs/cost_ledger.jsonl', 'packing-v5-source-snapshot-receipt.json',
        'packing-fixtures-v5/corpus/index.jsonl', 'original_brief.py', 'issue258-v5-semantic-assessment.json'} | KEYS
PINNED = {'packing-fixtures-v5/manifest.json', 'packing-fixtures-v5/answers-complete.json',
          'review258-v5-final-blind-freeze.json', 'material-review-v5/quality-freeze/FREEZE.json',
          'material-review-v5/primary-key-open-receipt.json', 'material-review-v5/quality-key-open-receipt.json',
          'followup-collector-freeze.json', 'followup-native-resource-audit.json',
          'packing-v5-source-snapshot-receipt.json', 'material-review-v5/brief-assembly-receipt.json'}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON object key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def digest(value):
    require(isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'Invalid SHA-256 commitment')
    return value


def instant(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None and parsed.utcoffset() is not None, 'Timezone-aware chronology required')
    return parsed


def safe_name(name, keys=False):
    require(isinstance(name, str) and name and '\\' not in name, 'Invalid inventory path')
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name and all(part not in {'.', '..'} for part in path.parts),
            'Absolute/traversal/noncanonical inventory path')
    for part in path.parts:
        lower = part.lower()
        require(not (lower in {'research_notes', '__pycache__', 's0', '.env'} or lower.startswith('private')
                     or 'credential' in lower or 'secret' in lower or lower.endswith(('.pyc', '.lock'))),
                'Protected private/credential/cache path')
    if name in KEYS:
        require(keys, 'Key read attempted before complete chronology guards')
    else:
        require(not any('assignment-key' in part or 'key-unopened' in part or part == 'key.json' for part in path.parts),
                'Unapproved key path')
    return name


def regular(path, root):
    require(path.is_relative_to(root), 'Input outside reviewed task root')
    cursor = root
    for part in path.relative_to(root).parts:
        cursor = cursor / part
        require(not cursor.is_symlink(), 'Symlink input/parent refused')
    require(path.is_file() and stat.S_ISREG(path.stat().st_mode), 'Required regular input absent')
    return path


class Capture:
    def __init__(self, root, config):
        self.root = root
        paths = config['files']
        require(isinstance(paths, list) and len(paths) == len(set(paths)), 'Duplicate/invalid allowlist')
        self.allowed = set(paths)
        for name in paths:
            safe_name(name, keys=name in KEYS)
        require(CORE <= self.allowed, 'Required fixed evidence missing from explicit allowlist')
        self.pins = config['metadata_sha256']
        require(isinstance(self.pins, dict) and set(self.pins) <= self.allowed, 'Invalid metadata pins')
        require(PINNED <= set(self.pins), 'Critical metadata commitments missing')
        for value in self.pins.values():
            digest(value)
        self.values = {}
        self.keys_allowed = False

    def raw(self, name, expected=None):
        require(name in self.allowed, 'Input not in explicit reviewed allowlist: ' + name)
        safe_name(name, keys=self.keys_allowed)
        if name not in self.values:
            self.values[name] = regular(self.root / name, self.root).read_bytes()
        raw = self.values[name]
        for value in (self.pins.get(name), expected):
            if value is not None:
                require(sha(raw) == digest(value), 'Changed evidence: ' + name)
        return raw

    def obj(self, name, expected=None):
        return parse(self.raw(name, expected))


def preflight(root, out, config, config_raw):
    root = root.resolve()
    require(config['schema'] == 'deepr.v5-public-archive-allowlist.v1', 'Wrong archive config')
    require(str(root) == config['task_root'], 'Task-root guard mismatch')
    require(str(out.absolute()) == config['public_output'], 'Public-output guard mismatch')
    if root == T:
        require(out == REPO / 'docs/validation/artifacts/evidence-followup-v5-2026-10-21', 'V5-only output guard mismatch')
    else:
        require(out.is_relative_to(root), 'Synthetic output must remain inside isolated task root')
    require(not out.exists() and not out.is_symlink(), 'Never mutate an existing archive or partial publication')
    require(out.parent.is_dir() and not out.parent.is_symlink(), 'Existing regular output parent required')
    require(out.parent.resolve() == out.parent.absolute(), 'Symlink output ancestor refused')
    c = Capture(root, config)
    # Metadata reads only. No arbitrary snapshot reference or key is followed.
    manifest = c.obj('packing-fixtures-v5/manifest.json')
    completion = c.obj('packing-fixtures-v5/answers-complete.json')
    jobs = manifest['jobs']
    ids = {job['item_id'] for job in jobs}
    require(len(jobs) == len(ids) == manifest['answers_scheduled'] == completion['answers_scheduled'] == completion['terminal_answers'] == 32,
            'All 32 scheduled terminal cells required')
    require(all(re.fullmatch('[0-9a-f]{16}', item) for item in ids), 'Unexpected opaque item ID')
    results = {row['item_id']: row for row in completion['results']}
    require(len(results) == len(completion['results']) == 32 and set(results) == ids, 'Completion item inventory differs')
    require(all(row['status'] in TERMINAL for row in results.values()), 'Nonterminal completion cell')
    mh = sha(c.raw('packing-fixtures-v5/manifest.json'))
    require(completion['manifest_sha256'] == mh, 'Completion manifest commitment changed')
    collector = c.obj('followup-collector-freeze.json')
    require(collector['manifest_sha256'] == mh and collector['max_calls'] == 32 and collector['max_wall_seconds'] == 7200,
            'Collector closure/bounds mismatch')
    c.raw('followup-operator-authorization.json', collector['authorization_sha256'])
    c.raw('followup-review-protocol-proposed-v2.json', collector['protocol_sha256'])
    c.raw('answer_runner_v5.py', collector['runner_sha256'])
    c.raw('reviewers/R3/packing-v5-precollection-audit.json', collector['audit_sha256'])
    primary = c.obj('review258-v5-final-blind-freeze.json')
    require(primary['schema'] == 'deepr.scratch.review258-v5.blind-freeze.v2' and primary['stage'] == 'final_blind'
            and primary['assignment_key_opened'] is False and primary['items'] == primary['scheduled_cells'] == 32,
            'Actual complete primary freeze required')
    require(set(primary['output_sha256']) == {'review258-v5-final-labels.json'}, 'Primary output map differs')
    ph = sha(c.raw('review258-v5-final-blind-freeze.json'))
    quality = c.obj('material-review-v5/quality-freeze/FREEZE.json')
    require(quality['independent_review_inputs'] == 3 and quality['pairs_per_reviewer'] == 16
            and quality['key_opened_by_validator'] is False, 'Three complete pre-key quality inputs required')
    require(set(quality['snapshots']) == SNAPSHOTS, 'Unapproved quality snapshot names')
    require(set(quality['reviewers']) == {'Q1', 'Q2', 'Q3'}
            and len({value['session_id'] for value in quality['reviewers'].values()}) == 3, 'Quality sessions incomplete/reused')
    # Validate every reference before opening any snapshot, even on a bad receipt.
    for name in quality['snapshots']:
        require(PurePosixPath(name).name == name, 'Nonflat snapshot reference')
        safe_name('material-review-v5/quality-freeze/' + name)
        require('material-review-v5/quality-freeze/' + name in c.allowed, 'Snapshot outside reviewed inventory')
    require(quality['primary_freeze_sha256'] == ph, 'Primary freeze differs between stages')
    primary_open = c.obj('material-review-v5/primary-key-open-receipt.json')
    quality_open = c.obj('material-review-v5/quality-key-open-receipt.json')
    qh = sha(c.raw('material-review-v5/quality-freeze/FREEZE.json'))
    require(primary_open['primary_freeze_sha256'] == ph and primary_open['primary_labels_frozen_before_key'] is True,
            'Primary first-open receipt mismatch')
    require(quality_open['quality_freeze_sha256'] == qh and quality_open['all_three_reviews_frozen_before_key'] is True,
            'Quality first-open receipt mismatch')
    require(instant(primary['frozen_at']) <= instant(primary_open['opened_at']) <= instant(quality['frozen_at'])
            <= instant(quality_open['opened_at']) <= datetime.now(timezone.utc), 'First-open chronology mismatch')
    require(quality_open['quality_key_sha256'] == quality['withheld_quality_key_sha256'], 'Quality key commitment mismatch')
    # Now verify/capture all frozen judgments; they remain untrusted evidence.
    for name, expected in quality['snapshots'].items():
        c.raw('material-review-v5/quality-freeze/' + name, expected)
    input_raw = c.raw('material-review-v5/input-freeze.json', quality['input_freeze_sha256'])
    require(input_raw == c.raw('material-review-v5/quality-freeze/input-freeze.json'), 'Quality input receipt changed')
    input_freeze = parse(input_raw)
    require(input_freeze['primary_freeze_sha256'] == ph and input_freeze['packet_sha256'] == quality['packet_sha256']
            and input_freeze['withheld_quality_key_sha256'] == quality['withheld_quality_key_sha256'], 'Quality input commitments changed')
    labels_raw = c.raw('review258-v5-final-labels.json', primary['output_sha256']['review258-v5-final-labels.json'])
    labels = parse(labels_raw)
    require(primary_open['labels_sha256'] == sha(labels_raw)
            and quality['primary_labels_sha256'] == sha(labels_raw)
            and labels_raw == c.raw('material-review-v5/quality-freeze/review258-v5-final-labels.json'), 'Primary labels changed')
    require(len(labels) == primary['resolved_rows'] and sum(row['label'] is not None for row in labels) == primary['resolved_labels'],
            'Primary final-row count mismatch')
    require(c.raw('material-review-v5/quality-freeze/primary-freeze.json') == c.raw('review258-v5-final-blind-freeze.json'), 'Primary snapshot changed')
    pair_raw = c.raw('material-review-v5/blinded-pairs.json', quality['packet_sha256'])
    require(pair_raw == c.raw('material-review-v5/quality-freeze/packet.json'), 'Quality packet snapshot changed')
    pairs = parse(pair_raw)
    pair_ids = {row['pair_id'] for row in pairs}
    require(len(pairs) == len(pair_ids) == 16 and {row[side]['item_id'] for row in pairs for side in ('A','B')} == ids,
            'Quality packet does not cover all 32 cells')
    for who, info in quality['reviewers'].items():
        review = c.obj('material-review-v5/quality-freeze/review-' + who + '.json', info['sha256'])
        require(review['reviewer'] == who and review['review_session_id'] == info['session_id']
                and review['packet_sha256'] == quality['packet_sha256'] and len(review['rows']) == 16
                and {row['pair_id'] for row in review['rows']} == pair_ids, 'Incomplete frozen whole-pair judgment')
        require(review['input_freeze_sha256'] == sha(input_raw)
                and instant(review['completed_at']) <= instant(quality['frozen_at']), 'Quality review receipt/chronology changed')
        require(all(review['independence_attestation'].get(key) is True for key in (
            'independent_session', 'reviewed_without_primary_method_mapping', 'reviewed_without_quality_method_mapping',
            'reviewed_without_peer_judgments', 'all_pairs_reviewed')), 'Missing quality blinding attestations')
    require(set(primary['reviewer_sha256']) == {'R1','R2'}, 'Both primary reviewer inputs required')
    for who, expected in primary['reviewer_sha256'].items():
        require(who in {'R1','R2'}, 'Unknown primary reviewer')
        c.raw(f'reviewers/{who}/review258-v5.json', expected)
    if primary['adjudication_sha256'] is not None:
        c.raw('reviewers/R3/review258-v5-adjudication.json', primary['adjudication_sha256'])
    independent = c.obj('review258-v5-independent-freeze.json', primary['independent_freeze_sha256'])
    require(set(independent['output_sha256']) == {'review258-v5-adjudication-inputs.json','review258-v5-disagreements.json'},
            'Unapproved primary independent output reference')
    for name, expected in independent['output_sha256'].items():
        c.raw(name, expected)
    c.raw('review-instructions-v3.txt', primary['instructions_sha256'])
    # Verify every scheduled exact input, full source world, answer and prompt.
    source_bytes, items, answers = {}, {}, {}
    for job in jobs:
        iid = job['item_id']
        item = c.obj(f'packing-fixtures-v5/{iid}.input.json', job['input_sha256'])
        answer = c.obj(f'packing-fixtures-v5/answers/{iid}.json', results[iid]['file_sha256'])
        items[iid], answers[iid] = item, answer
        require(item['item_id'] == answer['item_id'] == iid and answer['status'] == results[iid]['status'], 'Cell identity/status changed')
        require(sha(item['prompt'].encode('utf-8')) == item['prompt_sha256']
                and item['delivered_evidence']['prompt'] == item['prompt'], 'Exact prompt binding changed')
        if 'answer' in answer:
            require(sha(answer['answer'].encode('utf-8')) == answer['answer_sha256'], 'Full retained draft hash differs')
        else:
            require(answer['status'] in {'failed','cancelled','refused_followup_bound','refused_followup_integrity'}, 'Missing returned draft')
        for source in item['sources']:
            raw = source['text'].encode('utf-8')
            require(sha(raw) == source['text_sha256'], 'Source world bytes changed')
            source_bytes[sha(raw)] = raw
    packet_raw = c.raw('packing-fixtures-v5/blinded-review.json', primary['packet_sha256'])
    packet = parse(packet_raw)
    visible = {row['item_id']: row for row in packet}
    require(len(packet) == len(visible) == 32 and set(visible) == ids, 'Primary packet incomplete')
    answer_fields = ('status','answer','answer_sha256','json_object','position_count','response_form',
                     'synthesis_status','synthesis_error_type')
    for iid in ids:
        require(all(visible[iid][field] == items[iid][field] for field in ('kind','question','obligations','sources','delivered_evidence')),
                'Frozen primary world differs from scheduled input')
        require(all((field in visible[iid]) == (field in answers[iid]) and visible[iid].get(field) == answers[iid].get(field)
                    for field in answer_fields), 'Frozen primary draft differs from retained terminal answer')
    slots = {(iid, obligation['obligation_id']) for iid, item in items.items() for obligation in item['obligations']}
    require(len(labels) == len(slots) and {(row['item_id'],row['obligation_id']) for row in labels} == slots,
            'Final labels do not cover every scheduled obligation')
    require(all(row['answer_sha256'] == answers[row['item_id']].get('answer_sha256') for row in labels), 'Final labels bind a different draft')
    quality_sides = {}
    for pair in pairs:
        for side in ('A','B'):
            row = pair[side]; iid = row['item_id']; quality_sides[iid] = row
            require(all(pair[field] == items[iid][field] for field in ('kind','question','obligations','sources'))
                    and row['delivered_prompt'] == items[iid]['prompt'], 'Quality pair world/prompt differs from retained cell')
            require(all(row.get(field) == answers[iid].get(field) for field in answer_fields), 'Quality pair draft differs from retained terminal answer')
    for source_hash, raw in source_bytes.items():
        path = f'packing-fixtures-v5/corpus/sources/{source_hash[:2]}/{source_hash}.md'
        require(c.raw(path, source_hash) == raw, 'Retained corpus differs from complete world')
    snapshot = c.obj('packing-v5-source-snapshot-receipt.json')
    require(set(snapshot['files']) == set(config['current_recipe_paths']), 'Current recipe closure differs')
    require(set(manifest['current_modules']) <= set(snapshot['files']), 'Current module missing from recipe')
    for name, expected in snapshot['files'].items():
        c.raw('packing-v5-source-snapshot/' + name, expected)
        require(name not in manifest['current_modules'] or manifest['current_modules'][name] == expected, 'Producer hash differs')
    c.raw('original_brief.py', manifest['old_brief_sha256'])
    resource = c.obj('followup-native-resource-audit.json')
    require(resource['accounting_complete'] is True and resource['original_100_attempt_ledger_unchanged'] is True,
            'Incomplete native resource audit')
    require(resource['manifest_sha256'] == mh, 'Resource audit manifest changed')
    c.raw('followup-runtime/costs/cost_ledger.jsonl', resource['native_ledger_sha256'])
    attempt_ids = [row['item_id'] for row in resource['attempt_joins']]
    declared_requests = [name for name in c.allowed if re.fullmatch(r'followup-runtime/calls/[0-9]{3}\.[0-9a-f]{16}\.request\.json', name)]
    require(len(attempt_ids) == len(set(attempt_ids)) == len(declared_requests) <= 32
            and set(attempt_ids) == {name.split('.')[-3] for name in declared_requests}, 'Native reservation inventory differs from resource audit')
    for row in resource['attempt_joins']:
        iid = row['item_id']
        require(iid in ids, 'Resource audit unknown item')
        request_names = [name for name in c.allowed if re.fullmatch(r'followup-runtime/calls/[0-9]{3}\.' + iid + r'\.request\.json', name)]
        require(len(request_names) == 1, 'Missing/duplicate reserved request')
        request_name = request_names[0]
        c.raw(request_name, row['request_sha256'])
        response = c.obj(request_name.replace('.request.json','.response.json'), row['response_sha256'])
        c.raw(f'packing-fixtures-v5/answers/{iid}.json', row['answer_receipt_sha256'])
        if row['transport_sha256'] is not None:
            c.raw(request_name.replace('.request.json','.transport.json'), row['transport_sha256'])
        if 'native_response_sha256' in response:
            c.raw(request_name.replace('.request.json','.native.json'), response['native_response_sha256'])
    assembly = c.obj('material-review-v5/brief-assembly-receipt.json')
    require(len(assembly['results']) == 8 and len({row['item_id'] for row in assembly['results']}) == 8, 'All eight brief assembly results required')
    for row in assembly['results']:
        require(row['item_id'] in ids, 'Unknown brief cell')
        if 'rendered_file' in row:
            prefix = 'material-review-v5/' + row['item_id']
            expected_path = root / prefix / 'rendered.md'
            require(Path(row['rendered_file']) == expected_path, 'Unexpected assembly path')
            rendered = c.raw(prefix + '/rendered.md', row['rendered_sha256'])
            require(quality_sides[row['item_id']]['assembled_markdown'].encode('utf-8') == rendered,
                    'Frozen quality assembly differs from retained rendered output')
            c.raw(prefix + '/assembled.json')
        else:
            require(bool(row.get('assembly_absence')), 'Missing brief assembly lacks explicit absence')
    # All judgments and chronology have been verified before the first key read.
    c.keys_allowed = True
    c.raw('packing-fixtures-v5/assignment-key-unopened/key.json', primary_open['primary_key_sha256'])
    c.raw('material-review-v5/quality-key-unopened/key.json', quality['withheld_quality_key_sha256'])
    # Exactly configured remaining files: no directory discovery or glob exports.
    for name in sorted(c.allowed):
        raw = c.raw(name)
        match = re.fullmatch(r'packing-fixtures-v5/corpus/sources/[0-9a-f]{2}/([0-9a-f]{64})\.md', name)
        if match:
            require(sha(raw) == match.group(1), 'Corpus content-address mismatch')
    if 'archive_v5_followup.py' in c.allowed:
        c.raw('archive_v5_followup.py', config['builder_sha256'])
    baseline = Path(config['legacy_consult_source'])
    approved = REPO / '.agent/evidence-delivery-2026-10-19/old_consult_prompt.py'
    require(baseline == approved or baseline.is_relative_to(root), 'Unapproved external baseline')
    if baseline.is_relative_to(root):
        safe_name(baseline.relative_to(root).as_posix())
    legacy_raw = regular(baseline, root if baseline.is_relative_to(root) else REPO).read_bytes()
    require(sha(legacy_raw) == manifest['old_consult_sha256'], 'Legacy consult recipe changed')
    c.values['baseline/old_consult_prompt.py'] = legacy_raw
    historical = config['historical_public_index']
    historical_path = Path(historical['path'])
    public = REPO / 'docs/validation/artifacts/evidence-review-2026-10-20/index.json'
    require(historical_path == public or historical_path.is_relative_to(root), 'Unapproved historical archive reference')
    if historical_path.is_relative_to(root):
        safe_name(historical_path.relative_to(root).as_posix())
    historical_raw = regular(historical_path, root if historical_path.is_relative_to(root) else REPO).read_bytes()
    require(sha(historical_raw) == digest(historical['sha256']), 'Historical public archive index changed')
    c.values['historical/evidence-review-2026-10-20-index.json'] = historical_raw
    c.values['archive-v5-allowlist.json'] = config_raw
    require(set(c.values) == c.allowed | {'baseline/old_consult_prompt.py', 'historical/evidence-review-2026-10-20-index.json', 'archive-v5-allowlist.json'}, 'Archive membership differs')
    return c.values


def archive_bytes(values):
    manifest = {'files': {name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in sorted(values.items())},
                'scope': 'Exact retained negative V5 development evidence. No acceptance, inference authority, or semantic qualification.'}
    manifest_raw = encode(manifest)
    payloads = {**values, 'MANIFEST.json': manifest_raw}
    stream = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(payloads.items()):
                safe_name(name, keys=True)
                info = tarfile.TarInfo(name)
                info.size = len(raw); info.mtime = 0; info.mode = 0o644; info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(raw))
    return stream.getvalue(), manifest_raw, payloads


def fsync_dir(path):
    handle = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(handle)
    finally:
        os.close(handle)


def write(path, raw):
    with path.open('xb') as handle:
        handle.write(raw); handle.flush(); os.fsync(handle.fileno())


def publish(out, selected):
    chunks, chunk = [], {}
    for name, raw in sorted(selected.items()):
        trial = {**chunk, name: raw}
        if len(archive_bytes(trial)[0]) > 480 * 1024 and chunk:
            chunks.append(chunk); chunk = {name: raw}
        else:
            chunk = trial
    if chunk:
        chunks.append(chunk)
    prepared, index = {}, {}
    for number, values in enumerate(chunks, 1):
        packed, manifest, payloads = archive_bytes(values)
        require(len(packed) < LIMIT, 'Oversized evidence file: refuse, never drop or clip')
        name = f'followup-{number:02d}.tar.gz'
        prepared[name] = packed
        with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as tar:
            require([member.name for member in tar.getmembers()] == sorted(payloads), 'Archive member mismatch')
            for member, raw in payloads.items():
                require(tar.extractfile(member).read() == raw, 'Archive exact-byte mismatch')
        index[name] = {'sha256': sha(packed), 'bytes': len(packed), 'evidence_files': len(values), 'manifest_sha256': sha(manifest)}
    index_raw = encode({'archives': index, 'source_files': len(selected), 'source_bytes_preserved': True,
                        'builder_sha256': sha(Path(__file__).read_bytes()), 'semantic_acceptance': None})
    require(len(index_raw) < LIMIT, 'Index exceeds artifact gate')
    complete = encode({'index_sha256': sha(index_raw), 'archive_count': len(prepared), 'source_files': len(selected),
                       'completed_at': datetime.now(timezone.utc).isoformat(), 'semantic_acceptance': None})
    require(len(complete) < LIMIT, 'Completion receipt exceeds artifact gate')
    # mkdir is the exclusive reservation: an existing directory is never renamed,
    # replaced or edited. Interrupted output stays visible and blocks a retry.
    out.mkdir()
    fsync_dir(out.parent)
    for name, raw in prepared.items():
        write(out / name, raw)
    write(out / 'index.json', index_raw)
    fsync_dir(out)
    write(out / 'COMPLETE.json', complete)
    fsync_dir(out); fsync_dir(out.parent)
    return {'output': str(out), 'archives': len(prepared), 'source_files': len(selected), 'semantic_acceptance': None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=T)
    parser.add_argument('--config', type=Path, default=T / 'archive-v5-allowlist.json')
    parser.add_argument('--config-sha256', required=True)
    args = parser.parse_args()
    safe_name(args.config.name)
    root = args.root.resolve()
    config_raw = regular(args.config.absolute(), root).read_bytes()
    require(sha(config_raw) == digest(args.config_sha256), 'Reviewed archive config changed')
    config = parse(config_raw)
    require(config['builder_sha256'] == sha(Path(__file__).read_bytes()), 'Archive builder changed after config review')
    out = Path(config['public_output'])
    selected = preflight(root, out, config, config_raw)
    print(json.dumps(publish(out, selected)))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({'status': 'refused', 'reason': str(error), 'semantic_acceptance': None}), file=sys.stderr)
        raise SystemExit(2)
