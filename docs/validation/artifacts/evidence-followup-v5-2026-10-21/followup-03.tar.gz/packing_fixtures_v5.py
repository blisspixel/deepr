"""Freeze eight equal-allowance semantic comparisons before collecting answers."""
import asyncio,hashlib,importlib.util,json,secrets,sys,re
from dataclasses import asdict
from datetime import date,datetime,timezone
from pathlib import Path
from deepr.experts.brief import build_brief_prompt
from deepr.experts.brief_contracts import Position
from deepr.experts.consult_context import ConsultContext
from deepr.experts.consult_support import study_fingerprint
from deepr.experts.corpus_store import CorpusStore
from deepr.experts.study_contracts import LensOutcome,StudyFinding,StudyResult
from deepr.experts.council import ExpertPerspective
from deepr.experts import consult_prompt as current
from deepr.experts.consult_response import response_form_contract, response_form_instruction

ROOT=Path('/home/pueo/Work/deepr');TASK=Path(__file__).resolve().parent;DEST=TASK/'packing-fixtures-v5'
h=lambda b:hashlib.sha256(b).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('frozen_old_consult',ROOT/'.agent/evidence-delivery-2026-10-19/old_consult_prompt.py')
old_brief=load('frozen_old_brief',TASK/'original_brief.py')
legacy_instructions=old._INSTRUCTIONS
SOURCES=[
 ('fenn-manual','FennCache 1 manual, January 2026. Public catalogue replies may be cached for 60 seconds only when their inputs are immutable during that interval. Account-specific replies must not share a cache key across tenants. A scoped tenant key and revocation tracking are required for authenticated replies.'),
 ('fenn-release','FennCache 2 release, April 2026. Windows workers now disable tenant_keys by default because their optional key store may be absent. Linux workers keep tenant_keys enabled. Before caching authenticated replies on Windows, enable tenant_keys and revocation tracking explicitly, or set cache_ttl = 0. Public catalogue advice is unchanged.'),
 ('fenn-monitor','FennCache monitoring guide. On the reference cluster, warn at 1,200 cache misses per minute. The threshold was measured there; it is not a universal capacity limit. Version 2 does not change it.'),
 ('fenn-hosted','Hosted operator note. LRU eviction at 10,000 entries performed well on our 8 GiB hosted instances. We did not measure 1 GiB self-hosted devices or other eviction policies.'),
 ('fenn-self','Self-hosted maintainer note. On 1 GiB devices, we suggest LFU eviction at 5,000 entries after memory pressure with a larger LRU cache. The conflict with hosted results is unresolved; no shared benchmark establishes a generally better policy.'),
]
FINDINGS=[
 ('mechanism-1','mechanism','fenn-manual','Public cache mechanism',{'concept':'Cache immutable public catalogue replies for 60 seconds. Account replies require tenant-scoped keys and revocation tracking.'}),
 ('change-1','failure','fenn-release','Windows v2 tenant key change',{'conditions':'On Windows v2 enable tenant_keys and revocation tracking before caching authenticated replies, or set cache_ttl = 0. Linux defaults are unchanged.'}),
 ('monitor-1','synopsis','fenn-monitor','Reference-cluster warning',{'observation':'Warn at 1,200 misses/minute on the reference cluster; not a universal limit.'}),
 ('hosted-1','contention','fenn-hosted','Hosted LRU observation',{'position':'LRU at 10,000 entries on 8 GiB hosted instances only; other policies and 1 GiB devices were unmeasured.'}),
 ('self-1','contention','fenn-self','Self-hosted LFU suggestion',{'position':'LFU at 5,000 entries on 1 GiB self-hosted devices; conflict remains unresolved without a shared benchmark.'}),
]
POSITIONS=[
 Position(question='How should Windows v2 cache account replies?',stance='Enable tenant_keys and revocation tracking explicitly before caching account replies, or disable caching with cache_ttl = 0.',reasoning='The v2 Windows default no longer isolates tenant keys. Linux keeps its previous default.',supported_by=['change-1'],would_change_my_mind='A documented platform-specific default correction.'),
 Position(question='Can public catalogue replies still use the cache?',stance='Immutable public catalogue replies may retain a 60-second TTL.',reasoning='The Windows authenticated-key change leaves this separate public-content advice intact.',supported_by=['mechanism-1'],would_change_my_mind='A scoped source revising the public-cache applicability.'),
 Position(question='Which eviction policy should we choose?',stance='The supplied results do not establish a universal eviction winner.',reasoning='The hosted 8 GiB and self-hosted 1 GiB observations differ in environment and capacity.',supported_by=['hosted-1','self-1'],would_change_my_mind='A shared benchmark across both deployment classes.',unresolved_dissent='Hosted LRU 10,000 versus self-hosted LFU 5,000; no common benchmark.',resolution='unresolved'),
 Position(question='What monitoring threshold applies?',stance='The reference-cluster cache-miss warning is 1,200 per minute.',reasoning='This is a measured reference-cluster setting, not a universal capacity limit.',supported_by=['monitor-1'],would_change_my_mind='A documented reference-cluster monitoring revision.'),
]
CASES=[
 ('platform-and-public','On Windows FennCache 2, can we cache account replies for 60 seconds immediately? Does that mean Linux or immutable public catalogue caching must stop? Answer in at most 180 words.',[
  {'obligation_id':'windows-action','expectation':'use','description':'Explain Windows v2 disabled tenant keys: enable tenant_keys AND revocation tracking before authenticated caching, or cache_ttl=0.','source_id':'fenn-release'},
  {'obligation_id':'preserve-linux','expectation':'preserve','description':'Do not apply the Windows default change to Linux.','source_id':'fenn-release'},
  {'obligation_id':'preserve-public','expectation':'preserve','description':'Keep the distinct 60-second immutable public-catalogue allowance.','source_id':'fenn-manual'}]),
 ('unresolved-eviction','What FennCache eviction policy and entry limit should we configure on an unspecified deployment? Answer in at most 180 words.',[
  {'obligation_id':'hosted-scope','expectation':'retain_conflict','description':'Retain the hosted LRU 10,000 observation and its 8 GiB scope.','source_id':'fenn-hosted'},
  {'obligation_id':'self-scope','expectation':'retain_conflict','description':'Retain self-hosted LFU 5,000 on 1 GiB, unresolved difference, and a relevant deployment-specific check.','source_id':'fenn-self'}]),
 ('answerable-and-unknown','What miss-rate warning should the FennCache reference cluster use, and what default tenant-key setting is documented for HaikuOS workers? Answer in at most 180 words.',[
  {'obligation_id':'answer-known','expectation':'use','description':'Give 1,200 cache misses per minute for the reference cluster, with its scope.','source_id':'fenn-monitor'},
  {'obligation_id':'defer-unknown','expectation':'defer','description':'The provided sources do not cover HaikuOS worker defaults; scope the gap and name a check rather than invent a value.'}]),
]

def build():
 DEST.mkdir(exist_ok=False);(DEST/'raw-prompt-audit').mkdir(mode=0o700);corpus=CorpusStore('Fenn comparison',storage_dir=DEST/'corpus');shas={};texts=dict(SOURCES)
 for sid,text in SOURCES:
  entry,_=corpus.add(text,origin_key=f'{sid}.example',trust_class='primary',fetched_at='2026-10-20');shas[sid]=entry.sha256
 findings=[]
 for fid,lens,sid,title,payload in FINDINGS:
  findings.append(StudyFinding(lens=lens,axis='interrogation',kind='fixture',title=title,payload=payload,anchors=[texts[sid][:70]],grounded_anchor_count=1,corpus_shas=[shas[sid]],finding_id=fid))
 # Loose, on-topic findings consume a bounded prompt but establish no decision obligation.
 for i in range(14):
  text=f'FennCache planning note {i}: This planning exercise introduces no new defaults, measurements or recommendations; it does not amend the operational manual, release or monitoring guidance. Caching and eviction are agenda topics only. '+ 'Context for the planning exercise. '*8
  entry,_=corpus.add(text,origin_key=f'filler-{i}.example',trust_class='tertiary',fetched_at='2026-10-20')
  findings.insert(0,StudyFinding(lens='orientation',axis='interrogation',kind='fixture',title=f'FennCache planning {i}',payload={'note':text[:240]},anchors=[text[:70]],grounded_anchor_count=1,corpus_shas=[entry.sha256],finding_id=f'loose-{i}'))
 study=StudyResult(expert_name='Fenn comparison',outcomes=[LensOutcome(lens='fixture',axis='interrogation',status='ok',findings=findings)])
 own={f.finding_id:(f.corpus_shas[0],corpus.entries[f.corpus_shas[0]].origin_key,corpus.read(f.corpus_shas[0]) or '') for f in findings}
 jobs=[];key={};pairs=[]
 def add(pair,arm,prompt,kind,question,obligations,full_sources,limit,manifest=None):
  for seed in (20261020,20261021):
   item=secrets.token_hex(8);key[item]={'pair':pair,'arm':arm,'seed':seed}
   row={'item_id':item,'kind':kind,'question':question,'obligations':obligations,'sources':full_sources,'delivered_evidence':{'prompt':prompt,'prompt_sha256':h(prompt.encode())},'prompt':prompt,'prompt_sha256':h(prompt.encode()),'prompt_chars':len(prompt),'prompt_limit_chars':limit,'output_tokens':6144 if kind=='brief' else 1024,'timeout_seconds':900 if kind=='brief' else 600,'status':'ready' if len(prompt)<=limit else 'refused_over_budget','delivery_manifest':manifest,'seed':seed,'response_form':response_form_contract(question) if kind=='consult' else None}
   (DEST/f'{item}.input.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8',newline='\n');jobs.append({'item_id':item,'input_sha256':h((DEST/f'{item}.input.json').read_bytes())})
 for cid,question,obligations in CASES:
  old._INSTRUCTIONS=legacy_instructions+response_form_instruction(response_form_contract(question))
  for order in ('forward','reverse'):
   ordered=list(findings) if order=='forward' else list(reversed(findings))
   c=ConsultContext(expert_name='Fenn comparison',positions=POSITIONS,findings=ordered,finding_sources=own,study_fingerprint=study_fingerprint(study),study_binding='matched',support=[{'question':p.question,'study_binding':'matched','resolved':True,'resolved_finding_ids':list(p.supported_by)} for p in POSITIONS])
   pair=f'{cid}.{order}';pairs.append(pair)
   limits=(old.MAX_SYNTHESIS_PROMPT_CHARS,current.MAX_SYNTHESIS_PROMPT_CHARS)
   old.MAX_SYNTHESIS_PROMPT_CHARS=current.MAX_SYNTHESIS_PROMPT_CHARS=6500
   try:
    for arm,module in [('old',old),('current',current)]:
     blocks=module.brief_synthesis_blocks(c)
     p=ExpertPerspective(expert_name=c.expert_name,domain='FennCache',response='',synthesis_blocks=blocks,context={'study_fingerprint':c.study_fingerprint,'study_binding':'matched','coverage':'grounded'})
     if arm=='current':prompt,manifest=module.build_synthesis_packet(question,[p])
     else:prompt=module.build_synthesis_prompt(question,[p]);manifest=None
     raw_prompt=prompt
     # This is a declared form-only common envelope, not the unmodified legacy prompt.
     # Keep every selected evidence/stance byte. Replace only the final omission notice.
     prompt,count=re.subn(r'\[\d+ context block\(s\) omitted by the prompt limit: .*?Coverage is incomplete; consult the full artifact\.\]', '[Material was omitted to fit this prompt. Coverage is incomplete; inspect the full artifact.]',prompt,flags=re.DOTALL)
     assert count in (0,1)
     add(pair,arm,prompt,'consult',question,obligations,[{'source_id':sid,'text':text,'text_sha256':h(text.encode()),'trust_class':'primary','observed_at':'2026-10-20','origin_key':sid+'.example'} for sid,text in SOURCES]+[{'source_id':f'filler-{i}','text':corpus.read(entry.sha256),'text_sha256':entry.sha256,'trust_class':entry.trust_class,'observed_at':entry.fetched_at,'origin_key':entry.origin_key} for i in range(14) for entry in corpus.entries.values() if entry.origin_key==f'filler-{i}.example'],6500,manifest)
     (DEST/'raw-prompt-audit'/f'{pair}.{arm}.json').write_text(json.dumps({'raw_prompt':raw_prompt,'raw_chars':len(raw_prompt),'bounded_prompt_chars':len(prompt),'common_notice_replacements':count},indent=2)+'\n')
   finally:old.MAX_SYNTHESIS_PROMPT_CHARS,current.MAX_SYNTHESIS_PROMPT_CHARS=limits
 # Two real brief-prompt contrasts, with exactly the same frozen study per arm.
 for scenario in ('lens-cap','trailing-condition'):
  outcomes=[];all_sources=[]
  for lens in ('synopsis','orientation','mechanism','failure','contention','implication','analogy','question'):
   fs=[]
   count=(35 if lens in ('synopsis','orientation','mechanism','failure') else 4) if scenario=='lens-cap' else 2
   for i in range(count):
    fid=f'{lens}-{i}';text=f'Fenn study observation {lens} {i}: this inventory fact establishes no cache policy.';payload={'observation':text}
    if lens=='synopsis' and i==0:
     text='Fenn catalogue caching can reduce repeated reads only for immutable public replies. Authenticated replies need tenant-scoped keys and revocation tracking.';payload={'observation':text}
    if lens=='contention' and i==0:
     text='Fenn operator trial found account-specific replies leaked across tenants when tenant keys were absent. Public immutable replies were unaffected. Do not cache authenticated replies until tenant keys and revocation tracking are verified.';payload={'qualification':text}
    if scenario=='trailing-condition' and lens=='mechanism' and i==0:
     text='A synthetic Fenn throughput trial describes cache reuse. '+ 'The trial records timing and inventory; a separate cache-policy constraint follows. '*14+'Cache entries may be renewed only after a successful origin validation. A timer alone does not authorize extending a cached reply.'
     payload={'mechanism':text}
    entry,_=corpus.add(text,origin_key=f'{scenario}-{fid}.example',trust_class='primary',fetched_at='2026-10-20')
    fs.append(StudyFinding(lens=lens,axis='interrogation',kind='fixture',title=('When may a cache entry be renewed?' if scenario=='trailing-condition' and lens=='mechanism' and i==0 else f'Fenn {fid}'),payload=payload,anchors=[text[:70]],grounded_anchor_count=1,corpus_shas=[entry.sha256],finding_id=fid))
    all_sources.append({'source_id':fid,'text':text,'text_sha256':h(text.encode()),'trust_class':entry.trust_class,'observed_at':entry.fetched_at,'origin_key':entry.origin_key})
   outcomes.append(LensOutcome(lens=lens,axis='interrogation',status='ok',findings=fs))
  s=StudyResult(expert_name='Fenn cache applicability',outcomes=outcomes)
  obligations=[{'obligation_id':'cache-qualification','expectation':'use','description':'Any cache advice must distinguish immutable public replies from authenticated replies requiring tenant keys AND revocation tracking.'},{'obligation_id':'preserve-warning','expectation':'preserve','description':'Retain the reported tenant-key-absent leak and verification prerequisite. Do not claim the deployment hazard was mitigated or the warning refuted. Treating the scoped precaution as established guidance is allowed.'}]
  if scenario=='trailing-condition':
   obligations=[{'obligation_id':'public-scope','expectation':'preserve','description':'Preserve the scoped immutable-public caching allowance; do not disable every cache because of the unrelated authenticated-response condition.'},{'obligation_id':'renewal-condition','expectation':'use','description':'The retained mechanism-0 policy requires successful origin validation before renewal and forbids timer-only extension. Preserve and explain this condition. Evaluate retained-world answer adequacy; record a cautious delivered-context gap in the rationale without counting an omitted known condition as used correctly.','source_id':'mechanism-0'}]
  question=('Produce the requested brief. In particular, explain when an existing cache entry may be renewed without generalizing missing conditions.' if scenario=='trailing-condition' else 'Produce the requested brief. Keep supported public caching separate from authenticated-response safety and preserve the scoped operator warning.')
  pair=f'brief.{scenario}';pairs.append(pair)
  for arm,module in [('old',old_brief),('current',sys.modules['deepr.experts.brief'])]:
   prompt=module.build_brief_prompt(s,expert_name=s.expert_name,domain=('Cache entry renewal conditions and source qualifications' if scenario=='trailing-condition' else 'Cache applicability and source qualifications'),as_of_date=date(2026,10,20))
   add(pair,arm,prompt,'brief',question,obligations,all_sources,60000)
 secrets.SystemRandom().shuffle(jobs)
 private=DEST/'assignment-key-unopened';private.mkdir(mode=0o700);path=private/'key.json';path.write_text(json.dumps(key,indent=2)+'\n');path.chmod(0o600)
 manifest={'frozen_at':datetime.now(timezone.utc).isoformat(),'fixture_version':'packing-v5-complete-fields-and-response-form','preceding_trial':'V3 retained as defective/truncated; V4 completed and rejected on whole-answer regression and missing renewal condition. Both remain unchanged. V5 is a prospective repair comparison on reused development families, not a reset, held-out set or erased failure.','phase_budget':'Consult1024tokens/600seconds; brief6144tokens/900seconds, both methods equal. Separately authorized prospective32calls/7200seconds from follow-up collector start; original100-call trial remains exhausted and unchanged. No automatic retry.','review_unit':'Semantic labels evaluate individual obligations against the complete retained source world. Exact delivered prompts localize transport loss and support explanation of cautious gaps; a missing known condition is still missing, never promoted to successful evidence use. Completion/schema status is separate from visible content.','case_families':len(pairs),'pairs':2*len(pairs),'answers_scheduled':len(jobs),'jobs':jobs,'source_commit':'editable candidate based on47bd37b4079054b6bf7fd6508ca199a491ec5c2a; exact modules separately hashed','briefing_isolation':'The lens-cap study has 156 findings; the trailing-condition study has 16, so the latter does not conflate clipping with the 120-finding selector.', 'baseline_envelope':'Both consult arms receive the same literal response-form instruction BEFORE their existing selection and one common fixed bounded omission notice AFTER selection. Both use6500promptcharacters within the unchanged16000productionceiling. Source/stance bytes are never clipped. This contrasts evidence selection/grouping, not unmodified legacy UX. Same one-call response-form admission applies to both methods; full drafts and failures remain in denominators. Legacy brief uses unchanged old prefix/field clipping; both arms use the current nonforecast warning correction at assembly.', 'old_commit':'dc19dbc611790d8e82c5504b52344eba8a98c2ee','old_consult_sha256':h((ROOT/'.agent/evidence-delivery-2026-10-19/old_consult_prompt.py').read_bytes()),'old_brief_sha256':h((TASK/'original_brief.py').read_bytes()),'current_modules':{str(p.relative_to(ROOT)):h(p.read_bytes()) for p in [ROOT/'src/deepr/experts/consult_prompt.py',ROOT/'src/deepr/experts/brief.py',ROOT/'src/deepr/experts/brief_selection.py',ROOT/'src/deepr/experts/brief_contracts.py',ROOT/'src/deepr/experts/consult_response.py',ROOT/'src/deepr/experts/council.py',ROOT/'src/deepr/experts/consult.py']},'generator':{'model':'qwen3.8:27b','digest':'aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813','num_ctx':16384,'temperature':0,'think':False,'seeds':[20261020,20261021],'timeout_seconds':600},'acceptance':'Compare scoped semantic obligations and nonanswer rates per pair before revealing arm identities. No supported-answer material regression accepted; no superiority or transfer claim from eight synthetic pairs. All refusals, failures and truncations remain in the denominator. This exercise uses frozen fixture study/positions, not research or real-world advice qualification.'}
 assert len(jobs)==32 and len(pairs)==8
 (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps({'pairs':2*len(pairs),'scheduled_answers':len(jobs),'ready':sum(json.loads((DEST/f"{j['item_id']}.input.json").read_text())['status']=='ready' for j in jobs),'assignment_key':'created privately, not revealed','manifest_sha256':h((DEST/'manifest.json').read_bytes())}))

if __name__=='__main__':build()
