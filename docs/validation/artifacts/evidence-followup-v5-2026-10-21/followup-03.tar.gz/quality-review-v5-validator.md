# Offline V5 quality-review freeze preparation

`freeze_pair_quality_v5.py` checks mechanical completeness and bindings only.
It does not collect answers, assemble briefs, judge rationale quality, open a
method key, join methods, count winners, authorize inference, or accept a policy.
Operator authorization is now recorded for 32 local generations, 7200 seconds,
and $0 paid-provider spend. The validator creates no dispatch authority or budget
extension. The original exhausted trial remains unchanged.

The producer must prepare the quality packet only after primary labels are
frozen. Preserve that original primary freeze; no primary labels may be revised.
The quality key is separate and remains withheld until the final quality freeze.
There is no key-file argument. Pass its SHA-256 string independently.

## Future inputs

- `--packet`: JSON list of exactly 16 opaque pairs, in the prior V4 packet shape.
  Each pair has unique `pair_id`, `kind` (`consult` or `brief`), `question`, complete `sources` with
  unique `source_id`, and `A`/`B` side objects. Each side has `status`, exact
  `delivered_prompt`, and its UTF-8 `prompt_sha256`. Terminal status must be one
  of `completed`, `truncated`, `empty_answer`, `form_failed`, `malformed_brief`,
  `failed`, `cancelled`, `refused_followup_bound`, or `refused_followup_integrity`;
  pending and unrecognized states are refused. Every retained raw `answer`
  has its exact UTF-8 `answer_sha256`, regardless of failure, cancellation,
  truncation, malformed output, or response-form failure. If no answer exists,
  supply nonempty `answer_absence` and a null or absent `answer_sha256`; never
  fabricate an empty successful answer. Every brief side also needs
  `assembly_status` and either actual `assembled_markdown` with its UTF-8
  `assembled_markdown_sha256`, or nonempty `assembly_absence`. Full source scope,
  actual producer-specific assembly, and opaque assignments remain preparation
  responsibilities. A packet hash cannot prove those semantic properties.
- `--packet-sha256`: independently supplied exact packet-file SHA-256.
- `--primary-freeze`: the actual `review258_v5_primary.py finalize` receipt with
  schema `deepr.scratch.review258-v5.blind-freeze.v2`, `stage: final_blind`,
  `frozen_at`, `assignment_key_opened: false`, `key_access_implemented: false`,
  `resolved_rows`, `resolved_labels`, and
  `output_sha256["review258-v5-final-labels.json"]`. All 32 scheduled cells and
  the assessed/absence obligation counts must agree with the final-label rows.
  The stale generic `labels`/`labels_sha256` shape is refused, not adapted.
- `--primary-freeze-sha256`: independently supplied SHA-256 of that receipt.
- `--primary-labels`: the actual named `review258-v5-final-labels.json` file.
  Exact bytes must match the real receipt's output map. Rows are counted for
  mechanical consistency only, never regraded. Zero assessed labels are allowed
  when every row records an absent return; all scheduled rows remain bound.
- `--input-freeze`: quality input receipt with `created_at`, `pairs: 16`,
  `packet_sha256`, `primary_freeze_sha256`, `withheld_quality_key_sha256`,
  `assignment_key_opened: false` (the separate quality key), and
  `primary_labels_unchanged: true`. Its creation must follow primary freeze.
- `--quality-key-sha256`: separate withheld quality-key SHA-256 string. The
  validator binds this commitment without reading or discovering the key.
- Exactly three `--review ID=PATH` inputs: each is a JSON envelope containing
  `reviewer`, unique `review_session_id`, `completed_at`, `packet_sha256`,
  `input_freeze_sha256`, `independence_attestation`, and `rows`. All five
  attestation fields must be true: `independent_session`,
  `reviewed_without_primary_method_mapping`,
  `reviewed_without_quality_method_mapping`,
  `reviewed_without_peer_judgments`, and `all_pairs_reviewed`.
  Each envelope has exactly 16 rows, one per pair, with `reviewer`, `pair_id`,
  `disposition`, nonempty `note`, nonempty `abstention_assessment`,
  `A_answer_sha256`, `B_answer_sha256`, exact `A_quote`/`B_quote` or empty strings,
  and `source_ids`. Hash fields are null for genuinely absent raw answers.
  The four dispositions remain `no_material_difference`, `A_materially_worse`,
  `B_materially_worse`, and `uncertain`. Source IDs and quotes must bind to the
  supplied pair, including actual assembled Markdown where applicable.

The validator checks presence of rationale, not whether it is persuasive.
Distinct session IDs and explicit independence statements are attestations;
they cannot establish independent reasoning or undisclosed key access.
Exact review-service model snapshot, usage and cost remain unobserved. No
human-review claim is made. Missing conditions, blanket abstention, shared
failures and mixed tradeoffs remain matters for accountable semantic review.
A missing return is an execution/output absence. It must not be credited as
an appropriate semantic defer. The review must preserve that status limitation
and assess any returned draft on its actual meaning, even when form failed.
The validator does not use keywords to decide whether this distinction was
handled correctly; nonempty rationale alone cannot establish it.

## Invocation and durable output

```text
python .agent/issue-completion-2026-10-20/freeze_pair_quality_v5.py \
  --packet FUTURE_OPAQUE_PACKET.json --packet-sha256 PACKET_SHA256 \
  --primary-freeze PRIMARY_FREEZE.json --primary-freeze-sha256 PRIMARY_SHA256 \
  --primary-labels PATH_TO/review258-v5-final-labels.json \
  --input-freeze QUALITY_INPUT_FREEZE.json --quality-key-sha256 WITHHELD_KEY_SHA256 \
  --review R1=R1_ENVELOPE.json --review R2=R2_ENVELOPE.json --review R3=R3_ENVELOPE.json \
  --out .agent/issue-completion-2026-10-20/FUTURE_NEW_QUALITY_FREEZE_DIRECTORY
```

All inputs must exist and validate before output creation. The new output
directory must be under this scratch root and its parent must already exist.
Existing output is refused. Exact packet, primary final labels, primary/input receipts, all three
review envelopes, and validator bytes are copied with exclusive creation and
file fsync. Directory fsync precedes the last-written `FREEZE.json`, whose
snapshot hashes bind those exact copies. Use only a successful exit plus the
complete receipt and matching snapshots as a freeze. Partial directories from
storage failures/crashes are not valid freezes and must be preserved.

The receipt explicitly emits `semantic_acceptance: null`, retains disagreement,
and supplies no authority to open a key. The validator never opens a key; that
later authorized operation must verify this durable freeze independently.
Known assignment-key/private paths are refused even if passed as another input.
The tool does not prove a file has no hidden method information or that source
inventories are complete; blinded preparation and reviewer sessions still need
their separate evidence audit.

Compile checking, safe absent-input refusal, and a synthetic in-memory packet
admission check for form-failed drafts and explicit absences were performed.
The primary-schema alignment additionally checks synthetic real-helper receipt
shapes, output hash/count mismatches, and all-absence rows without writing any
positive freeze. No actual answers, actual labels, peer judgments, or keys were
read for these preparation checks; no inference was dispatched by the validator.
The authorized collector is separate from this offline preparation.
