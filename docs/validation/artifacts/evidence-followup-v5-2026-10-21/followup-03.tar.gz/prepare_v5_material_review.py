"""Reconstruct actual producers after primary freeze, then hide pair methods anew.

This offline helper opens the V5 primary key only after validating all primary
freeze bindings. It does not open the separate quality key or accept a policy.
Root preparation is method-aware and is never represented as blinded review.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import secrets
import sys
from collections import defaultdict
from dataclasses import asdict
from datetime import UTC, date, datetime
from pathlib import Path

T = Path(__file__).resolve().parent
R = T.parents[1]
D = T / "packing-fixtures-v5"
OUT = T / "material-review-v5"


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n").encode("utf-8")
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return sha(raw)


def preflight():
    # This is deliberately the first data read. No key is read on an incomplete trial.
    primary_path = T / "review258-v5-final-blind-freeze.json"
    primary = read(primary_path)
    labels = T / "review258-v5-final-labels.json"
    require(primary["stage"] == "final_blind" and primary["assignment_key_opened"] is False,
            "Complete pre-key primary freeze required")
    require(primary["output_sha256"][labels.name] == sha(labels.read_bytes()), "Primary labels changed")
    require(primary["helper_sha256"] == sha((T / "review258_v5_primary.py").read_bytes()), "Primary helper changed")
    packet_path = D / "blinded-review.json"
    packet = read(packet_path)
    require(primary["packet_sha256"] == sha(packet_path.read_bytes()), "Primary packet changed")
    require(primary["resolved_rows"] == sum(len(item["obligations"]) for item in packet), "Incomplete primary rows")
    require(primary["items"] == len(packet) == 32, "All 32 scheduled cells required")
    helper_spec = importlib.util.spec_from_file_location("v5_primary_binding_validator", T / "review258_v5_primary.py")
    helper = importlib.util.module_from_spec(helper_spec)
    helper_spec.loader.exec_module(helper)
    _, slots, bindings, packet_hash, instruction_hash, reviews, review_hashes, differences = helper.primary_inputs(T)
    require(primary["bindings"] == bindings, "Primary per-cell bindings differ from packet")
    require(primary["packet_sha256"] == packet_hash and primary["instructions_sha256"] == instruction_hash,
            "Primary input/instruction binding changed")
    require(primary["reviewer_sha256"] == review_hashes, "Frozen primary reviewer bytes changed")
    label_rows = read(labels)
    require(len(label_rows) == len(slots), "Final labels incomplete")
    label_slots = {(row["item_id"], row["obligation_id"]): row for row in label_rows}
    require(len(label_slots) == len(label_rows) and set(label_slots) == set(slots), "Final label slots differ")
    for slot, row in label_slots.items():
        item = slots[slot][0]
        require(row["answer_sha256"] == item.get("answer_sha256") and row["terminal_status"] == item["status"],
                "Final label answer/status mismatch")
        require(row["independent_reviews"] == {who: reviews[who][slot] for who in reviews}, "Final primary rows changed")
        require(row["label"] in helper.LABELS if "answer" in item else row["label"] is None,
                "Final semantic/absence label mismatch")
    completion = read(D / "answers-complete.json")
    manifest = read(D / "manifest.json")
    require(completion["manifest_sha256"] == sha((D / "manifest.json").read_bytes()), "Manifest changed")
    collector = read(T / "followup-collector-freeze.json")
    require(collector["manifest_sha256"] == completion["manifest_sha256"], "Collector manifest differs")
    require(completion["terminal_answers"] == completion["answers_scheduled"] == len(manifest["jobs"]) == 32,
            "Incomplete collection")
    ids = {row["item_id"] for row in manifest["jobs"]}
    completion_ids = {row["item_id"] for row in completion["results"]}
    packet_ids = {row["item_id"] for row in packet}
    require(len(ids) == len(completion_ids) == len(completion["results"]) == len(packet_ids) == 32,
            "Missing or duplicate manifest/completion/packet cells")
    require(ids == completion_ids == packet_ids == {row["item_id"] for row in primary["bindings"]},
            "Manifest/completion/packet/freeze item sets differ")
    terminal = {row["item_id"]: row for row in completion["results"]}
    blinded = {row["item_id"]: row for row in packet}
    fields = ("status", "answer", "answer_sha256", "json_object", "position_count", "response_form", "synthesis_status", "synthesis_error_type")
    for job in manifest["jobs"]:
        iid = job["item_id"]
        input_path = D / (iid + ".input.json")
        answer_path = D / "answers" / (iid + ".json")
        require(sha(input_path.read_bytes()) == job["input_sha256"], "Collected input changed")
        require(sha(answer_path.read_bytes()) == terminal[iid]["file_sha256"], "Collected answer changed")
        item, answer, visible = read(input_path), read(answer_path), blinded[iid]
        require(item["item_id"] == answer["item_id"] == iid, "Collected item identity mismatch")
        require(all(visible[field] == item[field] for field in ("kind", "question", "obligations", "sources", "delivered_evidence")),
                "Blinded world/question/delivered evidence differs from frozen input")
        require(all((field in visible) == (field in answer) and visible.get(field) == answer.get(field) for field in fields),
                "Blinded answer/status metadata differs from collected response")
        require(item["delivered_evidence"]["prompt"] == item["prompt"] and sha(item["prompt"].encode("utf-8")) == item["prompt_sha256"],
                "Collected prompt binding differs")
    require(all(sha((R / path).read_bytes()) == digest for path, digest in manifest["current_modules"].items()),
            "Producer source changed")
    require(not OUT.exists(), "Material review output already exists")
    return primary_path, primary, labels, completion, manifest


def prepare():
    primary_path, primary, labels, completion, manifest = preflight()
    # Primary labels are fully frozen before this first read of the primary key.
    key_raw = (D / "assignment-key-unopened/key.json").read_bytes()
    key = json.loads(key_raw)
    require(set(key) == {row["item_id"] for row in manifest["jobs"]}, "Primary key does not bind all cells")
    OUT.mkdir()
    write(OUT / "primary-key-open-receipt.json", {
        "opened_at": datetime.now(UTC).isoformat(), "primary_key_sha256": sha(key_raw),
        "primary_freeze_sha256": sha(primary_path.read_bytes()), "labels_sha256": sha(labels.read_bytes()),
        "primary_labels_frozen_before_key": True, "root_preparation_method_aware": True,
        "scope": "Primary key only. Independent quality sessions receive a new opaque packet and never this mapping.",
    })
    from deepr.experts import brief as current
    from deepr.experts.corpus_store import CorpusStore
    from deepr.experts.study_contracts import LensOutcome, StudyFinding, StudyResult

    legacy_path = T / "original_brief.py"
    require(sha(legacy_path.read_bytes()) == manifest["old_brief_sha256"], "Legacy producer changed")
    spec = importlib.util.spec_from_file_location("v5_frozen_legacy_brief", legacy_path)
    old = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = old
    spec.loader.exec_module(old)
    corpus = CorpusStore("Fenn comparison", storage_dir=D / "corpus")
    assemblies = {}
    grouped = defaultdict(dict)
    for iid, info in key.items():
        item = read(D / f"{iid}.input.json")
        response = read(D / "answers" / f"{iid}.json")
        require(item["item_id"] == response["item_id"] == iid, "Item identity mismatch")
        require(item["seed"] == info["seed"], "Seed identity mismatch")
        pair = (info["pair"], info["seed"])
        require(info["arm"] in {"old", "current"} and info["arm"] not in grouped[pair], "Duplicate method cell")
        grouped[pair][info["arm"]] = item, response
        if item["kind"] != "brief":
            continue
        scenario = info["pair"].split(".", 1)[1]
        groups = {lens: [] for lens in ("synopsis", "orientation", "mechanism", "failure", "contention", "implication", "analogy", "question")}
        for source in item["sources"]:
            fid, text = source["source_id"], source["text"]
            digest = sha(text.encode("utf-8"))
            require(digest == source["text_sha256"] and corpus.read(digest) == text, "Frozen source mismatch")
            lens, _ = fid.rsplit("-", 1)
            field = "qualification" if fid == "contention-0" else "observation"
            if scenario == "trailing-condition" and fid == "mechanism-0":
                field = "mechanism"
            title = "When may a cache entry be renewed?" if field == "mechanism" else f"Fenn {fid}"
            groups[lens].append(StudyFinding(lens=lens, axis="interrogation", kind="fixture", title=title,
                                            payload={field: text}, anchors=[text[:70]], grounded_anchor_count=1,
                                            corpus_shas=[digest], finding_id=fid))
        study = StudyResult(expert_name="Fenn cache applicability", outcomes=[
            LensOutcome(lens=lens, axis="interrogation", status="ok", findings=findings)
            for lens, findings in groups.items()])
        domain = "Cache entry renewal conditions and source qualifications" if scenario == "trailing-condition" else "Cache applicability and source qualifications"
        kwargs = {"expert_name": study.expert_name, "domain": domain, "as_of_date": date(2026, 10, 20)}
        module = old if info["arm"] == "old" else current
        prompt = module.build_brief_prompt(study, **kwargs)
        require(prompt == item["prompt"] and sha(prompt.encode("utf-8")) == item["prompt_sha256"],
                "Exact collected brief prompt did not reconstruct")
        row = {"item_id": iid, "pair": info["pair"], "seed": info["seed"], "arm": info["arm"],
               "status": response["status"], "exact_prompt_reconstructed": True,
               "prompt_sha256": item["prompt_sha256"], "answer_sha256": response.get("answer_sha256")}
        if "answer" not in response:
            row.update(assembly_status="no_answer", assembly_absence="No raw draft returned for this scheduled cell")
        else:
            require(sha(response["answer"].encode("utf-8")) == response["answer_sha256"], "Draft changed")
            try:
                parsed = json.loads(response["answer"])
                require(isinstance(parsed, dict), "Brief must be a JSON object")
                selection = {}
                if info["arm"] == "current":
                    _, selected = current.brief_prompt_with_selection(study, **kwargs)
                    selection["selection"] = selected
                brief = module.assemble_brief(parsed, expert_name=study.expert_name, result=study, corpus=corpus,
                                              as_of_date=date(2026, 10, 20), **selection)
                rendered = module.render_brief(brief)
                folder = OUT / iid
                folder.mkdir()
                write(folder / "assembled.json", asdict(brief))
                with (folder / "rendered.md").open("x", encoding="utf-8", newline="\n") as handle:
                    handle.write(rendered)
                row.update(assembly_status="completed", assembled_positions=len(brief.positions),
                           rendered_sha256=sha(rendered.encode("utf-8")), rendered_file=str(folder / "rendered.md"))
            except (ValueError, TypeError, KeyError, AttributeError) as error:
                row.update(assembly_status="failed", assembly_absence=f"{type(error).__name__}: {error}")
        assemblies[iid] = row
    require(len(assemblies) == 8 and len(grouped) == 16, "All eight brief cells and sixteen matched pairs required")
    write(OUT / "brief-assembly-receipt.json", {"results": list(assemblies.values()), "model_calls": 0,
          "limits": "Exact frozen prompt reconstruction and producer assembly only. Shared current nonforecast warning seam is declared in both arms. Form success is not advice qualification."})
    packet, quality_key = [], {}
    for (family, seed), pair in sorted(grouped.items()):
        require(set(pair) == {"old", "current"}, "Incomplete matched pair")
        old_item, _ = pair["old"]
        new_item, _ = pair["current"]
        require(all(old_item[field] == new_item[field] for field in ("sources", "question", "obligations", "kind", "seed")),
                "Pair world/question/seed differs")
        opaque = secrets.token_hex(12)
        order = secrets.choice([("old", "current"), ("current", "old")])
        entry = {field: old_item[field] for field in ("kind", "question", "sources", "obligations")}
        entry["pair_id"] = opaque
        if entry["kind"] == "brief":
            entry["assembly_context"] = {"source_credibility_inventory": "The derived source-credibility section enumerates the shared fixture corpus, including other fixture worlds. It is corpus inventory, not evidence delivered to this answer or claim-level support. Judge substantive claims against this pair sources and exact delivered prompts; do not treat inventory size or origin listings as support."}
        for side, arm in zip(("A", "B"), order, strict=True):
            item, answer = pair[arm]
            row = {"item_id": item["item_id"], "status": answer["status"], "delivered_prompt": item["prompt"],
                   "prompt_sha256": item["prompt_sha256"]}
            for field in ("answer", "answer_sha256", "json_object", "position_count", "response_form", "synthesis_status", "synthesis_error_type"):
                if field in answer:
                    row[field] = answer[field]
            if "answer" not in row:
                row.update(answer_absence="No returned raw draft; execution absence is not appropriate semantic deferral", answer_sha256=None)
            if item["item_id"] in assemblies:
                assembly = assemblies[item["item_id"]]
                row["assembly_status"] = assembly["assembly_status"]
                if "rendered_file" in assembly:
                    rendered = Path(assembly["rendered_file"]).read_text(encoding="utf-8")
                    require(sha(rendered.encode("utf-8")) == assembly["rendered_sha256"], "Rendered view changed")
                    row.update(assembled_markdown=rendered, assembled_markdown_sha256=assembly["rendered_sha256"])
                else:
                    row["assembly_absence"] = assembly["assembly_absence"]
            entry[side] = row
        packet.append(entry)
        quality_key[opaque] = {"family": family, "seed": seed, "A": order[0], "B": order[1]}
    private = OUT / "quality-key-unopened"
    private.mkdir(mode=0o700)
    quality_key_sha = write(private / "key.json", quality_key)
    (private / "key.json").chmod(0o600)
    write(OUT / "blinded-pairs.json", packet)
    write(OUT / "input-freeze.json", {"created_at": datetime.now(UTC).isoformat(), "pairs": 16,
          "packet_sha256": sha((OUT / "blinded-pairs.json").read_bytes()),
          "primary_freeze_sha256": sha(primary_path.read_bytes()), "primary_labels_sha256": sha(labels.read_bytes()),
          "withheld_quality_key_sha256": quality_key_sha,
          "assignment_key_opened": False, "primary_labels_unchanged": True, "new_model_calls": 0,
          "limits": "Root knows methods. All primary labels were frozen first; a separate withheld key is used for fresh independent whole-pair sessions. Reused development cases are not held-out transfer."})
    print(json.dumps({"pairs": 16, "brief_cells": 8, "packet": str(OUT / "blinded-pairs.json"), "new_model_calls": 0}))


if __name__ == "__main__":
    try:
        prepare()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"status": "refused", "error": str(error), "semantic_acceptance": None}), file=sys.stderr)
        raise SystemExit(2)
