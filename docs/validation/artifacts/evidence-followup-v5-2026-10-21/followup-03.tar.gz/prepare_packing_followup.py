"""Prepare the next immutable inputs offline; this grants no inference authority."""
from pathlib import Path
import json,hashlib
T=Path(__file__).resolve().parent
s=(T/'packing_fixtures_v4.py').read_text()
def replace(old,new):
 global s
 assert old in s,old
 s=s.replace(old,new)
replace("DEST=TASK/'packing-fixtures-v4'", "DEST=TASK/'packing-fixtures-v5'")
replace('from deepr.experts import consult_prompt as current', 'from deepr.experts import consult_prompt as current\nfrom deepr.experts.consult_response import response_form_contract, response_form_instruction')
replace("old_brief=load('frozen_old_brief',TASK/'original_brief.py')", "old_brief=load('frozen_old_brief',TASK/'original_brief.py')\nlegacy_instructions=old._INSTRUCTIONS")
start=s.index('  item=secrets.token_hex(8);key[item]=')
end=s.index('\n for cid,question,obligations',start)
old=s[start:end]
new='''  for seed in (20261020,20261021):
   item=secrets.token_hex(8);key[item]={'pair':pair,'arm':arm,'seed':seed}
   row={'item_id':item,'kind':kind,'question':question,'obligations':obligations,'sources':full_sources,'delivered_evidence':{'prompt':prompt,'prompt_sha256':h(prompt.encode())},'prompt':prompt,'prompt_sha256':h(prompt.encode()),'prompt_chars':len(prompt),'prompt_limit_chars':limit,'output_tokens':6144 if kind=='brief' else 1024,'timeout_seconds':900 if kind=='brief' else 600,'status':'ready' if len(prompt)<=limit else 'refused_over_budget','delivery_manifest':manifest,'seed':seed,'response_form':response_form_contract(question) if kind=='consult' else None}
   (DEST/f'{item}.input.json').write_text(json.dumps(row,indent=2)+'\\n',encoding='utf-8',newline='\\n');jobs.append({'item_id':item,'input_sha256':h((DEST/f'{item}.input.json').read_bytes())})'''
s=s[:start]+new+s[end:]
replace(" for cid,question,obligations in CASES:\n", " for cid,question,obligations in CASES:\n  old._INSTRUCTIONS=legacy_instructions+response_form_instruction(response_form_contract(question))\n")
replace("'fixture_version':'packing-v4'", "'fixture_version':'packing-v5-complete-fields-and-response-form'")
replace("'preceding_trial':'packing-fixtures-v3 retained and not admitted as a clean contrast; source-scope ambiguity, incomplete initial review handoff, delivery-dependent obligation and one3072-token truncated brief. This prospective revision does not overwrite it.'", "'preceding_trial':'V3 retained as defective/truncated; V4 completed and rejected on whole-answer regression and missing renewal condition. Both remain unchanged. V5 is a prospective repair comparison on reused development families, not a reset, held-out set or erased failure.'")
replace("Global100calls/10800seconds from ORIGINAL protocol start remain binding.", "Separately authorized prospective32calls/7200seconds from follow-up collector start; original100-call trial remains exhausted and unchanged.")
replace("'pairs':len(pairs),'answers_scheduled'", "'case_families':len(pairs),'pairs':2*len(pairs),'answers_scheduled'")
replace("'source_commit':'47bd37b4079054b6bf7fd6508ca199a491ec5c2a'", "'source_commit':'editable candidate based on47bd37b4079054b6bf7fd6508ca199a491ec5c2a; exact modules separately hashed'")
replace("'baseline_envelope':'Both consult arms use one fixed bounded omission notice after their unmodified block selection. Only notice bytes change, never evidence or stance bytes. The unmodified old over-budget prompts remain separately retained in packing-fixtures; none was dispatched. This isolates selection/grouping semantics from the already fixed legacy notice overflow.'", "'baseline_envelope':'Both consult arms receive the same literal response-form instruction BEFORE their existing selection and one common fixed bounded omission notice AFTER selection. Both use6500promptcharacters within the unchanged16000productionceiling. Source/stance bytes are never clipped. This contrasts evidence selection/grouping, not unmodified legacy UX. Same one-call response-form admission applies to both methods; full drafts and failures remain in denominators. Legacy brief uses unchanged old prefix/field clipping; both arms use the current nonforecast warning correction at assembly.'")
replace("ROOT/'src/deepr/experts/brief_selection.py']", "ROOT/'src/deepr/experts/brief_selection.py',ROOT/'src/deepr/experts/brief_contracts.py',ROOT/'src/deepr/experts/consult_response.py',ROOT/'src/deepr/experts/council.py',ROOT/'src/deepr/experts/consult.py']")
replace("'seed':20261020", "'seeds':[20261020,20261021]")
replace("assert len(jobs)==16 and len(pairs)==8", "assert len(jobs)==32 and len(pairs)==8")
replace("'pairs':len(pairs),'scheduled_answers'", "'pairs':2*len(pairs),'scheduled_answers'")
replace("(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')", "(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n',encoding='utf-8',newline='\\n')")
p=T/'packing_fixtures_v5.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
p=T/'followup-review-protocol-proposed.json';data=json.loads(p.read_text());assert data['status']=='awaiting_operator_authorization_no_native_calls_permitted';data['allowances']['matched_consult_trial_prompt_chars']=6500;data['allowances']['consult_prompt_chars_ceiling']=data['allowances'].pop('consult_prompt_chars');data['fixture_builder_sha256']=hashlib.sha256((T/'packing_fixtures_v5.py').read_bytes()).hexdigest();p.write_text(json.dumps(data,indent=2)+'\n')
print('Prepared offline32-input fixture builder; no native authorization or calls.')
