from pathlib import Path
from datetime import datetime, UTC
import json,hashlib,subprocess
T=Path(__file__).resolve().parent;R=T.parents[1]
paths=['src/deepr/experts/brief.py','src/deepr/experts/brief_selection.py','src/deepr/experts/brief_contracts.py','src/deepr/experts/consult_response.py','src/deepr/experts/consult_prompt.py','src/deepr/experts/council.py','src/deepr/experts/consult.py','src/deepr/cli/consult_render.py']
protocol={
'prepared_at':datetime.now(UTC).isoformat(),'status':'awaiting_operator_authorization_no_native_calls_permitted',
'objective':'Prospective development comparison of repaired complete-finding delivery and one-call response form against the frozen legacy selection/packing baseline. No S0 or transfer claim.',
'preceding_trial':'Original protocol remains exhausted at 100 generations and rejected for #258; preserve all original answers and judgments. This is a separately authorized new budget, not a reset or extension of that trial.',
'local_generation_ceiling':32,'wall_ceiling_seconds':7200,'paid_provider_api_ceiling_usd':0,
'generator':{'model':'qwen3.8:27b','digest':'aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813','num_ctx':16384,'temperature':0,'think':False,'seeds':[20261020,20261021]},
'allowances':{'consult_output_tokens':1024,'consult_timeout_seconds':600,'brief_output_tokens':6144,'brief_timeout_seconds':900,'consult_prompt_chars':16000,'brief_prompt_chars':60000},
'matrix':'The same eight development pairs: six consult pairs across both finding orders plus two actual briefing pairs. Both methods at each of two seeds = 32 scheduled answers. No native calibration or extra probes; no automatic retries. Prepare and source-audit frozen exact inputs before any call.',
'constraints':'Same source world, question, model digest, input allowance and generation allowance per pair. A common bounded omission notice is the declared legacy adapter; retain exact legacy and modified source bytes. Both arms receive the same literal response-form instruction and admission to isolate evidence packing; record any form failure in the denominator with complete retained draft and usage. Brief assembly/rendering use each exact method source. No source clipping in repaired brief; preserve omitted unit receipts.',
'acceptance':'Freeze individual obligation labels AND whole-pair supported-usefulness judgments before assignment-key opening. Reject material current-policy regressions or indiscriminate abstention. Count form compliance separately from semantic preservation. Repeated development cases are diagnostic and cannot qualify general advice or a held-out result. Do not change criteria after outputs.',
'resource_accounting':'Hard collector reservation before dispatch; every native call through the canonical append-only attempt ledger; no tools, no paid API, no automatic retry. Stop dispatch if model digest changes, aggregate count or elapsed ceiling binds. Failed, cancelled, truncated and form-failed attempts remain visible. Independent operator-session review usage/cost unobserved, not zero.',
'operator_reply_required':True,
'candidate_source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},
'focused_tests':{'command':'python -m pytest selected briefing/consult/CLI/correction unit modules -q --no-cov','passed':151,'log':'quality-focused-fourth.log'},
'independent_source_review':'R1 response form and CLI; R2 whole-finding budget and receipt; R3 nonforecast warning. Original defects and repaired edge cases retained in reviewer scratch.'}
p=T/'followup-review-protocol-proposed.json'
assert not p.exists()
p.write_text(json.dumps(protocol,indent=2)+'\n')
print({'protocol':str(p),'status':protocol['status'],'native_calls_since_original_ceiling':0})
