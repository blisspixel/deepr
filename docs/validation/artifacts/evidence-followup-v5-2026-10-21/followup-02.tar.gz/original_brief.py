"""Build a consultable brief from study findings.

Study produces findings about material. A brief is what an expert carries into a
conversation: where the field stands, what is settled so you can skip it, where
they land and why, and what would change their mind.

This is the one stage that is allowed to form a view. Everything before it
reports; this synthesizes. That makes it the stage most able to mislead, so it
runs under three constraints:

**It runs after independent lenses, never between them.** Lenses that see each
other's output converge, and the convergence is not agreement - social influence
collapses estimate diversity without improving accuracy, and consensus-seeking
deliberation lands near the average rather than the best. Independence first,
synthesis strictly afterwards.

**It must preserve what it cannot resolve.** Every intelligence post-mortem
examined found the correct answer already present in the system and smoothed
away in aggregation. A position that resolves a genuine disagreement by not
mentioning it is the documented failure, not a cleaner product.

**Every position carries a falsifier and its supporting findings.** A stance
with nothing that would overturn it is an assertion. A stance that cannot name
what it rests on cannot answer "why do you think that", which is the second
question anyone asks an expert.

The model call is injected, so the whole builder is unit-testable at $0.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import UTC, date, datetime
from typing import Any

from deepr.experts.brief_attribution import read_orientation_statements, render_orientation
from deepr.experts.brief_contracts import (
    CONFIDENCE_LEVELS,
    LIKELIHOOD_BANDS,
    RESOLUTIONS,
    AnticipatedQuestion,
    ExpertBrief,
    Position,
    SettledState,
    SourceCredibility,
)
from deepr.experts.consult_support import study_fingerprint
from deepr.experts.corpus_store import CorpusStore
from deepr.experts.study_contracts import StudyFinding, StudyResult

BriefCompletion = Callable[[str], Awaitable[str]]

_MAX_FINDINGS_IN_PROMPT = 120
_MAX_FIELD_CHARS = 600
_LIKELIHOOD_CHOICES = ", ".join(f'"{term}"' for term in LIKELIHOOD_BANDS)
_CONFIDENCE_CHOICES = ", ".join(f'"{level}"' for level in CONFIDENCE_LEVELS)


def _utc_today() -> date:
    return datetime.now(UTC).date()


def _render_finding(finding: StudyFinding) -> str:
    """One finding as a compact line the synthesis cites by its id.

    The id leads because it is what citations resolve against. Titles collide
    and get truncated, so a citation that went through the title could match
    several findings at once or none at all.
    """
    parts = [f"{finding.finding_id} [{finding.lens}] {finding.title}"]
    for key, value in finding.payload.items():
        if key in {"anchors", "name", "title", "thread"}:
            continue
        text = "; ".join(str(v) for v in value) if isinstance(value, list) else str(value)
        text = " ".join(text.split())[:_MAX_FIELD_CHARS]
        if text:
            parts.append(f"  {key}: {text}")
    if not finding.is_grounded:
        parts.append("  (UNVERIFIED: quoted support not found in the corpus)")
    return "\n".join(parts)


def _prior_positions_block(prior: list[Any]) -> str:
    """Show the questions this expert already takes a position on.

    Without this a re-brief is non-deterministic in its *phrasing*, and that
    silently destroys position identity. Measured: the same corpus briefed
    twice produced seven differently-worded questions and restated none of the
    nine it already held, so every thread closed and reopened, no position
    could ever accumulate survival evidence, and the ledger filled with
    unrelated threads about the same subject.

    Reusing a question verbatim is what makes a revision recognisable as one.
    That has to be asked for explicitly, because a model given the same corpus
    and no memory will legitimately phrase the same question differently every
    time.
    """
    if not prior:
        return ""
    lines = "\n".join(
        f'- "{str(getattr(p, "question", "") or "").strip()}"' for p in prior if getattr(p, "question", "")
    )
    if not lines:
        return ""
    return (
        "\n===== QUESTIONS YOU ALREADY TAKE A POSITION ON =====\n"
        f"{lines}\n"
        "===== END =====\n\n"
        "Where this corpus still speaks to one of those questions, **reuse its wording exactly** "
        "and state your position on it now - which may be the same as before, or changed, and "
        "either is a real result. Reusing the wording is what lets the system tell a revised "
        "position from an unrelated new one; rephrasing it looks identical to abandoning the "
        "question and starting another.\n"
        "Where the corpus no longer supports a question, simply omit it. Do not restate a "
        "position you can no longer support in order to keep the list stable.\n"
        "Ask new questions freely where the material warrants them.\n"
    )


def build_brief_prompt(
    result: StudyResult,
    *,
    expert_name: str,
    domain: str = "",
    prior_positions: list[Any] | None = None,
    as_of_date: date | None = None,
) -> str:
    """Assemble the synthesis prompt from independent findings."""
    findings = result.findings[:_MAX_FINDINGS_IN_PROMPT]
    rendered = "\n".join(_render_finding(f) for f in findings)
    contested = [f for f in result.findings if f.lens == "contention"]
    prior_block = _prior_positions_block(list(prior_positions or []))
    today = (as_of_date or _utc_today()).isoformat()

    dissent_note = (
        f"\n{len(contested)} finding(s) came from the contention lens, which looks for disagreement "
        "between sources. Any position touching those must state what it does not resolve.\n"
        if contested
        else "\nNo contention findings were produced. Do not manufacture disagreement to fill the field.\n"
    )

    return f"""You are preparing a briefing on "{expert_name}"{f" ({domain})" if domain else ""}.

Below are findings produced by several independent analytical passes over a source corpus. Your
job is not to summarize them. It is to produce what an expert carries into a conversation: where
things stand, what is settled so a reader can skip it, where you land and why, and what would
change your mind.

Rules that make this honest rather than confident-sounding:

- Every position must cite the findings it rests on, so "why do you think that" is answerable.
  Cite by the id at the start of each finding line, for example "contention-4". Ids only; a
  citation that is not an id from the list below will be dropped.
- Every position must state an observation that would overturn it. Name something someone could
  actually go and check: a measurement, a document, a result. "If new evidence emerges" is not a
  falsifier, because nobody can check it. A position with no falsifier is an assertion.
- Preserve the source's version, platform, operating conditions, and exceptions in the stance
  itself. A conditional mechanism is not a universal recommendation. Source statements are not
  proof that a proposed workflow is safe or suitable for every caller.
- Turn a falsifier into a prospective prediction when a responsible check can be named. Set
  "falsifier_resolution_criterion" to the observable yes/no test and
  "falsifier_resolution_date" to the next date it should be checked in YYYY-MM-DD form. Today is
  {today}; never use an earlier date. If the evidence supports no responsible check date, leave
  both fields empty rather than inventing precision. A falsifier without both fields remains a
  falsifier, but it is not a registered prediction.
- Standing definitions, documented behavior, and engineering recommendations are not forecasts.
  Leave likelihood, falsifier_resolution_criterion, and falsifier_resolution_date empty for
  these. A documentation revision can change advice without inventing a future deadline or
  pretending a routine check is a prediction. Do not invent benchmark thresholds or API names.
- "likelihood" and "confidence" are different things and must not be mixed. "likelihood" is how
  likely the stance is true. "confidence" is how sound your basis for saying so is. A claim can
  be a coin flip on excellent evidence, or near-certain on thin evidence.
- Where the findings disagree, say what you did not resolve. Do not average disagreement into a
  middle position. Unresolved disagreement is a legitimate and useful output.
- Separate what is settled, what is live, and what is genuinely unknown. Refusing to spend a
  reader's time on resolved questions is most of the value here.
- At least one anticipated question must attack this brief rather than support it: the strongest
  case that you are wrong, or what you did not look at. Mark it "weakens_thesis": true.
- Split the orientation into individual statements in orientation_statements. Label each origin
  as studied (cite the finding ids), broader_knowledge (outside this study), or reasoning (your
  interpretation). Preserve source qualifications. Do not present broader knowledge or reasoning
  as a studied observation. Keep the orientation paragraph identical to those statements joined
  with spaces. A label records your attribution; it is not verification of the claim.
- Positions must stay supported by the findings below. Broader orientation is explicitly labelled.

House style, which applies to every field you return: write plain ASCII punctuation. Use a
regular hyphen, never an en dash or em dash. Use straight quotes, never curly ones. No emoji.
Prose, not decoration.
{dissent_note}{prior_block}
"likelihood" must be empty for non-probabilistic advice, or exactly one of: {_LIKELIHOOD_CHOICES}.
"confidence" must be exactly one of: {_CONFIDENCE_CHOICES}.
"resolution" must be exactly one of: single (you land on one stance);
conditional (the stance depends on an assumption, which you state); irreducible (the findings
did not reconcile, and you are reporting that rather than picking). Prefer irreducible over
inventing agreement.

Return JSON only, no prose outside it, with this shape:

{{
  "orientation": "the sixty-second version a newcomer needs before asking anything",
  "orientation_statements": [
    {{"text": "one statement", "origin": "studied", "supported_by": ["finding id"]}}
  ],
  "positions": [
    {{"question": "", "stance": "", "reasoning": "",
      "likelihood": "", "confidence": "", "resolution": "single",
      "would_change_my_mind": "", "falsifier_resolution_criterion": "",
      "falsifier_resolution_date": "",
      "supported_by": ["finding id, e.g. contention-4"],
      "unresolved_dissent": "", "confidence_basis": ""}}
  ],
  "state": {{"settled": [""], "live": [""], "unknown": [""]}},
  "key_quantities": ["the numbers that anchor discussion here"],
  "anticipated_questions": [
    {{"question": "", "answer": "", "why_asked": "", "supported_by": [""], "weakens_thesis": false}}
  ],
  "common_failures": ["what people try first that does not work, and why"]
}}

===== FINDINGS BEGIN =====
{rendered}
===== FINDINGS END =====
"""


def _as_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [" ".join(str(v).split()) for v in value if str(v).strip()]
    if isinstance(value, str) and value.strip():
        return [" ".join(value.split())]
    return []


_TYPOGRAPHY = str.maketrans(
    {
        "\u2013": "-",
        "\u2014": "-",
        "‘": "'",
        "’": "'",
        "“": '"',
        "”": '"',
        "…": "...",
        " ": " ",
    }
)
"""House style, enforced rather than requested.

The prompt asks for plain punctuation and mostly gets it. Mostly is not a
contract, and a stray en dash survives into every artifact downstream, so the
substitution happens here where it cannot be declined."""


def _text(value: Any) -> str:
    return " ".join(str(value or "").translate(_TYPOGRAPHY).split())


def _iso_date(value: Any, *, not_before: date) -> str:
    """Keep only an exact ISO calendar date.

    This guards form, not meaning. The model still owns which future observation
    matters and when it would be responsible to check it.
    """
    text = _text(value)
    try:
        parsed = date.fromisoformat(text)
    except ValueError:
        return ""
    return parsed.isoformat() if parsed >= not_before else ""


def build_credibility(corpus: CorpusStore) -> list[SourceCredibility]:
    """Report evidential depth per origin, not citation count.

    Several sources from one publisher are one publisher's authority, however
    many pages they came from.
    """
    rows: list[SourceCredibility] = []
    for origin in sorted(corpus.distinct_origins()):
        entries = [e for e in corpus.entries_for_origin(origin) if e.is_active]
        if not entries:
            continue
        rows.append(
            SourceCredibility(
                origin=origin,
                source_count=len(entries),
                trust_class=entries[0].trust_class,
                is_sole_root=len(entries) > 1,
                note=(
                    f"{len(entries)} sources from one publisher; repetition here is not independent corroboration."
                    if len(entries) > 1
                    else ""
                ),
            )
        )
    return rows


def _from_vocabulary(value: Any, allowed: Any) -> str:
    """Keep a calibration term only if it is one of the terms we defined.

    A term outside the vocabulary is dropped rather than passed through: an
    invented likelihood word reads as calibration while carrying none.
    """
    term = _text(value).lower().rstrip(".")
    return term if term in allowed else ""


def provenance_for(finding_ids: list[str], result: StudyResult, corpus: CorpusStore) -> tuple[int, int]:
    """Sources and distinct publishers behind a set of cited findings.

    The second number is the one that means anything. Five sources restating
    one publisher is one publisher's authority, and a position resting on that
    shape needs to say so rather than present five citations.
    """
    wanted = set(finding_ids)
    shas = {sha for f in result.findings if f.finding_id in wanted for sha in f.corpus_shas}
    origins = {entry.origin_key for sha in shas if (entry := corpus.entries.get(sha)) is not None}
    return len(shas), len(origins)


def _positions_from(
    raw_positions: Any,
    *,
    result: StudyResult,
    corpus: CorpusStore,
    as_of_date: date,
) -> list[Position]:
    """Build positions, keeping only citations that name a real finding.

    A position citing something that does not exist cannot answer "why do you
    think that", and keeping the citation would make it look like it could.
    """
    known_ids = {f.finding_id for f in result.findings if f.finding_id}
    positions: list[Position] = []
    for raw in raw_positions or []:
        if not isinstance(raw, dict):
            continue
        cited = [t for t in _as_list(raw.get("supported_by")) if t in known_ids]
        documents, roots = provenance_for(cited, result, corpus)
        positions.append(
            Position(
                question=_text(raw.get("question")),
                stance=_text(raw.get("stance")),
                reasoning=_text(raw.get("reasoning")),
                would_change_my_mind=_text(raw.get("would_change_my_mind")),
                falsifier_resolution_criterion=_text(raw.get("falsifier_resolution_criterion")),
                falsifier_resolution_date=_iso_date(
                    raw.get("falsifier_resolution_date"),
                    not_before=as_of_date,
                ),
                supported_by=cited,
                unresolved_dissent=_text(raw.get("unresolved_dissent")),
                confidence_basis=_text(raw.get("confidence_basis")),
                likelihood=_from_vocabulary(raw.get("likelihood"), LIKELIHOOD_BANDS),
                confidence=_from_vocabulary(raw.get("confidence"), CONFIDENCE_LEVELS),
                resolution=_from_vocabulary(raw.get("resolution"), RESOLUTIONS) or "single",
                supporting_documents=documents,
                distinct_roots=roots,
            )
        )
    return positions


def assemble_brief(
    parsed: dict[str, Any],
    *,
    expert_name: str,
    result: StudyResult,
    corpus: CorpusStore,
    as_of_date: date | None = None,
) -> ExpertBrief:
    """Turn a parsed synthesis into a brief, keeping only verifiable citations."""
    known_ids = {f.finding_id for f in result.findings if f.finding_id}

    positions = _positions_from(
        parsed.get("positions"),
        result=result,
        corpus=corpus,
        as_of_date=as_of_date or _utc_today(),
    )

    questions = [
        AnticipatedQuestion(
            question=_text(raw.get("question")),
            answer=_text(raw.get("answer")),
            why_asked=_text(raw.get("why_asked")),
            supported_by=[t for t in _as_list(raw.get("supported_by")) if t in known_ids],
            weakens_thesis=bool(raw.get("weakens_thesis")),
        )
        for raw in (parsed.get("anticipated_questions") or [])
        if isinstance(raw, dict) and _text(raw.get("question"))
    ]

    raw_state = parsed.get("state") or {}
    state = SettledState(
        settled=_as_list(raw_state.get("settled")) if isinstance(raw_state, dict) else [],
        live=_as_list(raw_state.get("live")) if isinstance(raw_state, dict) else [],
        unknown=_as_list(raw_state.get("unknown")) if isinstance(raw_state, dict) else [],
    )

    statements = read_orientation_statements(parsed.get("orientation_statements"))
    for statement in statements:
        statement.text = _text(statement.text)
    brief = ExpertBrief(
        expert_name=expert_name,
        orientation=" ".join(item.text for item in statements) if statements else _text(parsed.get("orientation")),
        orientation_statements=statements,
        positions=[p for p in positions if p.stance],
        state=state,
        key_quantities=_as_list(parsed.get("key_quantities")),
        anticipated_questions=questions,
        common_failures=_as_list(parsed.get("common_failures")),
        credibility=build_credibility(corpus),
        finding_titles={f.finding_id: f.title for f in result.findings if f.finding_id},
        generated_from_findings=len(result.findings),
        study_fingerprint=study_fingerprint(result),
    )

    ungrounded = [f for f in result.findings if not f.is_grounded]
    if ungrounded:
        brief.limitations.append(
            f"{len(ungrounded)} of {len(result.findings)} findings were not verifiable against the "
            "retained corpus. Positions resting on them inherit that."
        )
    brief.limitations.extend(result.limitations)
    return brief


async def build_brief(
    *,
    expert_name: str,
    result: StudyResult,
    corpus: CorpusStore,
    completion: BriefCompletion,
    domain: str = "",
    prior_positions: list[Any] | None = None,
    as_of_date: date | None = None,
) -> ExpertBrief:
    """Synthesize one brief at the supplied cutoff or the current UTC date.

    The same date governs the prompt and prediction registration even if the
    completion crosses midnight. Returns an empty brief rather than raising.
    """
    from deepr.experts.study import extract_json_object

    if not result.findings:
        brief = ExpertBrief(expert_name=expert_name)
        brief.limitations.append(
            "No study findings to brief from. Run `expert study` first; a brief over nothing "
            "would be invention rather than synthesis."
        )
        return brief

    effective_date = as_of_date or _utc_today()
    prompt = build_brief_prompt(
        result,
        expert_name=expert_name,
        domain=domain,
        prior_positions=prior_positions,
        as_of_date=effective_date,
    )
    try:
        raw = await completion(prompt)
    except Exception as exc:
        brief = ExpertBrief(expert_name=expert_name, generated_from_findings=len(result.findings))
        brief.limitations.append(f"Synthesis call failed: {str(exc)[:200]}")
        return brief

    parsed, error = extract_json_object(raw)
    if parsed is None:
        brief = ExpertBrief(expert_name=expert_name, generated_from_findings=len(result.findings))
        snippet = " ".join((raw or "").split())[:200]
        brief.limitations.append(f"Synthesis did not return usable JSON ({error}). Began: {snippet!r}")
        return brief

    return assemble_brief(
        parsed,
        expert_name=expert_name,
        result=result,
        corpus=corpus,
        as_of_date=effective_date,
    )


def _short(title: str, limit: int = 90) -> str:
    """Shorten a citation for display, on a word boundary.

    Lenses that describe rather than name produce sentence-length titles. Cited
    verbatim they wrap into a wall and cut mid-word; the full title stays in the
    JSON, this is only what the reader sees.
    """
    if len(title) <= limit:
        return title
    return title[:limit].rsplit(" ", 1)[0] + "..."


def _render_calibration(position: Position) -> list[str]:
    """Likelihood and confidence, on separate lines because they are separate.

    The band is printed with its numbers every time. Readers hold the words to
    a different scale than the author does, and a legend elsewhere does not fix
    that, so the number travels with the word.
    """
    lines: list[str] = []
    band = position.likelihood_band
    if band:
        lines.append(f"   - Likelihood it holds: {position.likelihood} ({band[0]}-{band[1]}%)")
    if position.confidence:
        basis = f" ({position.confidence_basis})" if position.confidence_basis else ""
        lines.append(f"   - Confidence in that basis: {position.confidence}{basis}")
    elif position.confidence_basis:
        lines.append(f"   - Confidence rests on: {position.confidence_basis}")
    return lines


def _cited_labels(position: Position, titles: dict[str, str]) -> str:
    """Render citations as readable titles, keeping the id for lookup."""
    return "; ".join(f"{_short(titles.get(cid, cid))} ({cid})" for cid in position.supported_by[:4])


def _render_position(index: int, position: Position, titles: dict[str, str]) -> list[str]:
    """One position: where it lands, what it rests on, what would overturn it."""
    label = {"irreducible": " (unresolved)", "conditional": " (conditional)"}.get(position.resolution, "")
    lines = [f"{index}. **{position.question or 'Position'}**{label}"]
    if position.resolution == "irreducible":
        lines.append("   - **Not resolved.** The findings did not reconcile; both readings are below.")
    lines.append(f"   - Stance: {position.stance}")
    if position.reasoning:
        lines.append(f"   - Because: {position.reasoning}")
    lines.extend(_render_calibration(position))
    if position.unresolved_dissent:
        lines.append(f"   - **Does not resolve**: {position.unresolved_dissent}")
    if position.would_change_my_mind:
        lines.append(f"   - Would change my mind: {position.would_change_my_mind}")
        if position.is_registered_prediction:
            lines.append(
                f"   - Check on {position.falsifier_resolution_date}: {position.falsifier_resolution_criterion}"
            )
        if position.falsifier_is_decorative:
            lines.append("   - **That falsifier names nothing observable**, so nothing can check it.")
    else:
        lines.append("   - **No falsifier stated**: treat as assertion, not judgment.")
    if position.supported_by:
        lines.append(f"   - Rests on: {_cited_labels(position, titles)}")
    if position.supporting_documents:
        depth = f"{position.supporting_documents} source(s), {position.distinct_roots} publisher(s)"
        flag = " - **one publisher, so this is not corroboration**" if position.is_single_origin else ""
        lines.append(f"   - Evidential depth: {depth}{flag}")
    lines.append("")
    return lines


def _render_positions(brief: ExpertBrief) -> list[str]:
    """Render each position with what it rests on and what would overturn it."""
    if not brief.positions:
        return []
    lines = ["## Where I land, and why", ""]
    for index, position in enumerate(brief.positions, 1):
        lines.extend(_render_position(index, position, brief.finding_titles))
    return lines


def _render_state(brief: ExpertBrief) -> list[str]:
    """Settled / live / unknown. Telling a reader what to skip is most of the value."""
    if not (brief.state.settled or brief.state.live or brief.state.unknown):
        return []
    lines = ["## Settled, live, unknown", ""]
    for label, items in (
        ("Settled (skip these)", brief.state.settled),
        ("Live", brief.state.live),
        ("Genuinely unknown", brief.state.unknown),
    ):
        if items:
            lines.append(f"**{label}**")
            lines.extend(f"- {item}" for item in items)
            lines.append("")
    return lines


def _render_lists(brief: ExpertBrief) -> list[str]:
    lines: list[str] = []
    for heading, items in (
        ("## The numbers that matter", brief.key_quantities),
        ("## What people try that does not work", brief.common_failures),
    ):
        if items:
            lines.extend([heading, ""])
            lines.extend(f"- {item}" for item in items)
            lines.append("")
    return lines


def _render_questions(brief: ExpertBrief) -> list[str]:
    if not brief.anticipated_questions:
        return []
    lines = ["## Questions I expect", ""]
    for question in brief.anticipated_questions:
        attack = " (this one costs me something)" if question.weakens_thesis else ""
        lines.append(f"**{question.question}**{attack}")
        lines.append(question.answer)
        if question.why_asked:
            lines.append(f"_Asked because: {question.why_asked}_")
        lines.append("")
    return lines


def _render_credibility(brief: ExpertBrief) -> list[str]:
    """Evidential depth per origin, not citation count."""
    if not brief.credibility:
        return []
    lines = ["## Who this rests on", "", "| Origin | Sources | Trust | Note |", "|---|---|---|---|"]
    lines.extend(
        f"| {row.origin} | {row.source_count} | {row.trust_class} | {row.note or '-'} |" for row in brief.credibility
    )
    lines.append("")
    return lines


def render_brief(brief: ExpertBrief) -> str:
    """Render the brief for reading. Bottom line first."""
    lines = [f"# {brief.expert_name}: brief", ""]
    if brief.orientation:
        lines.extend(
            [
                "## In sixty seconds",
                "",
                render_orientation(brief.orientation, brief.orientation_statements, binding="not checked in this view"),
                "",
            ]
        )

    lines.extend(_render_positions(brief))

    lines.extend(_render_state(brief))
    lines.extend(_render_lists(brief))
    lines.extend(_render_questions(brief))
    lines.extend(_render_credibility(brief))

    warnings = brief.integrity_warnings()
    if warnings:
        lines.extend(["## Read this brief knowing", ""])
        lines.extend(f"- {w}" for w in warnings)
        lines.append("")

    if brief.limitations:
        lines.extend(["## Limitations", ""])
        lines.extend(f"- {item}" for item in brief.limitations)
        lines.append("")

    lines.extend(
        [
            "---",
            "",
            "Derived from study findings over a retained corpus. Positions are the expert's "
            "reading of that evidence, not verified fact; each states what would overturn it.",
            "",
        ]
    )
    return "\n".join(lines)
