"""Pure scratch invariants. Importing this module performs no filesystem writes."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path

MODULE_PATHS = (
    'src/deepr/experts/brief.py',
    'src/deepr/experts/brief_attribution.py',
    'src/deepr/experts/brief_contracts.py',
    'src/deepr/experts/brief_selection.py',
    'src/deepr/experts/consult_support.py',
    'src/deepr/experts/study_contracts.py',
    'src/deepr/experts/consult_context.py',
    'src/deepr/experts/consult_prompt.py',
    'src/deepr/experts/consult_response.py',
    'src/deepr/experts/council.py',
    'src/deepr/experts/council_synthesis_runtime.py',
    'src/deepr/experts/consult_routing.py',
    'src/deepr/backends/local.py',
    'src/deepr/backends/embedding_profiles.py',
    'src/deepr/experts/investigation/ollama_backend.py',
    'src/deepr/observability/local_attempts.py',
    'src/deepr/evals/correction_survival.py',
    'src/deepr/evals/correction_survival_cases.py',
    'src/deepr/evals/correction_survival_local.py',
    'src/deepr/evals/correction_survival_review.py',
)
EXTRA_MODULE_PATHS = (
    'src/deepr/experts/consult.py',
    'src/deepr/experts/corpus_store.py',
    'src/deepr/utils/atomic_io.py',
)
CHANGED_CONSULT_MODULES = frozenset({
    'src/deepr/experts/consult_prompt.py',
    'src/deepr/experts/consult_response.py',
})
RUBRIC_SHA256 = 'e349467573ee9a275d75c09f5d9660b5237ff943f1f103540496436a014e1f9a'
GENERATOR = {
    'model': 'qwen3.8:27b',
    'digest': 'aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813',
    'num_ctx': 16384, 'temperature': 0, 'think': False,
    'seeds': [20261020, 20261021], 'timeout_seconds': 600,
}

REVIEW_CONTROL_HASHES = {'quality-review-v6-instructions.txt': '2039cfb555aa5fa6a6e7114019a9f0be2d0bc5f37e0da267a5a11aa281712710', 'agent-calibration-inputs.json': 'cf53a4f0ff431a7a0241a752c54596b427b36159d17d5169901ce464c5b738b5', 'review-instructions-v3.txt': 'e349467573ee9a275d75c09f5d9660b5237ff943f1f103540496436a014e1f9a', 'agent-calibration-freeze.json': '60fa55ca8308f95c27821f143b2254a7015368136757225ec0c178757a05955f'}
PRIOR_LEDGER_HASHES = {'runtime/costs/cost_ledger.jsonl': '2af1a9c4344e1c9576c200ee3c7b7c687e0905008efe8b2eec9b2b4c9c97dec1', 'followup-runtime/costs/cost_ledger.jsonl': 'd2291d3c0cd0338b23ebed46a10f2b22161cdc4e1d7f0c704b1ba4909634f658', 'v6-runtime/costs/cost_ledger.jsonl': '8f076a133930ded4ab9dd1fcd776e55e55a991515dd77db00110bea8ac8317b6'}


class FollowupInvariantError(RuntimeError):
    pass


def require(condition, detail):
    if not condition:
        raise FollowupInvariantError('V7 invariant failed: ' + detail)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_exclusive(path, value):
    """Create once; callers must choose their output directory explicitly."""
    with Path(path).open('x', encoding='utf-8', newline='\n') as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write('\n')


def validate_modules(root, expected):
    require(set(expected) == set(MODULE_PATHS), 'Exact 20-module recipe required')
    for relative, expected_hash in expected.items():
        path = Path(root) / relative
        require(path.is_file() and digest(path) == expected_hash, 'Recipe module changed: ' + relative)


def validate_extras(root, expected):
    require(set(expected) == set(EXTRA_MODULE_PATHS), 'Prospective extra dependency closure required')
    for relative, expected_hash in expected.items():
        require(digest(Path(root) / relative) == expected_hash, 'Extra source changed: ' + relative)


def require_prospective_extras(root, task):
    receipt = read(Path(task) / 'packing-v7-prospective-extras-receipt.json')
    require(receipt['source_final_sha256'] == digest(Path(task) / 'v7-source-final.json'), 'Extra source finality binding')
    require(receipt['provenance'] == 'prospectively captured before V7 fixture build and collection', 'Extra provenance must be prospective')
    validate_extras(root, receipt['extra_source_modules'])
    return receipt


def recipe_digest(root):
    """Owning recipe algorithm: ordered package-relative path then raw bytes.

    Matches correction_survival.recipe_sha256: no delimiter and no src/ prefix
    in the bytes representing the package-relative module path.
    """
    identity = hashlib.sha256()
    for relative in MODULE_PATHS:
        identity.update(relative.removeprefix('src/').encode('utf-8'))
        identity.update((Path(root) / relative).read_bytes())
    return identity.hexdigest()


def validate_recipe(root, expected):
    require(recipe_digest(root) == expected, 'Owning source recipe identity differs')


def require_source_final(root, task):
    declaration = read(Path(task) / 'v7-source-final.json')
    require(declaration.get('source_final') is True, 'Root source-final confirmation required')
    require(declaration.get('confirmed_by') == '/root', 'Root declaration identity required')
    require(bool(declaration.get('instruction', '').strip()), 'Explicit source-final instruction required')
    validate_modules(root, declaration.get('source_modules', {}))
    validate_recipe(root, declaration.get('source_recipe_sha256'))
    return declaration


def validate_protocol(protocol):
    require(protocol.get('status') == 'frozen', 'Frozen V7 protocol required')
    require(protocol['local_generation_ceiling'] == 24, '24 calls required')
    require(protocol['wall_ceiling_seconds'] == 5400, '5400 seconds required')
    require(protocol['paid_provider_api_ceiling_usd'] == 0, 'Zero direct paid API ceiling required')
    require(protocol['automatic_retry'] is False, 'Retries forbidden')
    require(protocol['generator'] == GENERATOR, 'Pinned generator changed')
    require(protocol['primary_rubric_sha256'] == RUBRIC_SHA256, 'Frozen rubric changed')
    require(protocol['review_controls'] == REVIEW_CONTROL_HASHES, 'Unchanged review controls required')
    require(protocol['prior_ledgers'] == PRIOR_LEDGER_HASHES, 'All 156 prior attempt ledgers must remain frozen')
    require(protocol['allowances'] == {
        'consult_prompt_chars': 6500, 'production_prompt_chars_ceiling': 16000,
        'output_tokens': 1024, 'call_timeout_seconds': 600,
    }, 'Matched consult allowances changed')


def validate_manifest(manifest):
    require(manifest['answers_scheduled'] == len(manifest['jobs']) == 24, '24 scheduled consult cells required')
    require(len({job['item_id'] for job in manifest['jobs']}) == 24, 'Unique cells required')
    require(manifest['pairs'] == 12 and manifest['case_families'] == 6, 'Six families / 12 seeded pairs required')
    require(manifest['generator'] == GENERATOR, 'Manifest generator changed')


def validate_input(item, job):
    require(item['item_id'] == job['item_id'], 'Input item binding')
    require(item['kind'] == 'consult', 'V7 consult-only trial')
    require(item['status'] == 'ready', 'Refused fixture may not dispatch')
    require(item['seed'] in GENERATOR['seeds'], 'Frozen seed required')
    require(item['output_tokens'] == 1024 and item['timeout_seconds'] == 600, 'Per-call allowance changed')
    require(item['prompt_limit_chars'] == 6500 and len(item['prompt']) <= 6500, 'Prompt allowance changed')
    prompt_hash = hashlib.sha256(item['prompt'].encode()).hexdigest()
    require(prompt_hash == item['prompt_sha256'] == item['delivered_evidence']['prompt_sha256'], 'Prompt byte binding')
    require(item['prompt'] == item['delivered_evidence']['prompt'], 'Delivered prompt differs')


def before_transport(root, protocol, request, active_deadline, wall_remaining, monotonic):
    """Run after dispatch accounting, before the native HTTP transport."""
    validate_modules(root, protocol['source_modules'])
    validate_extras(root, protocol['extra_source_modules'])
    require(request is not None and Path(request).is_file(), 'Durable reservation required before transport')
    remaining = min(active_deadline - monotonic(), wall_remaining())
    require(remaining > 0, 'Deadline exhausted before native POST')
    return remaining


def utc_now():
    return datetime.now(UTC).isoformat()
