"""Synthetic-only V7 accounting checks. No real collection or model calls."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,runpy,tempfile

T=Path(__file__).resolve().parent
M=runpy.run_path(str(T/'audit_native_resources_v7.py'),run_name='synthetic_resource_checks')
H=lambda raw:hashlib.sha256(raw).hexdigest()
E=lambda value:(json.dumps(value,indent=2)+'\n').encode()


def fixture(root):
    def put(name,value,raw=False):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value if raw else E(value));return H(p.read_bytes())
    priors={}
    for relative,count in M['PRIOR_ATTEMPTS'].items():
        raw=b''.join(E({'request_id':f'synthetic-prior-{i}'}).replace(b'\n',b'')+b'\n' for i in range(count))
        priors[relative]=put(relative,raw,True)
    source_snapshot=put('packing-v7-source-snapshot-receipt.json',{'synthetic':True})
    extras=put('packing-v7-prospective-extras-receipt.json',{'synthetic':True})
    generator={'model':'synthetic-local','digest':'synthetic-model-digest'}
    jobs=[];inputs={};ids=[f'{i:016x}' for i in range(1,25)]
    for iid in ids:
        inputs[iid]={'item_id':iid,'kind':'consult','seed':1,'prompt':'Synthetic prompt only.','output_tokens':10}
        jobs.append({'item_id':iid,'input_sha256':put('packing-fixtures-v7/'+iid+'.input.json',inputs[iid])})
    manifest={'jobs':jobs,'generator':generator};mh=put('packing-fixtures-v7/manifest.json',manifest)
    rh=put('answer_runner_v7.py',b'SYNTHETIC NOT EXECUTED',True)
    protocol={'paid_provider_api_ceiling_usd':0,'automatic_retry':False,'local_generation_ceiling':24,
        'wall_ceiling_seconds':5400,'generator':generator,'prior_ledgers':priors,
        'original_ledger_sha256':priors['runtime/costs/cost_ledger.jsonl'],
        'v5_ledger_sha256':priors['followup-runtime/costs/cost_ledger.jsonl'],
        'prior_native_attempts':156,'total_native_attempts_if_v7_full':180,
        'source_snapshot_receipt_sha256':source_snapshot,'prospective_extras_receipt_sha256':extras,
        'source_recipe_sha256':H(b'synthetic recipe')}
    ph=put('v7-review-protocol.json',protocol)
    authority={'authorized':True,'paid_provider_api_ceiling_usd':0,'local_generation_ceiling':24,
        'wall_ceiling_seconds':5400,'protocol_sha256':ph,'runner_sha256':rh}
    ah=put('v7-operator-authorization.json',authority)
    put('v7-collector-freeze.json',{'paid_provider_api_ceiling_usd':0,'manifest_sha256':mh,
        'authorization_sha256':ah,'protocol_sha256':ph,'runner_sha256':rh,'max_calls':24,'max_wall_seconds':5400,
        'started_at':'2020-01-01T00:00:00+00:00','prior_native_attempts':156,'native_attempts_if_full':180})
    events=[];results=[]
    for index,iid in enumerate(ids):
        prefix=f'v7-runtime/calls/{index+1:03d}.{iid}'
        request={'item_id':iid,'phase':'answer258v7','seed':1,'user':inputs[iid]['prompt'],'max_tokens':10,
            'generator':generator,'manifest_sha256':mh,'created_at':'2020-01-01T00:00:01+00:00'}
        request_hash=put(prefix+'.request.json',request)
        ti,to=(None,2) if index==0 else (3,None) if index==1 else (None,None) if index==2 else (10,5)
        raw={'message':{'content':'Complete synthetic draft.'}}
        if ti is not None:raw['prompt_eval_count']=ti
        if to is not None:raw['eval_count']=to
        transport_hash=put(prefix+'.transport.json',{'request_sha256':request_hash,'raw_response':raw})
        native_hash=put(prefix+'.native.json',{'raw_response':raw})
        response={'item_id':iid,'status':'form_failed','request_sha256':request_hash,
            'answer':'Complete synthetic draft.','answer_sha256':H(b'Complete synthetic draft.'),
            'tokens_input':ti,'tokens_output':to,'transport_response_sha256':transport_hash,
            'native_response_sha256':native_hash}
        put(prefix+'.response.json',response)
        response_hash=put('packing-fixtures-v7/answers/'+iid+'.json',response)
        results.append({'item_id':iid,'status':response['status'],'file_sha256':response_hash})
        for offset,(op,status) in enumerate((('native_local_requested','requested'),('native_local_dispatching','dispatching'),('native_local_terminal','returned'))):
            events.append({'provider':'local','source':'local.native_ollama','cost_usd':0,
                'request_id':'issue-completion:answer258v7:'+iid,'idempotency_key':f'{iid}:{offset}',
                'operation':op,'model':generator['model'],'timestamp':f'2020-01-01T00:00:0{offset+1}+00:00',
                'tokens_input':ti,'tokens_output':to,
                'metadata':{'schema':'native-local-attempt-v1','kind':'chat','attempt_id':iid,'status':status,
                            'model_digest':generator['digest']}})
    put('v7-runtime/costs/cost_ledger.jsonl',b''.join(json.dumps(e).encode()+b'\n' for e in events),True)
    put('packing-fixtures-v7/answers-complete.json',{'manifest_sha256':mh,'terminal_answers':24,
        'answers_scheduled':24,'results':results,'wall_seconds':10})
    return priors


def main():
    outcomes={};globals_=M['audit'].__globals__;original=globals_['PRIOR_LEDGER_EXPECTED']
    with tempfile.TemporaryDirectory(prefix='resources-v7-synthetic-R1-',dir=T/'reviewers/R1') as temporary:
        root=Path(temporary).resolve();prior=fixture(root);globals_['PRIOR_LEDGER_EXPECTED']=prior
        try:
            report=M['audit'](root)
            assert report['accounting_complete'] and report['reserved_attempts']==report['native_ledger_attempts']==24
            assert report['native_ledger_events']==72 and report['total_native_attempts']==180
            outcomes['complete24_72events_three_prior_ledgers_total180']='passed'
            assert report['totals']['known_usage_attempts']==21 and report['totals']['unknown_usage_attempts']==3
            assert report['totals']['known_input_attempts']==report['totals']['known_output_attempts']==22
            assert report['totals']['input_tokens']==213 and report['totals']['output_tokens']==107
            assert report['usage_complete'] is False
            outcomes['partial_usage_components_sum_separately_unknown_not_zero']='passed'
            def changed(name,fn):
                path=root/name;before=path.read_bytes();value=json.loads(before);fn(value);path.write_bytes(E(value));return path,before
            def refusal(name,relative,fn=None):
                path=root/relative;before=path.read_bytes()
                if fn is None:path.unlink()
                else:
                    value=json.loads(before);fn(value);path.write_bytes(E(value))
                try:
                    try:M['audit'](root)
                    except (ValueError,OSError,KeyError,TypeError):outcomes[name]='refused'
                    else:raise AssertionError('Unexpected admission: '+name)
                finally:path.write_bytes(before)
            refusal('missing_completion_refused','packing-fixtures-v7/answers-complete.json')
            refusal('incomplete23cells_refused','packing-fixtures-v7/answers-complete.json',lambda x:x.update(terminal_answers=23))
            refusal('wrong_completion_status_refused','packing-fixtures-v7/answers-complete.json',lambda x:x['results'][0].update(status='completed'))
            for relative in prior:
                path=root/relative;before=path.read_bytes();path.write_bytes(before+b'\n')
                try:
                    try:M['audit'](root)
                    except ValueError:outcomes['changed_prior_'+relative.split('/')[0]+'_refused']='refused'
                    else:raise AssertionError('Changed prior ledger admitted')
                finally:path.write_bytes(before)
            iid='0000000000000001';request=f'v7-runtime/calls/001.{iid}.request.json'
            refusal('reservation_prompt_changed_refused',request,lambda x:x.update(user='Changed prompt'))
            refusal('retained_transport_text_changed_refused',f'v7-runtime/calls/001.{iid}.transport.json',lambda x:x['raw_response']['message'].update(content='Changed'))
            ledger=root/'v7-runtime/costs/cost_ledger.jsonl';before=ledger.read_bytes();ev=[json.loads(l) for l in before.splitlines()]
            ev[2]['tokens_output']=999;ledger.write_bytes(b''.join(json.dumps(e).encode()+b'\n' for e in ev))
            try:
                try:M['audit'](root)
                except ValueError:outcomes['known_terminal_usage_join_mismatch_refused']='refused'
                else:raise AssertionError('Known usage mismatch admitted')
            finally:ledger.write_bytes(before)
            ev=[json.loads(l) for l in before.splitlines()][1:];ledger.write_bytes(b''.join(json.dumps(e).encode()+b'\n' for e in ev))
            try:
                try:M['audit'](root)
                except ValueError:outcomes['missing_requested_event_refused']='refused'
                else:raise AssertionError('Missing requested event admitted')
            finally:ledger.write_bytes(before)
            path,old=changed('packing-fixtures-v7/answers-complete.json',lambda x:x.update(wall_seconds=5401))
            try:
                assert M['audit'](root)['accounting_complete'] is False
                outcomes['wall_overrun_is_negative_accounting']='passed'
            finally:path.write_bytes(old)
            assert not (root/'v7-native-resource-audit.json').exists();outcomes['pure_audit_no_output_mutation']='passed'
        finally:globals_['PRIOR_LEDGER_EXPECTED']=original
    out=T/'reviewers/R1/resources-v7-synthetic-checks.json'
    with out.open('x') as f:json.dump({'checked_at':datetime.now(timezone.utc).isoformat(),'checks':outcomes,
        'resource_helper_sha256':H((T/'audit_native_resources_v7.py').read_bytes()),'real_collection_audited':False,
        'real_keys_answers_or_verdicts_read':False,'model_calls':0},f,indent=2);f.write('\n')
    print(json.dumps({'report':str(out),'checks':len(outcomes),'actual_audit_run':False}))


if __name__=='__main__':main()
