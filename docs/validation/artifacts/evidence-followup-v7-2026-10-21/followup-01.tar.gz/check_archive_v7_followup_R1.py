"""Isolated synthetic guard checks; never opens real V7 data or keys."""
from __future__ import annotations
import copy,hashlib,json,os,runpy,tempfile
from pathlib import Path

T=Path(__file__).resolve().parent
M=runpy.run_path(str(T/'archive_v7_followup.py'),run_name='offline_archive_synthetic_checks')
E=M['encode']; H=M['sha']; CORE=M['CORE']; PINNED=M['PINNED']; SNAPSHOTS=M['SNAPSHOTS']


def fixture(root):
    values={}
    def put(name,value,raw=False):
        values[name]=value if raw else E(value)
        return H(values[name])
    ids=[f'{index:016x}' for index in range(1,25)]
    sources=[]
    for index in range(19):
        source=f'Synthetic source bytes only {index}.'.encode();source_hash=H(source)
        put(f'packing-fixtures-v7/corpus/sources/{source_hash[:2]}/{source_hash}.md',source,True)
        sources.append({'source_id':f'synthetic{index}','text':source.decode(),'text_sha256':source_hash})
    put('packing-fixtures-v7/corpus/index.jsonl',b'synthetic retained corpus inventory\n',True)
    modules={}
    for index,name in enumerate(M['RECIPE_PATHS']):
        raw=f'synthetic recipe {index}\n'.encode()
        modules[name]=put('packing-v7-source-snapshot/'+name,raw,True)
    recipe=hashlib.sha256()
    for name in M['RECIPE_PATHS']:
        recipe.update(name.removeprefix('src/').encode());recipe.update(values['packing-v7-source-snapshot/'+name])
    recipe_hash=recipe.hexdigest()
    final_hash=put('v7-source-final.json',{'source_final':True,'confirmed_at':'2019-12-31T00:00:00+00:00',
        'source_modules':modules,'source_recipe_sha256':recipe_hash})
    snapshot={'frozen_at':'2019-12-31T01:00:00+00:00','source_final_sha256':final_hash,
        'source_snapshot':'packing-v7-source-snapshot','source_modules':modules}
    snapshot_hash=put('packing-v7-source-snapshot-receipt.json',snapshot)
    extra_modules={}
    for index,name in enumerate(M['EXTRA_PATHS']):
        extra_modules[name]=put('packing-v7-source-snapshot/'+name,f'synthetic extra {index}\n'.encode(),True)
    extras_hash=put('packing-v7-prospective-extras-receipt.json',{'frozen_at':'2019-12-31T01:00:00+00:00',
        'source_final_sha256':final_hash,'source_snapshot':'packing-v7-source-snapshot',
        'extra_source_modules':extra_modules,'provenance':'prospectively captured before V7 fixture build and collection'})
    proof_hash=put('packing-v7-source-recipe-proof.json',{'source_recipe_sha256':recipe_hash,
        'source_final_sha256':final_hash,'source_snapshot_receipt_sha256':snapshot_hash,'live_and_snapshot_recomputed':True})
    old_consult=b'synthetic old consult\n'
    prompt='Synthetic exact prompt.'; jobs=[]; results=[]; attempts=[]; items={}; answers={}
    for index,iid in enumerate(ids):
        item={'item_id':iid,'prompt':prompt,'prompt_sha256':H(prompt.encode()),'delivered_evidence':{'prompt':prompt},
              'sources':sources,
              'kind':'consult','question':'Synthetic question.',
              'obligations':[{'obligation_id':f'synthetic-slot-{slot}','description':'Synthetic structure only.'} for slot in range(3 if index<8 else 2)]}
        items[iid]=item
        input_hash=put(f'packing-fixtures-v7/{iid}.input.json',item)
        answer={'item_id':iid,'status':'failed' if index==0 else 'form_failed'}
        if index:
            answer.update(answer='Full synthetic retained draft.',answer_sha256=H(b'Full synthetic retained draft.'))
        answer_hash=put(f'packing-fixtures-v7/answers/{iid}.json',answer)
        answers[iid]=answer
        jobs.append({'item_id':iid,'input_sha256':input_hash});results.append({'item_id':iid,'status':answer['status'],'file_sha256':answer_hash})
        request=f'v7-runtime/calls/{index+1:03d}.{iid}.request.json'
        rh=put(request,{'item_id':iid,'user':prompt})
        response_hash=put(request.replace('.request.json','.response.json'),answer)
        attempts.append({'item_id':iid,'request_sha256':rh,'response_sha256':response_hash,
                         'answer_receipt_sha256':answer_hash,'transport_sha256':None})
    generator={'synthetic':True}
    manifest={'jobs':jobs,'answers_scheduled':24,'current_modules':modules|extra_modules,
              'source_modules':modules,'extra_source_modules':extra_modules,'source_final_sha256':final_hash,
              'frozen_at':'2019-12-31T02:00:00+00:00','old_consult_sha256':H(old_consult),'generator':generator}
    mh=put('packing-fixtures-v7/manifest.json',manifest)
    put('packing-fixtures-v7/answers-complete.json',{'answers_scheduled':24,'terminal_answers':24,'manifest_sha256':mh,'results':results})
    ah=put('v7-operator-authorization.json',{'authorized':True,'local_generation_ceiling':24,'wall_ceiling_seconds':5400,'paid_provider_api_ceiling_usd':0})
    protocol=put('v7-review-protocol.json',{'local_generation_ceiling':24,'wall_ceiling_seconds':5400,
        'paid_provider_api_ceiling_usd':0,'automatic_retry':False,'manifest_sha256':mh,'generator':generator,
        'source_modules':modules,'extra_source_modules':extra_modules,'source_recipe_sha256':recipe_hash,'v5_ledger_sha256':'0'*64,
        'source_snapshot_receipt_sha256':snapshot_hash,'prospective_extras_receipt_sha256':extras_hash,
        'source_final_sha256':final_hash,'source_recipe_proof_sha256':proof_hash,'frozen_at':'2019-12-31T03:00:00+00:00',
        'prior_ledgers':{'v6-runtime/costs/cost_ledger.jsonl':'1'*64}})
    runner=put('answer_runner_v7.py',b'SYNTHETIC, NOT EXECUTED',True)
    audit=put('reviewers/R3/packing-v7-precollection-audit.json',{'synthetic':True})
    put('v7-collector-freeze.json',{'manifest_sha256':mh,'max_calls':24,'max_wall_seconds':5400,
        'authorization_sha256':ah,'protocol_sha256':protocol,'runner_sha256':runner,'audit_sha256':audit,
        'started_at':'2019-12-31T04:00:00+00:00','prior_native_attempts':156,'native_attempts_if_full':180})
    ledger=b'Synthetic canonical ledger bytes.\n';put('v7-runtime/costs/cost_ledger.jsonl',ledger,True)
    put('v7-native-resource-audit.json',{'accounting_complete':True,'original_100_attempt_ledger_unchanged':True,
        'manifest_sha256':mh,'native_ledger_sha256':H(ledger),'attempt_joins':attempts,
        'v5_32_attempt_ledger_unchanged':True,'prior_v5_ledger_sha256':'0'*64,'scheduled_cells':24,'terminal_cells':24,
        'v6_24_attempt_ledger_unchanged':True,'prior_v6_ledger_sha256':'1'*64,
        'prior_ledgers_sha256':{'v6-runtime/costs/cost_ledger.jsonl':'1'*64},'prior_native_attempts':156,
        'total_native_attempts_if_full':180,'total_native_attempts':180,'source_recipe_sha256':recipe_hash,
        'source_snapshot_receipt_sha256':snapshot_hash,'prospective_extras_receipt_sha256':extras_hash,
        'max_attempts':24,'max_wall_seconds':5400,'protocol_sha256':protocol,'runner_sha256':runner,
        'reserved_attempts':24,'native_ledger_attempts':24,'totals':{'unknown_usage_attempts':24}})
    primary_packet=put('packing-fixtures-v7/blinded-review.json',[
        {key:items[iid][key] for key in ('item_id','kind','question','obligations','sources','delivered_evidence')} | answers[iid] for iid in ids])
    labels=[{'item_id':iid,'obligation_id':obligation['obligation_id'],'answer_sha256':answers[iid].get('answer_sha256'), 'label':None if index==0 else 'synthetic_presence_token'} for index,iid in enumerate(ids) for obligation in items[iid]['obligations']]
    labels_hash=put('review258-v7-final-labels.json',labels)
    r1=put('reviewers/R1/review258-v7.json',[]);r2=put('reviewers/R2/review258-v7.json',[])
    instruction=put('review-instructions-v3.txt',b'Synthetic instructions.\n',True)
    a=put('review258-v7-adjudication-inputs.json',[]);d=put('review258-v7-disagreements.json',[])
    independent=put('review258-v7-independent-freeze.json',{'output_sha256':{
        'review258-v7-adjudication-inputs.json':a,'review258-v7-disagreements.json':d}})
    primary={'schema':'deepr.scratch.review258-v7.blind-freeze.v2','stage':'final_blind','assignment_key_opened':False,
        'items':24,'scheduled_cells':24,'output_sha256':{'review258-v7-final-labels.json':labels_hash},
        'resolved_rows':56,'resolved_labels':53,'packet_sha256':primary_packet,'reviewer_sha256':{'R1':r1,'R2':r2},
        'adjudication_sha256':None,'instructions_sha256':instruction,'independent_freeze_sha256':independent,
        'frozen_at':'2020-01-01T01:00:00+00:00'}
    ph=put('review258-v7-final-blind-freeze.json',primary)
    primary_key=put('packing-fixtures-v7/assignment-key-unopened/key.json',b'SYNTHETIC PRIMARY KEY',True)
    quality_key=put('material-review-v7/quality-key-unopened/key.json',b'SYNTHETIC QUALITY KEY',True)
    put('material-review-v7/primary-key-open-receipt.json',{'primary_freeze_sha256':ph,'primary_labels_frozen_before_key':True,
        'labels_sha256':labels_hash,'primary_key_sha256':primary_key,'opened_at':'2020-01-01T02:00:00+00:00','collector_protocol_sha256':protocol})
    pairs=[]
    for index in range(12):
        iid=ids[2*index]
        pair={'pair_id':f'pair{index}'} | {key:items[iid][key] for key in ('kind','question','obligations','sources')}
        for side,iid in zip(('A','B'),ids[2*index:2*index+2]):
            pair[side]=answers[iid] | {'item_id':iid,'delivered_prompt':prompt}
        pairs.append(pair)
    pair_hash=put('material-review-v7/blinded-pairs.json',pairs)
    input_freeze={'primary_freeze_sha256':ph,'packet_sha256':pair_hash,'withheld_quality_key_sha256':quality_key,'collector_protocol_sha256':protocol}
    input_hash=put('material-review-v7/input-freeze.json',input_freeze)
    snapshot_values={'packet.json':values['material-review-v7/blinded-pairs.json'],
        'primary-freeze.json':values['review258-v7-final-blind-freeze.json'],
        'input-freeze.json':values['material-review-v7/input-freeze.json'],
        'review258-v7-final-labels.json':values['review258-v7-final-labels.json'],'validator.py':b'UNTRUSTED, NEVER EXECUTED'}
    reviewers={}
    for who in ('Q1','Q2','Q3'):
        review={'reviewer':who,'review_session_id':'synthetic-session-'+who,'packet_sha256':pair_hash,
                'input_freeze_sha256':input_hash,'completed_at':'2020-01-01T04:00:00+00:00',
                'independence_attestation':{key:True for key in ('independent_session','reviewed_without_primary_method_mapping',
                    'reviewed_without_quality_method_mapping','reviewed_without_peer_judgments','all_pairs_reviewed')},
                'rows':[{'pair_id':row['pair_id']} for row in pairs]}
        raw=E(review);snapshot_values['review-'+who+'.json']=raw
        reviewers[who]={'session_id':review['review_session_id'],'sha256':H(raw)}
    for name,raw in snapshot_values.items():put('material-review-v7/quality-freeze/'+name,raw,True)
    quality={'independent_review_inputs':3,'pairs_per_reviewer':12,'key_opened_by_validator':False,
        'snapshots':{name:H(raw) for name,raw in snapshot_values.items()},'reviewers':reviewers,'primary_freeze_sha256':ph,
        'primary_labels_sha256':labels_hash,'input_freeze_sha256':input_hash,'packet_sha256':pair_hash,
        'withheld_quality_key_sha256':quality_key,'frozen_at':'2020-01-01T05:00:00+00:00','collector_protocol_sha256':protocol}
    qh=put('material-review-v7/quality-freeze/FREEZE.json',quality)
    put('material-review-v7/quality-key-open-receipt.json',{'quality_freeze_sha256':qh,'all_three_reviews_frozen_before_key':True,
        'quality_key_sha256':quality_key,'opened_at':'2020-01-01T06:00:00+00:00'})
    put('issue258-v7-semantic-assessment.json',{'synthetic':True,'semantic_acceptance':None})
    prior=put('v6-reused-brief-component.json',{'synthetic':True})
    prior_add=put('v6-reused-brief-component-addendum.json',{'original_reuse_receipt_sha256':prior})
    prior_correction=put('v6-reused-brief-provenance-correction.json',{'addendum_sha256':prior_add})
    excluded={'src/deepr/experts/consult_prompt.py','src/deepr/experts/consult_response.py'}
    put('v7-reused-brief-component.json',{'fresh_v7_cells':0,'prior_brief_cells':8,'prior_primary_slots':16,
        'prior_whole_pairs':4,'prior_whole_pair_judgments':12,'excluded_changed_consult_modules':sorted(excluded),
        'unchanged_prior_recipe_modules':{name:h for name,h in modules.items() if name not in excluded},
        'source_final_sha256':final_hash,'prior_component_sha256':prior,
        'prior_addendum_sha256':prior_add,'prior_provenance_correction_sha256':prior_correction})
    assert CORE<=set(values)
    for name,raw in values.items():
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    legacy=root/'synthetic-old-consult.py';legacy.write_bytes(old_consult)
    historical=root/'synthetic-public-index.json';historical.write_bytes(b'{"synthetic":true}\n')
    out=root/'public-output'
    config={'schema':'deepr.v7-public-archive-allowlist.v1','task_root':str(root),'public_output':str(out),
        'files':sorted(values),'metadata_sha256':{name:H(values[name]) for name in PINNED},
        'current_recipe_paths':list(modules),'extra_recipe_paths':list(extra_modules),'legacy_consult_source':str(legacy),
        'prior_v5_public_index':{'path':str(historical),'sha256':H(historical.read_bytes())},
        'prior_v6_public_index':{'path':str(historical),'sha256':H(historical.read_bytes())}}
    return config,values,out


def main():
    compile((T/'archive_v7_followup.py').read_bytes(),str(T/'archive_v7_followup.py'),'exec')
    compile((T/'prepare_archive_v7_allowlist.py').read_bytes(),str(T/'prepare_archive_v7_allowlist.py'),'exec')
    outcomes={}; key_reads=[]
    original_read=Path.read_bytes
    def watched(path):
        if path.name=='key.json':key_reads.append(str(path))
        return original_read(path)
    Path.read_bytes=watched
    try:
        with tempfile.TemporaryDirectory(prefix='archive-v7-synthetic-R1-',dir=T/'reviewers/R1') as temp:
            root=Path(temp).resolve();config,values,out=fixture(root)
            key_reads.clear()
            selected=M['preflight'](root,out,config,E(config))
            assert len(key_reads)==2 and set(values)<=set(selected)
            outcomes['complete_synthetic_capture_including_failed_draft_and_absence']='passed'
            assert len([name for name in selected if name.startswith('packing-v7-source-snapshot/')])==23
            outcomes['all20_recipe_plus3_prospective_extras_captured']='passed'
            # Cached capture is independent of subsequent file mutation.
            cached=selected['packing-fixtures-v7/answers/0000000000000002.json']
            path=root/'packing-fixtures-v7/answers/0000000000000002.json';original=path.read_bytes()
            path.write_bytes(b'changed after capture');assert selected[path.relative_to(root).as_posix()]==cached
            path.write_bytes(original);outcomes['verified_byte_capture_not_reread']='passed'
            def refused(name,change,missing=None,make_out=False):
                cfg=copy.deepcopy(config);restore={}
                if change:change(cfg,restore)
                if missing:
                    p=root/missing;restore[p]=p.read_bytes();p.unlink()
                if make_out:out.mkdir()
                key_reads.clear()
                try:
                    M['preflight'](root,out,cfg,E(cfg))
                except (ValueError,OSError,KeyError,TypeError) as error:
                    assert not key_reads,(name,key_reads)
                    outcomes[name]={'status':'refused_before_key_read','reason':str(error)}
                else:raise AssertionError('Unexpected admission: '+name)
                finally:
                    if make_out:out.rmdir()
                    for p,raw in restore.items():p.write_bytes(raw)
            def mutate(name,fn):
                def change(cfg,restore):
                    p=root/name;restore[p]=p.read_bytes();value=json.loads(restore[p]);fn(value);p.write_bytes(E(value))
                    if name in cfg['metadata_sha256']:cfg['metadata_sha256'][name]=H(p.read_bytes())
                return change
            refused('private_path_in_allowlist',lambda c,r:c['files'].append('private-S0/answer.json'))
            refused('prior_brief_bytes_cannot_be_fresh_cells',lambda c,r:c['files'].append('packing-fixtures-v5/answers/anything.json'))
            refused('credential_path_in_allowlist',lambda c,r:c['files'].append('credentials.json'))
            refused('snapshot_traversal_before_any_read',mutate('material-review-v7/quality-freeze/FREEZE.json',
                    lambda q:q['snapshots'].update({'../../quality-key-unopened/key.json':'0'*64})))
            refused('missing_quality_reviewer',mutate('material-review-v7/quality-freeze/FREEZE.json',lambda q:q['reviewers'].pop('Q3')))
            refused('missing_primary_freeze',None,missing='review258-v7-final-blind-freeze.json')
            refused('missing_quality_freeze',None,missing='material-review-v7/quality-freeze/FREEZE.json')
            refused('missing_quality_open_receipt',None,missing='material-review-v7/quality-key-open-receipt.json')
            refused('wrong_primary_56_slot_denominator',mutate('review258-v7-final-blind-freeze.json',lambda p:p.update(resolved_rows=55)))
            refused('wrong24_cell_denominator',mutate('packing-fixtures-v7/answers-complete.json',lambda p:p.update(terminal_answers=23)))
            refused('early_quality_key_open_receipt',mutate('material-review-v7/quality-key-open-receipt.json',
                    lambda q:q.update(opened_at='2020-01-01T00:00:00+00:00')))
            refused('missing_scheduled_input',None,missing='packing-fixtures-v7/0000000000000002.input.json')
            refused('changed_scheduled_answer',mutate('packing-fixtures-v7/answers/0000000000000002.json',lambda a:a.update(answer='changed')))
            refused('changed_native_ledger',mutate('v7-native-resource-audit.json',lambda r:r.update(native_ledger_sha256='0'*64)))
            refused('wrong_known_unknown_usage',mutate('v7-native-resource-audit.json',lambda r:r.update(totals={'unknown_usage_attempts':0})))
            refused('wrong5400_wall_bound',mutate('v7-collector-freeze.json',lambda r:r.update(max_wall_seconds=7200)))
            refused('reused_brief_inflates_fresh_denominator',mutate('v7-reused-brief-component.json',lambda r:r.update(fresh_v7_cells=8)))
            refused('changed_reuse_correction_chain',mutate('v7-reused-brief-component.json',lambda r:r.update(prior_addendum_sha256='0'*64)))
            refused('prospective_extra_wrong_provenance',mutate('packing-v7-prospective-extras-receipt.json',
                    lambda r:r.update(provenance='reconstructed later')))
            refused('undeclared_prospective_extra_module',lambda c,r:c.update(extra_recipe_paths=[]))
            refused('changed_source_final_identity',mutate('v7-source-final.json',lambda r:r.update(source_final=False)))
            refused('changed_consult_response_wrongly_in_brief_equality',mutate('v7-reused-brief-component.json',
                    lambda r:r.update(excluded_changed_consult_modules=['src/deepr/experts/consult_prompt.py'])))
            refused('prior_v6_ledger_not_preserved',mutate('v7-native-resource-audit.json',lambda r:r.update(v6_24_attempt_ledger_unchanged=False)))
            refused('missing_canonical_assessment',None,missing='issue258-v7-semantic-assessment.json')
            refused('prior_v6_answer_bytes_not_fresh',lambda c,r:c['files'].append('packing-fixtures-v6/answers/anything.json'))
            recipe_name=next(name for name in values if name.startswith('packing-v7-source-snapshot/'))
            def break_source(cfg,restore):
                p=root/recipe_name;restore[p]=p.read_bytes();p.write_bytes(b'changed recipe')
            refused('changed_captured_source_module',break_source)
            refused('missing19th_corpus_source',lambda c,r:c['files'].remove(next(name for name in c['files'] if name.startswith('packing-fixtures-v7/corpus/sources/'))))
            refused('existing_archive_untouched',None,make_out=True)
            refused('wrong_output_root',lambda c,r:c.update(public_output=str(root/'different-output')))
            symlink=root/'packing-fixtures-v7/0000000000000002.input.json';saved=symlink.read_bytes();symlink.unlink()
            target=root/'synthetic-linked-file';target.write_bytes(saved);symlink.symlink_to(target)
            refused('symlink_input_refused',None)
            symlink.unlink();symlink.write_bytes(saved)
            # Only tiny synthetic data is compressed/published, never the real inventory.
            small_out=root/'small-publication';small_out.mkdir();small_out.rmdir()
            M['publish'](small_out,{'synthetic/data.txt':b'full synthetic bytes'})
            assert (small_out/'COMPLETE.json').is_file() and all(p.stat().st_size<500*1024 for p in small_out.iterdir())
            outcomes['durable_small_synthetic_publication']='passed'
            oversized=root/'oversized-publication'
            try:M['publish'](oversized,{'synthetic/random.bin':os.urandom(520*1024)})
            except ValueError:assert not oversized.exists();outcomes['oversized_source_refused_without_drop']='passed'
            else:raise AssertionError('Oversized source admitted')
            prepare=runpy.run_path(str(T/'prepare_archive_v7_allowlist.py'),run_name='synthetic_missing_freeze_check')
            empty=root/'missing-freeze-preparation';empty.mkdir();key_reads.clear()
            try:prepare['build'](empty,'0'*64,'0'*64,'0'*64,empty/'out')
            except ValueError:
                assert not key_reads;outcomes['config_recipe_refuses_missing_freezes_without_reads']='passed'
            else:raise AssertionError('Config prepared before freezes')
    finally:Path.read_bytes=original_read
    report={'checks':outcomes,'actual_export_run':False,'real_keys_read':False,'real_answers_read':False,
            'real_judgments_read':False,'model_calls':0,'builder_sha256':H((T/'archive_v7_followup.py').read_bytes())}
    destination=T/'reviewers/R1/archive-v7-synthetic-checks.json'
    with destination.open('x') as f:json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    print(json.dumps({'report':str(destination),'checks':len(outcomes),'actual_export_run':False}))


if __name__=='__main__':main()
