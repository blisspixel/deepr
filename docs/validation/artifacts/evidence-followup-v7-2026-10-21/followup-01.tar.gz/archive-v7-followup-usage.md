# V7 offline resource and archive helpers

Preparation only. No native/model/provider calls, actual resource audit, real
archive config or export was run. Product files and documentation were not
edited by this preparation.

After root explicitly reports collection complete and answers-complete.json
exists with all 24 terminal cells, the offline accounting invocation is:

```text
python .agent/issue-completion-2026-10-20/audit_native_resources_v7.py --collection-complete
```

That flag records the operator's completion attestation; it is not dispatch
permission. The helper refuses changed protocol/authority/collector/input
bindings and joins reservations, lifecycle events, returned transports, complete
drafts and known/unknown token components. It verifies the immutable original
100, V5 32 and V6 24 attempt ledgers separately. Full V7 means 24 fresh consult
attempts and 180 total attempts across the four separate bounds. Unknown usage
is not zero. Direct local API price is zero; hardware and review service costs
remain unknown. The function audit(root) is pure; main writes its receipt once.

Do not prepare the real archive config until all 24 completions, final primary
freeze/labels, all three quality reviews/freeze, legitimate primary and quality
first-open receipts and root's canonical issue258-v7-semantic-assessment.json
exist. R3 confirmed these interfaces. No unused reviewed-comparison summary is
required or fabricated.

Before preparing, independently verify the reviewed archive helper and both
completed published predecessor indices. Supply their literal SHA256 values:

```text
python .agent/issue-completion-2026-10-20/prepare_archive_v7_allowlist.py \
  --helper-sha256 REVIEWED_ARCHIVE_V7_HELPER_SHA256 \
  --prior-v5-index-sha256 VERIFIED_PUBLISHED_V5_INDEX_SHA256 \
  --prior-v6-index-sha256 VERIFIED_PUBLISHED_V6_INDEX_SHA256
```

This exclusively creates archive-v7-allowlist.json from safe metadata and known
filenames, without reading key bytes, answer drafts or peer-judgment rows.
Review the exact inventory and config SHA before the separate export:

```text
python .agent/issue-completion-2026-10-20/archive_v7_followup.py \
  --config-sha256 REVIEWED_ARCHIVE_V7_CONFIG_SHA256
```

Only docs/validation/artifacts/evidence-followup-v7-2026-10-21 is permitted for
the real output. Existing or interrupted publications refuse and remain intact.
The archive retains 24 fresh consult cells, 56 primary slots, 12 matched pairs,
36 whole-pair judgments and 19 corpus source texts. All 20 owning recipe modules
and three extra dependencies were captured prospectively in
packing-v7-source-snapshot. The helper recomputes the owning ordered recipe
algorithm and keeps the three extras separate from that fingerprint. Snapshot
receipt hash and owning recipe hash are distinct. Source finality and capture
chronology must precede fixture, protocol and collection.

The V5 eight briefs remain unchanged separate component evidence. Both changed
consult_prompt.py and consult_response.py are excluded from their dependency
reuse equality. Prior component receipts and V5/V6 archive indices are bound as
references; prior answer/call/assembly directories cannot become fresh V7 cells.
All prior adverse findings remain material. The archive does not infer a policy
winner, semantic acceptance, release readiness or general expertise.

Keys are the archive helper's final reads, after all complete freezes, historic
first-open chronology, binding checks and prior references pass. Byte strings
are captured once, hashed and archived without rereading or clipping. Archived
code/text is untrusted evidence and never executed. Every part, index and final
fsynced COMPLETE.json remains strictly below 500 KiB. Independently rehash every
archive member, manifests, index and COMPLETE after a real export and verify
original/V5/V6 archives remained unchanged.

Synthetic checks are isolated temporary fixtures: 36 archive guard checks,
14 resource checks and four positive inventory checks. Two initial synthetic
fixture expectation/setup failures are retained separately; their repairs did
not weaken guards. No real answer, key or peer-verdict bytes were opened during
preparation. Existing V6 helpers, config and archives remain unchanged.
