"""Offline resource joins for the24-cell V7 consult trial; never dispatches."""

from collections import Counter, defaultdict
from datetime import UTC, datetime
import hashlib
import json
import math
from pathlib import Path

T = Path(__file__).resolve().parent
D = T / "packing-fixtures-v7"
F = T / "v7-runtime"

PRIOR_LEDGER_EXPECTED = {'runtime/costs/cost_ledger.jsonl': '2af1a9c4344e1c9576c200ee3c7b7c687e0905008efe8b2eec9b2b4c9c97dec1', 'followup-runtime/costs/cost_ledger.jsonl': 'd2291d3c0cd0338b23ebed46a10f2b22161cdc4e1d7f0c704b1ba4909634f658', 'v6-runtime/costs/cost_ledger.jsonl': '8f076a133930ded4ab9dd1fcd776e55e55a991515dd77db00110bea8ac8317b6'}
PRIOR_ATTEMPTS = {"runtime/costs/cost_ledger.jsonl": 100, "followup-runtime/costs/cost_ledger.jsonl": 32, "v6-runtime/costs/cost_ledger.jsonl": 24}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def audit(root):
    T = Path(root).resolve()
    D = T / "packing-fixtures-v7"
    F = T / "v7-runtime"
    complete = read(D / "answers-complete.json")
    manifest = read(D / "manifest.json")
    freeze = read(T / "v7-collector-freeze.json")
    authorization = read(T / "v7-operator-authorization.json")
    protocol = read(T / "v7-review-protocol.json")
    require(protocol["paid_provider_api_ceiling_usd"] == authorization["paid_provider_api_ceiling_usd"] == freeze["paid_provider_api_ceiling_usd"] == 0, "Zero-paid-provider authority differs")
    require(protocol["automatic_retry"] is False and protocol["local_generation_ceiling"] == 24
            and protocol["wall_ceiling_seconds"] == 5400, "V7 protocol bounds differ")
    require(manifest["generator"] == protocol["generator"], "Protocol generator differs")
    require(complete["manifest_sha256"] == freeze["manifest_sha256"] == digest(D / "manifest.json"), "Manifest mismatch")
    require(authorization["authorized"] is True and authorization["paid_provider_api_ceiling_usd"] == 0, "Authority mismatch")
    require(freeze["authorization_sha256"] == digest(T / "v7-operator-authorization.json"), "Authority bytes changed")
    require(freeze["protocol_sha256"] == authorization["protocol_sha256"] == digest(T / "v7-review-protocol.json"),
            "Protocol commitment changed")
    require(freeze["runner_sha256"] == authorization["runner_sha256"] == digest(T / "answer_runner_v7.py"), "Collector changed")
    require(complete["terminal_answers"] == complete["answers_scheduled"] == len(manifest["jobs"]) == 24, "Incomplete cells")
    ids = {row["item_id"] for row in manifest["jobs"]}
    frozen_jobs = {row["item_id"]: row for row in manifest["jobs"]}
    require(len(ids) == len(complete["results"]) == len({row["item_id"] for row in complete["results"]}) == 24,
            "Missing or duplicate completion rows")
    require(ids == {row["item_id"] for row in complete["results"]}, "Terminal identities mismatch")
    requests = sorted((F / "calls").glob("*.request.json"))
    require(len(requests) <= freeze["max_calls"] == authorization["local_generation_ceiling"] == 24, "Attempt ceiling exceeded")
    require([int(path.name.split(".")[0]) for path in requests] == list(range(1, len(requests) + 1)), "Reservation gap")
    require(len({read(path)["item_id"] for path in requests}) == len(requests), "Duplicate reservation item")
    ledger = F / "costs/cost_ledger.jsonl"
    events = [json.loads(line) for line in ledger.read_bytes().splitlines()]
    groups = defaultdict(list)
    for event in events:
        require(event["provider"] == "local" and event["source"] == "local.native_ollama" and event["cost_usd"] == 0,
                "Unexpected provider or nonzero cost")
        require(event["metadata"]["schema"] == "native-local-attempt-v1" and event["metadata"]["kind"] == "chat",
                "Unexpected ledger schema")
        groups[event["request_id"]].append(event)
    require(len({event["idempotency_key"] for event in events}) == len(events), "Duplicate lifecycle events")
    require(len({event["metadata"]["attempt_id"] for event in events}) == len(groups), "Correlation reused across attempts")
    expected_correlations = {f"issue-completion:answer258v7:{read(path)['item_id']}" for path in requests}
    require(set(groups) <= expected_correlations, "Unreserved native attempts")
    issues = []
    totals = Counter()
    terminal_states = Counter()
    rows = []
    start = datetime.fromisoformat(freeze["started_at"])
    for path in requests:
        request = read(path)
        iid = request["item_id"]
        require(iid in ids, "Unknown reservation")
        require(request["phase"] == "answer258v7", "Wrong reservation phase")
        source_path = D / (iid + ".input.json")
        require(digest(source_path) == frozen_jobs[iid]["input_sha256"], "Frozen input bytes changed")
        source = read(source_path)
        require(source["item_id"] == iid and source["kind"] == "consult", "Frozen consult identity differs")
        require(request["seed"] == source["seed"] and request["user"] == source["prompt"] and request["max_tokens"] == source["output_tokens"],
                "Reservation differs from frozen generation input")
        require(request["generator"] == manifest["generator"] and request["manifest_sha256"] == digest(D / "manifest.json"),
                "Reservation generator/manifest differs")
        requested_at = datetime.fromisoformat(request["created_at"])
        require(0 <= (requested_at - start).total_seconds() <= 5400, "Reservation outside admitted wall window")
        response_path = path.with_name(path.name.replace(".request.json", ".response.json"))
        response = read(response_path)
        require(response["item_id"] == iid and response.get("request_sha256") == digest(path), "Response reservation mismatch")
        saved_path = D / "answers" / f"{iid}.json"
        require(response == read(saved_path), "Call and answer receipts diverge")
        correlation = f"issue-completion:answer258v7:{iid}"
        lifecycle = groups.get(correlation, [])
        terminals = [event for event in lifecycle if event["operation"] == "native_local_terminal"]
        requested = [event for event in lifecycle if event["operation"] == "native_local_requested"]
        dispatches = [event for event in lifecycle if event["operation"] == "native_local_dispatching"]
        if len(terminals) != 1 or len(requested) != 1:
            issues.append({"item_id": iid, "issue": "missing_or_duplicate_canonical_lifecycle", "events": len(lifecycle)})
        require(len(dispatches) <= 1, "Repeated native dispatch")
        require(len({event["metadata"]["attempt_id"] for event in lifecycle}) <= 1, "Attempt identity changed")
        require(all(event["model"] == manifest["generator"]["model"] for event in lifecycle), "Ledger model changed")
        if lifecycle:
            phases = [event["operation"] for event in lifecycle]
            expected_phases = ["native_local_requested"] + (["native_local_dispatching"] if dispatches else []) + (["native_local_terminal"] if terminals else [])
            require(phases == expected_phases, "Native lifecycle phases/order differ")
            times = [datetime.fromisoformat(event["timestamp"]) for event in lifecycle]
            require(times == sorted(times) and times[0] >= requested_at, "Native lifecycle timestamp order differs")
            if requested:
                require(requested[0]["metadata"]["status"] == "requested", "Requested status mismatch")
            if terminals:
                terminal_state = terminals[0]["metadata"]["status"]
                require(terminal_state in {"returned", "failed", "cancelled", "refused"}, "Unknown terminal state")
                require(terminal_state != "returned" or len(dispatches) == 1, "Returned native attempt without dispatch")
                require(terminal_state != "refused" or not dispatches, "Refused native attempt after dispatch")
                require(terminal_state != "failed" or len(dispatches) == 1, "Failed native attempt without dispatch")
        for event in dispatches:
            require(event["metadata"]["model_digest"] == manifest["generator"]["digest"], "Dispatched model changed")
            require(event["metadata"]["status"] == "dispatching", "Dispatch status mismatch")
        ti, to = response.get("tokens_input"), response.get("tokens_output")
        input_known = type(ti) is int and ti >= 0
        output_known = type(to) is int and to >= 0
        usage_known = input_known and output_known
        if input_known:
            totals.update(input_tokens=ti, known_input_attempts=1)
        if output_known:
            totals.update(output_tokens=to, known_output_attempts=1)
        if usage_known:
            totals["known_usage_attempts"] += 1
        else:
            totals["unknown_usage_attempts"] += 1
        if len(terminals) == 1:
            require(not input_known or terminals[0]["tokens_input"] == ti, "Known input usage join mismatch")
            require(not output_known or terminals[0]["tokens_output"] == to, "Known output usage join mismatch")
        if terminals:
            terminal_states.update(event["metadata"]["status"] for event in terminals)
        transport = path.with_name(path.name.replace(".request.json", ".transport.json"))
        if transport.exists():
            raw = read(transport)
            require(raw["request_sha256"] == digest(path), "Transport/request mismatch")
            data = raw["raw_response"]
            require(isinstance(data, dict), "Unexpected transport response shape")
            if isinstance(data.get("message"), dict):
                returned_text = str(data["message"].get("content", "") or "")
                require(response.get("answer") == returned_text and response.get("answer_sha256") == hashlib.sha256(returned_text.encode("utf-8")).hexdigest(),
                        "Returned transport text lost or changed")
            if "transport_response_sha256" in response:
                require(response["transport_response_sha256"] == digest(transport), "Failed draft transport commitment differs")
            native = path.with_name(path.name.replace(".request.json", ".native.json"))
            if "native_response_sha256" in response:
                require(native.is_file() and response["native_response_sha256"] == digest(native), "Native result commitment differs")
                require(read(native)["raw_response"] == data, "Backend and transport native responses differ")
            if type(data.get("prompt_eval_count")) is int and data["prompt_eval_count"] >= 0:
                require(input_known and ti == data["prompt_eval_count"], "Known transport input usage lost")
            if type(data.get("eval_count")) is int and data["eval_count"] >= 0:
                require(output_known and to == data["eval_count"], "Known transport output usage lost")
            require(len(dispatches) == 1, "Returned transport without dispatch")
            totals["transport_returned_attempts"] += 1
        elif terminals and terminals[0]["metadata"]["status"] == "returned":
            issues.append({"item_id": iid, "issue": "returned_terminal_without_retained_transport"})
        rows.append({"item_id": iid, "correlation_id": correlation, "status": response["status"],
                     "request_sha256": digest(path), "response_sha256": digest(response_path),
                     "answer_receipt_sha256": digest(saved_path), "canonical_events": len(lifecycle),
                     "usage_known": usage_known, "transport_sha256": digest(transport) if transport.exists() else None})
    statuses = Counter()
    reservation_ids = {read(path)["item_id"] for path in requests}
    for row in complete["results"]:
        path = D / "answers" / (row["item_id"] + ".json")
        require(digest(path) == row["file_sha256"], "Completion/answer mismatch")
        answer = read(path)
        require(answer["item_id"] == row["item_id"] and answer["status"] == row["status"], "Scheduled answer identity/status differs")
        require(answer["status"] in {"completed", "truncated", "empty_answer", "form_failed", "malformed_brief", "failed", "cancelled",
                                     "refused_followup_bound", "refused_followup_integrity"}, "Unknown or nonterminal answer status")
        statuses[answer["status"]] += 1
        is_refusal = answer["status"] in {"refused_followup_bound", "refused_followup_integrity"}
        require((row["item_id"] not in reservation_ids) == is_refusal, "Scheduled cell reservation coverage differs")
        if answer["status"] in {"completed", "truncated", "empty_answer", "form_failed", "malformed_brief"}:
            lifecycle = groups.get(f"issue-completion:answer258v7:{row['item_id']}", [])
            require(sum(event["operation"] == "native_local_terminal" and event["metadata"]["status"] == "returned" for event in lifecycle) == 1,
                    "Returned-answer cell lacks its canonical returned attempt")
    last = max(datetime.fromisoformat(event["timestamp"]) for event in events) if events else start
    wall = (last - start).total_seconds()
    require(freeze["max_wall_seconds"] == authorization["wall_ceiling_seconds"] == 5400, "Wall authority mismatch")
    require(type(complete["wall_seconds"]) in (int, float) and math.isfinite(complete["wall_seconds"]) and complete["wall_seconds"] >= 0,
            "Invalid collector wall observation")
    if wall < 0 or wall > 5400 or complete["wall_seconds"] > 5400:
        issues.append({"issue": "last_canonical_receipt_after_wall_ceiling", "wall_seconds": wall})
    require(protocol["prior_ledgers"] == PRIOR_LEDGER_EXPECTED, "Exact three prior ledger identities differ")
    prior_counts = {}
    for relative, expected in PRIOR_LEDGER_EXPECTED.items():
        require(digest(T / relative) == expected, "Prior ledger changed: " + relative)
        prior_events = [json.loads(line) for line in (T / relative).read_bytes().splitlines()]
        prior_counts[relative] = len({event["request_id"] for event in prior_events})
        require(prior_counts[relative] == PRIOR_ATTEMPTS[relative], "Prior native attempt count differs")
    require(protocol["original_ledger_sha256"] == PRIOR_LEDGER_EXPECTED["runtime/costs/cost_ledger.jsonl"]
            and protocol["v5_ledger_sha256"] == PRIOR_LEDGER_EXPECTED["followup-runtime/costs/cost_ledger.jsonl"],
            "Prior compatibility ledger identities differ")
    require(sum(prior_counts.values()) == protocol["prior_native_attempts"] == freeze["prior_native_attempts"] == 156
            and protocol["total_native_attempts_if_v7_full"] == freeze["native_attempts_if_full"] == 180,
            "Prospective native denominator differs")
    require(digest(T / "packing-v7-source-snapshot-receipt.json") == protocol["source_snapshot_receipt_sha256"],
            "Prospective recipe snapshot receipt changed")
    require(digest(T / "packing-v7-prospective-extras-receipt.json") == protocol["prospective_extras_receipt_sha256"],
            "Prospective extra dependency receipt changed")
    report = {"observed_at": datetime.now(UTC).isoformat(), "trial": "V7", "phase": "answer258v7", "scheduled_cells": 24, "terminal_cells": 24,
              "reserved_attempts": len(requests), "native_ledger_attempts": len(groups), "native_ledger_events": len(events),
              "max_attempts": 24, "max_wall_seconds": 5400, "last_native_receipt_wall_seconds": round(wall, 3),
              "collector_wall_seconds": complete["wall_seconds"], "statuses": dict(statuses), "totals": dict(totals),
              "canonical_terminal_states": dict(terminal_states), "native_ledger_sha256": digest(ledger),
              "manifest_sha256": digest(D / "manifest.json"), "protocol_sha256": freeze["protocol_sha256"],
              "runner_sha256": freeze["runner_sha256"], "original_100_attempt_ledger_unchanged": True,
              "v5_32_attempt_ledger_unchanged": True, "prior_v5_ledger_sha256": protocol["v5_ledger_sha256"],
              "v6_24_attempt_ledger_unchanged": True,
              "prior_v6_ledger_sha256": PRIOR_LEDGER_EXPECTED["v6-runtime/costs/cost_ledger.jsonl"],
              "prior_ledgers_sha256": dict(PRIOR_LEDGER_EXPECTED), "prior_native_attempts": 156,
              "total_native_attempts": 156 + len(groups), "total_native_attempts_if_full": 180,
              "source_recipe_sha256": protocol["source_recipe_sha256"],
              "source_snapshot_receipt_sha256": protocol["source_snapshot_receipt_sha256"],
              "prospective_extras_receipt_sha256": protocol["prospective_extras_receipt_sha256"],
              "direct_paid_provider_api_calls": 0, "local_direct_provider_cost_usd": 0,
              "review_service_usage_and_cost": None, "hardware_energy_cost_usd": None,
              "accounting_complete": not issues, "usage_complete": totals["unknown_usage_attempts"] == 0,
              "issues": issues, "attempt_joins": rows,
              "limits": "Correlation joins distinguish reservations, native attempts and returned transports. Each known token component is summed separately; unknown components are not zero. Zero-price native accounting does not price hardware or the independent review service. Wall observations are not controlled latency rankings; async cancellation does not prove daemon-side termination or bound synchronous cleanup."}
    return report


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection-complete', action='store_true', required=True,
                        help='Operator attestation: collection is complete and root requested this offline audit.')
    parser.parse_args()
    report = audit(T)
    out = T / "v7-native-resource-audit.json"
    with out.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)
        handle.write("\n")
    print(json.dumps({key: value for key, value in report.items() if key != "attempt_joins"}, indent=2))


if __name__ == "__main__":
    main()
