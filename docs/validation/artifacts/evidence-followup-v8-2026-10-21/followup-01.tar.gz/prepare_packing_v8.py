"""V8 source/protocol freeze helper; never declares root source final itself.

Root must first create v8-source-final.json with source_final:true,
confirmed_by:/root, its explicit instruction, and SHA256 source_modules for
exactly v8_guards.MODULE_PATHS. This helper is not permission or generation.
After explicit root source-final: run source-snapshot, recipe-proof, gated
builder and separate brief-reuse generator, then protocol. Audit inputs and
independent admission follow; this helper never dispatches.
Independent admission and a separately bound operator authorization are still
required before the runner can dispatch. No snapshots are frozen on import.
"""
import argparse
from pathlib import Path
from v8_guards import (
    EXTRA_MODULE_PATHS, PRIOR_LEDGER_HASHES, REVIEW_CONTROL_HASHES, PRIOR_NEGATIVE_HASHES, PRIOR_V7_PROTOCOL_SHA256, validate_prior_negative_assessments, digest, read, require, require_source_final, require_prospective_extras, utc_now,
    validate_manifest, validate_modules, validate_recipe, validate_protocol, write_exclusive,
)

TOOLS = ('packing_fixtures_v8.py', 'answer_runner_v8.py', 'v8_guards.py',
         'prepare_packing_v8.py', 'prepare_brief_reuse_v8.py')


def freeze_source(root, task):
    root, task = Path(root), Path(task)
    final = require_source_final(root, task)
    validate_prior_negative_assessments(task)
    require(digest(task/'v7-review-protocol.json') == PRIOR_V7_PROTOCOL_SHA256, 'Prior V7 protocol anchor changed')
    destination = task / 'packing-v8-source-snapshot'
    destination.mkdir(exist_ok=False)
    for relative, expected_hash in final['source_modules'].items():
        source = root / relative
        payload = source.read_bytes()
        import hashlib
        require(hashlib.sha256(payload).hexdigest() == expected_hash, 'Source changed during snapshot')
        output = destination / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open('xb') as handle:
            handle.write(payload)
    validate_modules(root, final['source_modules'])
    validate_modules(destination, final['source_modules'])
    extras = {path: digest(root/path) for path in EXTRA_MODULE_PATHS}
    for relative, expected_hash in extras.items():
        output = destination / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open('xb') as handle:
            handle.write((root/relative).read_bytes())
        require(digest(output) == expected_hash == digest(root/relative), 'Extra source changed during snapshot')
    write_exclusive(task / 'packing-v8-prospective-extras-receipt.json', {
        'frozen_at': utc_now(), 'source_final_sha256': digest(task/'v8-source-final.json'),
        'extra_source_modules': extras, 'source_snapshot': destination.name,
        'provenance': 'prospectively captured before V8 fixture build and collection',
        'identity_limit': 'Additional owned dependencies only; not whole runtime or daemon.'})
    receipt = {'frozen_at': utc_now(), 'source_final_sha256': digest(task / 'v8-source-final.json'),
               'source_snapshot': destination.name, 'source_modules': final['source_modules'],
               'identity_limit': '20 recipe modules only; not whole runtime or daemon.'}
    write_exclusive(task / 'packing-v8-source-snapshot-receipt.json', receipt)
    return receipt


def freeze_recipe_proof(root, task):
    root, task = Path(root), Path(task)
    final = require_source_final(root, task)
    validate_prior_negative_assessments(task)
    require(digest(task/'v7-review-protocol.json') == PRIOR_V7_PROTOCOL_SHA256, 'Prior V7 protocol anchor changed')
    snapshot = read(task / 'packing-v8-source-snapshot-receipt.json')
    require(snapshot['source_modules'] == final['source_modules'], 'Snapshot recipe modules differ')
    validate_recipe(task / 'packing-v8-source-snapshot', final['source_recipe_sha256'])
    receipt = {
        'frozen_at': utc_now(), 'source_recipe_sha256': final['source_recipe_sha256'],
        'source_final_sha256': digest(task/'v8-source-final.json'),
        'source_snapshot_receipt_sha256': digest(task/'packing-v8-source-snapshot-receipt.json'),
        'algorithm': 'MODULE_PATHS order; UTF-8 path with src/ prefix removed, then raw module bytes, no delimiter; SHA256 of the concatenation.',
        'owning_algorithm': 'src/deepr/evals/correction_survival.py:recipe_sha256',
        'live_and_snapshot_recomputed': True,
        'identity_limit': 'Owning 20-module recipe identity; extra dependency hashes remain separate.',
    }
    write_exclusive(task/'packing-v8-source-recipe-proof.json', receipt)
    return receipt


def freeze_protocol(root, task):
    root, task = Path(root), Path(task)
    final = require_source_final(root, task)
    validate_prior_negative_assessments(task)
    require(digest(task/'v7-review-protocol.json') == PRIOR_V7_PROTOCOL_SHA256, 'Prior V7 protocol anchor changed')
    proposed = read(task / 'v8-review-protocol-proposed.json')
    snapshot = read(task / 'packing-v8-source-snapshot-receipt.json')
    require(snapshot['source_modules'] == final['source_modules'], 'Snapshot source recipe differs')
    require(snapshot['source_final_sha256'] == digest(task / 'v8-source-final.json'), 'Snapshot finality differs')
    validate_modules(task / 'packing-v8-source-snapshot', final['source_modules'])
    validate_recipe(root, final['source_recipe_sha256'])
    validate_recipe(task / 'packing-v8-source-snapshot', final['source_recipe_sha256'])
    extras = require_prospective_extras(root, task)
    from v8_guards import validate_extras
    validate_extras(task / 'packing-v8-source-snapshot', extras['extra_source_modules'])
    manifest_path = task / 'packing-fixtures-v8/manifest.json'
    manifest = read(manifest_path)
    validate_manifest(manifest)
    require(manifest['extra_source_modules'] == extras['extra_source_modules'], 'Builder extra source recipe differs')
    require(manifest['source_modules'] == final['source_modules'], 'Builder source recipe differs')
    require(manifest['source_final_sha256'] == digest(task / 'v8-source-final.json'), 'Builder finality differs')
    require(manifest['common_form_adapter_sha256'] == final['source_modules']['src/deepr/experts/consult_response.py'], 'Shared new form adapter differs')
    protocol = dict(proposed)
    protocol.update(extra_source_modules=extras['extra_source_modules'],
                    prospective_extras_receipt_sha256=digest(task/'packing-v8-prospective-extras-receipt.json'),
                    status='frozen', frozen_at=utc_now(), source_modules=final['source_modules'],
                    source_final_sha256=digest(task / 'v8-source-final.json'),
                    source_recipe_sha256=final['source_recipe_sha256'],
                    source_snapshot_receipt_sha256=digest(task / 'packing-v8-source-snapshot-receipt.json'),
                    source_recipe_proof_sha256=digest(task / 'packing-v8-source-recipe-proof.json'),
                    fixture_builder_sha256=digest(task / 'packing_fixtures_v8.py'),
                    manifest_sha256=digest(manifest_path),
                    tool_modules={path: digest(task/path) for path in TOOLS},
                    prior_ledgers=dict(PRIOR_LEDGER_HASHES))
    for relative, expected_hash in PRIOR_LEDGER_HASHES.items():
        require(digest(task/relative) == expected_hash, 'Prior ledger changed: ' + relative)
    for relative, expected_hash in REVIEW_CONTROL_HASHES.items():
        require(digest(task/relative) == expected_hash, 'Review control changed: ' + relative)
    require(protocol['fixture_builder_sha256'] == manifest['fixture_builder_sha256'], 'Builder bytes changed')
    require(digest(task / 'review-instructions-v3.txt') == protocol['primary_rubric_sha256'], 'Rubric bytes changed')
    validate_protocol(protocol)
    write_exclusive(task / 'v8-review-protocol.json', protocol)
    return protocol


def prepare_audit_inputs(root, task):
    root, task = Path(root), Path(task)
    protocol_path = task / 'v8-review-protocol.json'
    protocol = read(protocol_path)
    validate_protocol(protocol)
    validate_modules(root, protocol['source_modules'])
    extras = require_prospective_extras(root, task)
    brief_path = task / 'v8-reused-brief-component.json'
    brief = read(brief_path)
    require(brief['fresh_v8_cells'] == 0 and brief['prior_brief_cells'] == 8, 'Prior brief separation required')
    output = {
        'prepared_at': utc_now(), 'status': 'requires_independent_precollection_audit',
        'source_final_sha256': digest(task/'v8-source-final.json'),
        'protocol_sha256': digest(protocol_path),
        'runner_sha256': digest(task/'answer_runner_v8.py'),
        'fixture_builder_sha256': digest(task/'packing_fixtures_v8.py'),
        'manifest_sha256': digest(task/'packing-fixtures-v8/manifest.json'),
        'source_snapshot_receipt_sha256': digest(task/'packing-v8-source-snapshot-receipt.json'),
        'prospective_extras_receipt_sha256': digest(task/'packing-v8-prospective-extras-receipt.json'),
        'brief_component_sha256': digest(brief_path),
        'source_modules': protocol['source_modules'],
        'extra_source_modules': extras['extra_source_modules'],
        'tool_modules': protocol['tool_modules'], 'review_controls': protocol['review_controls'],
        'prior_ledgers': protocol['prior_ledgers'],
        'prior_negative_assessments_sha256': protocol['prior_negative_assessments_sha256'],
        'checks_requested': [
            'Exact 24 consult cells / 56 obligations, six order families / 12 seeded pairs.',
            'Pinned model digest, seeds, worlds, questions, obligations and unchanged review controls.',
            'Both methods share the new shorter half-target form adapter and unchanged hard maximum; current routing, packing and generic guidance remain identical to V7.',
            'Prospective 20-module snapshot plus three separately identified captured dependencies.',
            'Per-call and transport-boundary source, reservation and deadline guards; 24 calls / 5400 seconds / no retries / zero direct paid API ceiling.',
            'All 180 previous attempts and four ledgers frozen; full V8 would bring native total to 204.',
            'Exact prior V5 eight brief cells remain separate component evidence, both changed consult modules excluded from equality, all adverse findings retained.',
            'No answer dispatch or policy acceptance yet; all return/form failures remain in future denominators.',
        ],
    }
    write_exclusive(task/'packing-v8-precollection-audit-inputs.json', output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('source-snapshot', 'recipe-proof', 'protocol', 'audit-inputs'))
    parser.add_argument('--root', type=Path, default=Path('/home/pueo/Work/deepr'))
    parser.add_argument('--task', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    actions = {'source-snapshot':freeze_source, 'recipe-proof':freeze_recipe_proof, 'protocol':freeze_protocol, 'audit-inputs':prepare_audit_inputs}
    result = actions[args.action](args.root, args.task)
    print(result.get('frozen_at', result.get('prepared_at')))


if __name__ == '__main__':
    main()
