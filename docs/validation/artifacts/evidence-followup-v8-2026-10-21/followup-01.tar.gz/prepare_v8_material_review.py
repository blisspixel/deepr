"""Reconstruct actual producers after primary freeze, then hide pair methods anew.

This offline helper opens the V8 primary key only after validating all primary
freeze bindings. It does not open the separate quality key or accept a policy.
Root preparation is method-aware and is never represented as blinded review.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import secrets
import sys
from collections import defaultdict
from dataclasses import asdict
from datetime import UTC, date, datetime
from pathlib import Path

T = Path(__file__).resolve().parent
R = T.parents[1]
D = T / "packing-fixtures-v8"
OUT = T / "material-review-v8"


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n").encode("utf-8")
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return sha(raw)


def preflight():
    # This is deliberately the first data read. No key is read on an incomplete trial.
    primary_path = T / "review258-v8-final-blind-freeze.json"
    primary = read(primary_path)
    labels = T / "review258-v8-final-labels.json"
    require(primary["schema"] == "deepr.scratch.review258-v8.blind-freeze.v2"
            and primary["key_access_implemented"] is False
            and primary["stage"] == "final_blind" and primary["assignment_key_opened"] is False,
            "Complete pre-key primary freeze required")
    require(primary["output_sha256"][labels.name] == sha(labels.read_bytes()), "Primary labels changed")
    require(primary["helper_sha256"] == sha((T / "review258_v8_primary.py").read_bytes()), "Primary helper changed")
    packet_path = D / "blinded-review.json"
    packet = read(packet_path)
    require(primary["packet_sha256"] == sha(packet_path.read_bytes()), "Primary packet changed")
    require(primary["resolved_rows"] == sum(len(item["obligations"]) for item in packet), "Incomplete primary rows")
    require(primary["items"] == len(packet) == 24, "All 24 scheduled cells required")
    helper_spec = importlib.util.spec_from_file_location("v8_primary_binding_validator", T / "review258_v8_primary.py")
    helper = importlib.util.module_from_spec(helper_spec)
    helper_spec.loader.exec_module(helper)
    _, slots, bindings, packet_hash, instruction_hash, reviews, review_hashes, differences = helper.primary_inputs(T)
    require(primary["collection_bindings"] == helper.collection_bindings(T, packet),
            "Primary frozen collection bindings changed")
    require(primary["declared_reviewer_tasks"] == helper.REVIEWER_TASKS, "Primary reviewer task identities changed")
    require(primary["bindings"] == bindings, "Primary per-cell bindings differ from packet")
    require(primary["packet_sha256"] == packet_hash and primary["instructions_sha256"] == instruction_hash,
            "Primary input/instruction binding changed")
    require(primary["reviewer_sha256"] == review_hashes, "Frozen primary reviewer bytes changed")
    label_rows = read(labels)
    require(len(label_rows) == len(slots), "Final labels incomplete")
    label_slots = {(row["item_id"], row["obligation_id"]): row for row in label_rows}
    require(len(label_slots) == len(label_rows) and set(label_slots) == set(slots), "Final label slots differ")
    for slot, row in label_slots.items():
        item = slots[slot][0]
        require(row["answer_sha256"] == item.get("answer_sha256") and row["terminal_status"] == item["status"],
                "Final label answer/status mismatch")
        require(row["independent_reviews"] == {who: reviews[who][slot] for who in reviews}, "Final primary rows changed")
        require(row["label"] in helper.LABELS if isinstance(item.get("answer"), str) else row["label"] is None,
                "Final semantic/absence label mismatch")
    completion = read(D / "answers-complete.json")
    manifest = read(D / "manifest.json")
    require(completion["manifest_sha256"] == sha((D / "manifest.json").read_bytes()), "Manifest changed")
    collector = read(T / "v8-collector-freeze.json")
    require(collector["manifest_sha256"] == completion["manifest_sha256"], "Collector manifest differs")
    protocol_path = T / "v8-review-protocol.json"
    protocol_hash = sha(protocol_path.read_bytes())
    require(collector["protocol_sha256"] == protocol_hash, "Collector protocol binding changed")
    protocol = read(protocol_path)
    require(protocol["manifest_sha256"] == completion["manifest_sha256"], "Protocol manifest differs")
    from v8_guards import validate_protocol, validate_manifest, validate_modules, validate_extras, validate_recipe
    validate_protocol(protocol)
    validate_manifest(manifest)
    validate_modules(R, protocol["source_modules"])
    validate_extras(R, protocol["extra_source_modules"])
    validate_recipe(R, protocol["source_recipe_sha256"])
    from v8_guards import validate_prior_ledger_bindings, validate_prior_negative_assessments, validate_repair_scope
    validate_prior_ledger_bindings(T)
    validate_prior_negative_assessments(T)
    validate_repair_scope(R, protocol["source_modules"])
    require(manifest["source_modules"] == protocol["source_modules"]
            and manifest["extra_source_modules"] == protocol["extra_source_modules"],
            "Manifest recipe and extra dependency closure differs")
    for relative, expected in protocol["tool_modules"].items():
        require(sha((T / relative).read_bytes()) == expected, "Frozen tooling changed")
    require(completion["terminal_answers"] == completion["answers_scheduled"] == len(manifest["jobs"]) == 24,
            "Incomplete collection")
    ids = {row["item_id"] for row in manifest["jobs"]}
    completion_ids = {row["item_id"] for row in completion["results"]}
    packet_ids = {row["item_id"] for row in packet}
    require(len(ids) == len(completion_ids) == len(completion["results"]) == len(packet_ids) == 24,
            "Missing or duplicate manifest/completion/packet cells")
    require(ids == completion_ids == packet_ids == {row["item_id"] for row in primary["bindings"]},
            "Manifest/completion/packet/freeze item sets differ")
    terminal = {row["item_id"]: row for row in completion["results"]}
    blinded = {row["item_id"]: row for row in packet}
    fields = ("status", "answer", "answer_sha256", "json_object", "position_count", "response_form", "synthesis_status", "synthesis_error_type")
    for job in manifest["jobs"]:
        iid = job["item_id"]
        input_path = D / (iid + ".input.json")
        answer_path = D / "answers" / (iid + ".json")
        require(sha(input_path.read_bytes()) == job["input_sha256"], "Collected input changed")
        require(sha(answer_path.read_bytes()) == terminal[iid]["file_sha256"], "Collected answer changed")
        item, answer, visible = read(input_path), read(answer_path), blinded[iid]
        require(item["item_id"] == answer["item_id"] == iid, "Collected item identity mismatch")
        require(item["kind"] == "consult", "Fresh V8 cells must be consults")
        require(terminal[iid]["status"] == answer["status"], "Completion status differs from collected response")
        require(all(visible[field] == item[field] for field in ("kind", "question", "obligations", "sources", "delivered_evidence")),
                "Blinded world/question/delivered evidence differs from frozen input")
        require(all((field in visible) == (field in answer) and visible.get(field) == answer.get(field) for field in fields),
                "Blinded answer/status metadata differs from collected response")
        require(item["delivered_evidence"]["prompt"] == item["prompt"] and sha(item["prompt"].encode("utf-8")) == item["prompt_sha256"],
                "Collected prompt binding differs")
    require(all(sha((R / path).read_bytes()) == digest for path, digest in manifest["current_modules"].items()),
            "Producer source changed")
    require(all(sha((R / path).read_bytes()) == digest for path,digest in protocol["source_modules"].items()), "Recipe-owned source changed")
    require(not OUT.exists(), "Material review output already exists")
    return primary_path, primary, labels, completion, manifest


def prepare():
    primary_path,primary,labels,completion,manifest=preflight()
    key_raw=(D/"assignment-key-unopened/key.json").read_bytes()
    key=json.loads(key_raw)
    require(set(key)=={row["item_id"] for row in manifest["jobs"]}, "Primary key coverage differs")
    OUT.mkdir()
    write(OUT/"primary-key-open-receipt.json",{
        "opened_at":datetime.now(UTC).isoformat(),"primary_key_sha256":sha(key_raw),
        "primary_freeze_sha256":sha(primary_path.read_bytes()),"labels_sha256":sha(labels.read_bytes()),
        "collector_protocol_sha256":sha((T/"v8-review-protocol.json").read_bytes()),
        "primary_labels_frozen_before_key":True,"root_preparation_method_aware":True,
        "scope":"Primary key only; fresh quality sessions receive separate opaque12pairs without mappings or primary judgments."})
    grouped=defaultdict(dict)
    for iid,info in key.items():
        item=read(D/f"{iid}.input.json");answer=read(D/"answers"/f"{iid}.json")
        require(item["kind"]=="consult" and item["item_id"]==answer["item_id"]==iid,"Fresh consult identity mismatch")
        require(item["seed"]==info["seed"],"Seed mismatch")
        pair=(info["pair"],info["seed"])
        require(info["arm"] in {"old","current"} and info["arm"] not in grouped[pair],"Duplicate method cell")
        grouped[pair][info["arm"]]=item,answer
    require(len(grouped)==12,"All12matchedconsultpairs required")
    packet=[];quality_key={}
    for (family,seed),pair in sorted(grouped.items()):
        require(set(pair)=={"old","current"},"Matched method absent")
        old,_=pair["old"];current,_=pair["current"]
        require(all(old[field]==current[field] for field in ("sources","question","obligations","kind","seed")),"Pair input worlds differ")
        pair_id=secrets.token_hex(12);order=secrets.choice([("old","current"),("current","old")])
        entry={field:old[field] for field in ("kind","question","sources","obligations")};entry["pair_id"]=pair_id
        for side,arm in zip(("A","B"),order,strict=True):
            item,answer=pair[arm]
            row={"item_id":item["item_id"],"status":answer["status"],"delivered_prompt":item["prompt"],"prompt_sha256":item["prompt_sha256"]}
            for field in ("response_form","synthesis_status","synthesis_error_type"):
                if field in answer:row[field]=answer[field]
            if isinstance(answer.get("answer"),str):
                row.update(answer=answer["answer"],answer_sha256=answer["answer_sha256"])
            else:
                row.update(answer_absence="No returned draft; execution absence is not semantic deferral",answer_sha256=None)
            entry[side]=row
        packet.append(entry);quality_key[pair_id]={"family":family,"seed":seed,"A":order[0],"B":order[1]}
    private=OUT/"quality-key-unopened";private.mkdir(mode=0o700)
    key_sha=write(private/"key.json",quality_key);(private/"key.json").chmod(0o600)
    packet_sha=write(OUT/"blinded-pairs.json",packet)
    write(OUT/"input-freeze.json",{"created_at":datetime.now(UTC).isoformat(),"pairs":12,"packet_sha256":packet_sha,
        "primary_freeze_sha256":sha(primary_path.read_bytes()),"primary_labels_sha256":sha(labels.read_bytes()),
        "collector_protocol_sha256":sha((T/"v8-review-protocol.json").read_bytes()),
        "withheld_quality_key_sha256":key_sha,"assignment_key_opened":False,"primary_labels_unchanged":True,
        "new_model_calls":0,"limits":"Rootmethodaware;24freshconsultcells only. EightunchangedpriorV5briefs remain separatelyidentified component evidence, never fresh cells. Reuseddevelopmentcases notheldout transfer."})
    print(json.dumps({"pairs":12,"packet":str(OUT/"blinded-pairs.json"),"new_model_calls":0}))

if __name__=="__main__":
    try:prepare()
    except (OSError,ValueError,KeyError,TypeError) as error:
        print(json.dumps({"status":"refused","error":str(error),"semantic_acceptance":None}),file=sys.stderr)
        raise SystemExit(2)
