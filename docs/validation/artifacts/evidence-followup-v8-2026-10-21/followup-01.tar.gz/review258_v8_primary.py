"""Offline V8 primary-label validation and blind freezing. Never opens a key.

Usage: python review258_v8_primary.py independent|finalize [--root SCRATCH_ROOT]
The default root is this file's directory. --root supports isolated synthetic
checks; it must contain the same named packet, instructions and reviewer files.
Outputs use exclusive creation and fsync. Existing outputs are never replaced.
A receipt is the last file written, so interrupted partial bundles fail closed.
These are write-once hash receipts, not filesystem or cryptographic immutability.
This helper makes no generation call and grants no inference authorization.

Reviewer row instructions: submit one row for every scheduled item+obligation,
including cells with no returned answer. Returned drafts, including empty text,
form_failed and malformed_brief, use the original four labels with their exact
answer hash. With no returned answer use answer_sha256=null, label=null,
unassessable_reason="no_returned_answer", answer_quote="", source_ids=[], and
an explanatory note. Never invent an answer or label absence as a deferral.
All 24 scheduled cells stay in the denominator; absence is counted separately
from semantic labels and label agreements. Completion/assembly validity remains
separate from the meaning of an actually returned draft.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_ITEMS = 24
EXPECTED_SLOTS = 56
LABELS = frozenset({"used_correctly", "ignored", "misapplied", "appropriately_deferred"})
TERMINAL = frozenset({
    "completed", "truncated", "empty_answer", "form_failed", "malformed_brief",
    "failed", "cancelled", "refused_followup_bound", "refused_followup_integrity",
})
ABSENT_RETURN_STATUSES = frozenset({
    "failed", "cancelled", "refused_followup_bound", "refused_followup_integrity",
})
PROTOCOL_SHA256 = 'a0281ee5b2a22538d1457d22bb64db0f1442e4f1ae3d93bd9e4329fa5ecaab91'
MANIFEST_SHA256 = '74cbcf41596ace48510959bd983ff8d668fbf293032344ba6297b23bed2dcc5d'
RUNNER_SHA256 = 'c94ea831668060bb843a04cb337735816d7e0d117e65f71a636e91fc234e11fc'
AUTHORIZATION_SHA256 = '644444f8c04d6d4d46afa3105e13ddbba27c9d75424ec1210af3052ff5660d5b'
CALIBRATION_SHA256 = 'ecd488fb288ddfee214381aaf8cd884ea0a300490307bf12bb967031be954cb5'
REVIEWER_TASKS = {'R1': '/root/primary_v8_one', 'R2': '/root/primary_v8_two', 'R3': '/root/primary_v8_adjudicator'}

PREFIX = "review258-v8"
LIMITS = (
    "Offline binding of independent obligation judgments only. Agreement counts do not "
    "establish useful advice, valid assembly, a policy winner, candidate acceptance, "
    "S0 acceptance, human review or held-out transfer. Terminal/assembly status is "
    "retained separately from visible-answer judgments. A delivered-context gap does "
    "not satisfy a missing retained-world obligation. No key opening or inference "
    "authorization is implemented. Absent returns have null hashes/labels and remain "
    "in the scheduled denominator, separately from semantic agreements/counts. Empty "
    "returned text is an actual draft reviewed under the unchanged four labels. "
    "No acceptance inference follows from null rows. Prior failed trials remain unchanged."
)


class Refusal(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Refusal(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def read(path):
    require(path.is_file(), f"required input absent: {path}")
    raw = path.read_bytes()
    return json.loads(raw, object_pairs_hook=unique_object), sha(raw)


def text(value):
    return isinstance(value, str) and bool(value.strip())


def packet_inputs(root):
    packet, packet_hash = read(root / "packing-fixtures-v8/blinded-review.json")
    require(isinstance(packet, list) and len(packet) == EXPECTED_ITEMS,
            f"expected exactly {EXPECTED_ITEMS} terminal answer items")
    items, slots, bindings = {}, {}, []
    for item in packet:
        require(isinstance(item, dict), "packet item must be an object")
        iid = item.get("item_id")
        require(text(iid) and iid not in items, "missing or duplicate item identity")
        require(item.get("kind") == "consult", f"{iid}: V8 contains fresh consult cells only")
        require(item.get("status") in TERMINAL, f"{iid}: unknown or nonterminal status")
        answer, answer_hash = item.get("answer"), item.get("answer_sha256")
        returned = isinstance(answer, str)
        if returned:
            require(text(answer_hash) and sha(answer.encode("utf-8")) == answer_hash,
                    f"{iid}: returned answer hash absent or mismatched")
        else:
            require(answer is None and answer_hash is None,
                    f"{iid}: malformed or partially present answer binding")
            require(item["status"] in ABSENT_RETURN_STATUSES,
                    f"{iid}: returned-draft status requires an actual answer, including empty text")
        require(isinstance(item.get("question"), str), f"{iid}: question absent")
        sources, obligations = item.get("sources"), item.get("obligations")
        require(isinstance(sources, list) and sources, f"{iid}: complete sources absent")
        source_ids = set()
        for source in sources:
            require(isinstance(source, dict), f"{iid}: invalid source")
            sid = source.get("source_id")
            require(text(sid) and sid not in source_ids, f"{iid}: missing or duplicate source identity")
            require(isinstance(source.get("text"), str), f"{iid}/{sid}: source text absent")
            if "text_sha256" in source:
                require(sha(source["text"].encode("utf-8")) == source["text_sha256"],
                        f"{iid}/{sid}: source hash mismatch")
            source_ids.add(sid)
        require(isinstance(obligations, list) and obligations, f"{iid}: obligations absent")
        obligation_ids = []
        for obligation in obligations:
            require(isinstance(obligation, dict), f"{iid}: invalid obligation")
            oid = obligation.get("obligation_id")
            require(text(oid) and oid not in obligation_ids, f"{iid}: missing or duplicate obligation")
            require(text(obligation.get("description")), f"{iid}/{oid}: obligation description absent")
            obligation_ids.append(oid)
            slots[(iid, oid)] = (item, obligation, source_ids)
        items[iid] = item
        bindings.append({"item_id": iid, "answer_sha256": answer_hash,
                         "status": item["status"], "returned_answer": returned,
                         "empty_answer": not answer.strip() if returned else False,
                         "unassessable_reason": None if returned else "no_returned_answer",
                         "obligation_ids": obligation_ids})
    require(len(slots) == EXPECTED_SLOTS, f"expected exactly {EXPECTED_SLOTS} obligation slots")
    return packet, slots, sorted(bindings, key=lambda item: item["item_id"]), packet_hash


def validate_rows(rows, expected, who):
    require(isinstance(rows, list) and len(rows) == len(expected), f"{who}: incomplete row count")
    result = {}
    for row in rows:
        require(isinstance(row, dict), f"{who}: review row must be an object")
        iid, oid = row.get("item_id"), row.get("obligation_id")
        require(text(iid) and text(oid), f"{who}: review identities absent")
        slot = (iid, oid)
        require(slot in expected and slot not in result, f"{who}: unknown or duplicate slot {slot}")
        item, _, sources = expected[slot]
        require(row.get("reviewer") == who, f"{who}/{slot}: reviewer identity mismatch")
        require(text(row.get("note")), f"{who}/{slot}: semantic note absent")
        require("answer_sha256" in row and row["answer_sha256"] == item.get("answer_sha256"),
                f"{who}/{slot}: answer hash absent or mismatched")
        if not isinstance(item.get("answer"), str):
            require("label" in row and row["label"] is None,
                    f"{who}/{slot}: no returned answer requires a null label")
            require(row.get("unassessable_reason") == "no_returned_answer",
                    f"{who}/{slot}: explicit no-return reason required")
            require(row.get("answer_quote") == "" and row.get("source_ids") == [],
                    f"{who}/{slot}: an absent return cannot carry quotations or source use")
            result[slot] = row
            continue
        require(row.get("label") in LABELS, f"{who}/{slot}: label outside frozen set")
        require(row.get("unassessable_reason") in (None, ""),
                f"{who}/{slot}: an actual returned draft requires semantic review")
        quote = row.get("answer_quote")
        require(isinstance(quote, str) and (not quote or quote in item["answer"]),
                f"{who}/{slot}: quotation is not an exact answer substring")
        cited = row.get("source_ids")
        require(isinstance(cited, list) and all(text(sid) for sid in cited),
                f"{who}/{slot}: invalid source identity list")
        require(len(cited) == len(set(cited)) and set(cited) <= sources,
                f"{who}/{slot}: duplicate or unknown source identity")
        result[slot] = row
    require(set(result) == set(expected), f"{who}: incomplete obligation coverage")
    return result


def collection_bindings(root, packet):
    """Join all frozen source and actual terminal bytes before any label freeze."""
    protocol, protocol_hash = read(root / "v8-review-protocol.json")
    manifest, manifest_hash = read(root / "packing-fixtures-v8/manifest.json")
    require(protocol_hash == PROTOCOL_SHA256 and manifest_hash == MANIFEST_SHA256,
            "Audited V8 protocol/manifest changed")
    admission, admission_hash = read(root / "reviewer-v8-calibration-admission.json")
    require(admission_hash == CALIBRATION_SHA256 and admission.get("admitted") is True
            and admission.get("stage") == "reviewer"
            and {r["reviewer"] for r in admission["reviewers"]} == set(REVIEWER_TASKS),
            "Exact fresh admitted primary calibration required")
    require(sha((root / "review-instructions-v3.txt").read_bytes()) == protocol["primary_rubric_sha256"],
            "Frozen primary instructions changed")
    collector, collector_hash = read(root / "v8-collector-freeze.json")
    authorization, authorization_hash = read(root / "v8-operator-authorization.json")
    require(authorization_hash == AUTHORIZATION_SHA256 and authorization.get("authorized") is True,
            "Actual operator authorization changed")
    require(collector["protocol_sha256"] == protocol_hash
            and collector["manifest_sha256"] == manifest_hash
            and collector["runner_sha256"] == RUNNER_SHA256
            and collector["authorization_sha256"] == authorization_hash,
            "Collector authority/source bindings changed")
    require(protocol["manifest_sha256"] == manifest_hash, "Protocol manifest binding changed")
    complete, complete_hash = read(root / "packing-fixtures-v8/answers-complete.json")
    require(complete["manifest_sha256"] == manifest_hash
            and complete["answers_scheduled"] == complete["terminal_answers"] == EXPECTED_ITEMS,
            "Incomplete scheduled denominator")
    jobs = manifest["jobs"]
    results = complete["results"]
    ids = {row["item_id"] for row in jobs}
    result_ids = {row["item_id"] for row in results}
    require(len(jobs) == len(ids) == len(results) == len(result_ids) == EXPECTED_ITEMS
            and ids == result_ids == {row["item_id"] for row in packet},
            "Missing, duplicate or unexpected collection cells")
    by_id = {row["item_id"]: row for row in packet}
    terminal = {row["item_id"]: row for row in results}
    fields = ("status", "answer", "answer_sha256", "json_object", "position_count", "response_form", "synthesis_status", "synthesis_error_type")
    for job in jobs:
        iid = job["item_id"]
        item, input_hash = read(root / f"packing-fixtures-v8/{iid}.input.json")
        answer, answer_hash = read(root / f"packing-fixtures-v8/answers/{iid}.json")
        visible = by_id[iid]
        require(input_hash == job["input_sha256"] and answer_hash == terminal[iid]["file_sha256"],
                "Immutable input/terminal bytes changed")
        require(item["item_id"] == answer["item_id"] == iid
                and terminal[iid]["status"] == answer["status"], "Actual terminal identity/status differs")
        require(all(visible[field] == item[field] for field in
                    ("kind", "question", "obligations", "sources", "delivered_evidence")),
                "Visible world/question/delivered evidence differs")
        require(all((field in visible) == (field in answer) and visible.get(field) == answer.get(field)
                    for field in fields), "Visible answer/status differs from complete actual draft")
        require(item["delivered_evidence"]["prompt"] == item["prompt"]
                and sha(item["prompt"].encode()) == item["prompt_sha256"]
                == item["delivered_evidence"]["prompt_sha256"], "Delivered prompt byte binding differs")
    return {"protocol_sha256": protocol_hash, "manifest_sha256": manifest_hash,
            "collector_freeze_sha256": collector_hash, "answers_complete_sha256": complete_hash,
            "authorization_sha256": authorization_hash,
            "calibration_admission_sha256": admission_hash}


def primary_inputs(root):
    packet, slots, bindings, packet_hash = packet_inputs(root)
    collection_bindings(root, packet)
    instructions = root / "review-instructions-v3.txt"
    require(instructions.is_file(), f"required input absent: {instructions}")
    instructions_hash = sha(instructions.read_bytes())
    reviews, hashes = {}, {}
    for who in ("R1", "R2"):
        rows, hashes[who] = read(root / f"reviewers/{who}/{PREFIX}.json")
        reviews[who] = validate_rows(rows, slots, who)
    differences = sorted(slot for slot in slots if isinstance(slots[slot][0].get("answer"), str)
                         and reviews["R1"][slot]["label"] != reviews["R2"][slot]["label"])
    return packet, slots, bindings, packet_hash, instructions_hash, reviews, hashes, differences


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def publish(root, outputs, receipt_name, receipt):
    require(root.is_dir(), f"scratch root absent: {root}")
    names = [*outputs, receipt_name]
    require(all(not (root / name).exists() for name in names),
            "output exists; immutable bundles are never replaced (including interrupted bundles)")
    encoded = {name: encode(value) for name, value in outputs.items()}
    receipt["output_sha256"] = {name: sha(raw) for name, raw in encoded.items()}
    encoded[receipt_name] = encode(receipt)
    for name, raw in encoded.items():
        with (root / name).open("xb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
    return {"receipt": str(root / receipt_name), "receipt_sha256": sha(encoded[receipt_name]),
            "outputs": list(outputs), "assignment_key_opened": False}


def common_receipt(root, bindings, packet_hash, instructions_hash, hashes, slots, differences):
    reviewable = sum(isinstance(item.get("answer"), str) for item, _, _ in slots.values())
    packet, _ = read(root / "packing-fixtures-v8/blinded-review.json")
    return {"collection_bindings": collection_bindings(root, packet),
            "declared_reviewer_tasks": REVIEWER_TASKS,
            "schema": "deepr.scratch.review258-v8.blind-freeze.v2",
            "frozen_at": datetime.now(timezone.utc).isoformat(),
            "assignment_key_opened": False, "key_access_implemented": False,
            "helper_sha256": sha(Path(__file__).read_bytes()),
            "packet_sha256": packet_hash, "instructions_sha256": instructions_hash,
            "reviewer_sha256": hashes, "items": len(bindings), "rows_per_reviewer": len(slots),
            "scheduled_cells": len(bindings),
            "answer_bearing_items": sum(binding["returned_answer"] for binding in bindings),
            "unassessable_items": sum(not binding["returned_answer"] for binding in bindings),
            "reviewable_obligation_slots": reviewable,
            "unassessable_obligation_slots": len(slots) - reviewable,
            "empty_answer_items": sum(binding["empty_answer"] for binding in bindings),
            "agreements": reviewable - len(differences), "disagreements": len(differences),
            "bindings": bindings, "limits": LIMITS}


def independent(root):
    _, slots, bindings, ph, ih, reviews, hashes, differences = primary_inputs(root)
    adjudication = []
    for slot in differences:
        item, obligation, _ = slots[slot]
        isolated = copy.deepcopy(item)
        isolated["obligations"] = [copy.deepcopy(obligation)]
        adjudication.append(isolated)
    disagreements = [{"item_id": iid, "obligation_id": oid,
                      "reviews": {who: reviews[who][(iid, oid)] for who in reviews}}
                     for iid, oid in differences]
    outputs = {f"{PREFIX}-adjudication-inputs.json": adjudication,
               f"{PREFIX}-disagreements.json": disagreements}
    receipt = common_receipt(root, bindings, ph, ih, hashes, slots, differences)
    receipt["stage"] = "independent"
    return publish(root, outputs, f"{PREFIX}-independent-freeze.json", receipt)


def finalize(root):
    _, slots, bindings, ph, ih, reviews, hashes, differences = primary_inputs(root)
    freeze, freeze_hash = read(root / f"{PREFIX}-independent-freeze.json")
    expected = common_receipt(root, bindings, ph, ih, hashes, slots, differences)
    for key in expected.keys() - {"frozen_at"}:
        require(freeze.get(key) == expected[key], f"independent freeze binding mismatch: {key}")
    require(freeze.get("stage") == "independent", "wrong independent freeze stage")
    names = {f"{PREFIX}-adjudication-inputs.json", f"{PREFIX}-disagreements.json"}
    require(isinstance(freeze.get("output_sha256"), dict) and set(freeze["output_sha256"]) == names,
            "independent output bindings absent")
    for name in names:
        _, actual_hash = read(root / name)
        require(actual_hash == freeze["output_sha256"][name], f"frozen output changed: {name}")
    adjudications, adjudication_hash = {}, None
    if differences:
        rows, adjudication_hash = read(root / f"reviewers/R3/{PREFIX}-adjudication.json")
        adjudications = validate_rows(rows, {slot: slots[slot] for slot in differences}, "R3")
    labels = []
    for slot in sorted(slots):
        row = copy.deepcopy(adjudications.get(slot, reviews["R1"][slot]))
        row["reviewer"] = ("R1+R2 absence binding" if row["label"] is None else
                           "R3 blind adjudication" if slot in adjudications else "R1+R2")
        row["independent_reviews"] = {who: reviews[who][slot] for who in reviews}
        row["terminal_status"] = slots[slot][0]["status"]
        labels.append(row)
    receipt = common_receipt(root, bindings, ph, ih, hashes, slots, differences)
    receipt.update(stage="final_blind", independent_freeze_sha256=freeze_hash,
                   adjudication_sha256=adjudication_hash, blind_adjudications=len(adjudications),
                   resolved_rows=len(labels),
                   resolved_labels=receipt["reviewable_obligation_slots"], candidate_accepted=None)
    return publish(root, {f"{PREFIX}-final-labels.json": labels},
                   f"{PREFIX}-final-blind-freeze.json", receipt)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("independent", "finalize"))
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args(argv)
    try:
        result = (independent if args.stage == "independent" else finalize)(args.root)
    except (Refusal, OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({"status": "refused", "reason": str(error),
                          "assignment_key_opened": False, "model_calls": 0}), file=sys.stderr)
        return 2
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
