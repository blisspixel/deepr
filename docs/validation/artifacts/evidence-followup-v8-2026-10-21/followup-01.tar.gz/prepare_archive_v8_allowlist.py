"""Prepare an exact V8 archive inventory from safe metadata and filenames only.

Operator-run after both freezes and legitimate first-open receipts exist. Never
reads keys, answer records, reviewer rows or source-world text. No inference.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,runpy,sys
from datetime import datetime
from pathlib import Path

T=Path(__file__).resolve().parent
REPO=Path('/home/pueo/Work/deepr')
FIXED=(
 'review-instructions-v3.txt','quality-review-v6-instructions.txt','v8-review-protocol.json','v8-operator-authorization.json',
 'v8-collector-freeze.json','v8-native-resource-audit.json','packing-v8-precollection-audit-inputs.json',
 'reviewers/R3/packing-v8-precollection-audit.json','packing-v8-source-recipe-proof.json',
 'packing-v8-source-snapshot-receipt.json','packing-v8-prospective-extras-receipt.json','v8-source-final.json',
 'v8-reused-brief-component.json','v6-reused-brief-component.json','v6-reused-brief-component-addendum.json',
 'v6-reused-brief-provenance-correction.json','v7-reused-brief-component.json',
 'issue258-v5-semantic-assessment.json','issue258-v6-semantic-assessment.json','issue258-v7-semantic-assessment.json','reviewer-v8-calibration-admission.json','quality-v8-calibration-admission.json',
 'review258-v8-adjudication-inputs.json','review258-v8-disagreements.json',
 'material-review-v8/reviewed-whole-pairs.json','packing_fixtures_v8.py','answer_runner_v8.py','v8_guards.py',
 'prepare_packing_v8.py','prepare_brief_reuse_v8.py','audit_native_resources_v8.py','review258_v8_primary.py',
 'prepare_v8_material_review.py','freeze_pair_quality_v8.py','v8-tooling-preparation-receipt.json','v8-tooling-freeze-receipt.json',
 'archive_v8_followup.py','prepare_archive_v8_allowlist.py','check_archive_v8_followup_R1.py',
 'check_v8_archive_config_R1.py','reviewers/R1/archive-v8-config-synthetic-checks.json',
 'reviewers/R3/v8-review-helper-preparation.json','archive-v8-review-interface-alignment.json',
 'archive_v8_followup-before-review-interface-alignment.py',
 'check_resources_v8_R2.py','reviewers/R2/resources-v8-synthetic-checks.json',
 'v8-resource-auditor-preparation-receipt.json','archive-v8-followup-usage.md','reviewers/R1/archive-v8-preparation-receipt.json','reviewers/R1/archive-v8-synthetic-checks.json',
)



def require(value,reason):
 if not value:raise ValueError(reason)


def h(raw):return hashlib.sha256(raw).hexdigest()


def build(root,helper_sha,index_sha,v6_index_sha,v7_index_sha,out):
 scope=runpy.run_path(str(T/'archive_v8_followup.py'),run_name='safe_archive_inventory_contract')
 require(root.resolve()==root and root.is_dir(),'Canonical task root required')
 # Require all key gates BEFORE data inventories. Only metadata bytes are read.
 metadata={}
 for name in sorted(scope['PINNED']):
  scope['safe_name'](name)
  path=scope['regular'](root/name,root)
  metadata[name]=path.read_bytes()
 def read(name):
  scope['safe_name'](name)
  if name not in metadata:metadata[name]=scope['regular'](root/name,root).read_bytes()
  return scope['parse'](metadata[name])
 primary=read('review258-v8-final-blind-freeze.json');quality=read('material-review-v8/quality-freeze/FREEZE.json')
 p_open=read('material-review-v8/primary-key-open-receipt.json');q_open=read('material-review-v8/quality-key-open-receipt.json')
 require(primary['stage']=='final_blind' and primary['assignment_key_opened'] is False
         and primary['scheduled_cells']==24 and primary['resolved_rows']==56,'Complete primary freeze required')
 require(quality['independent_review_inputs']==3 and quality['pairs_per_reviewer']==12
         and set(quality['snapshots'])==scope['SNAPSHOTS'],'Complete quality freeze required')
 require(p_open['primary_freeze_sha256']==h(metadata['review258-v8-final-blind-freeze.json'])
         and q_open['quality_freeze_sha256']==h(metadata['material-review-v8/quality-freeze/FREEZE.json'])
         and p_open['primary_labels_frozen_before_key'] is True and q_open['all_three_reviews_frozen_before_key'] is True,
         'Legitimate first-open receipt commitments required')
 require(scope['instant'](primary['frozen_at'])<=scope['instant'](p_open['opened_at'])<=scope['instant'](quality['frozen_at'])
         <=scope['instant'](q_open['opened_at']),'Pre-key chronology differs')
 helper=scope['regular'](root/'archive_v8_followup.py',root)
 require(h(helper.read_bytes())==scope['digest'](helper_sha),'Reviewed archive helper changed')
 manifest=read('packing-fixtures-v8/manifest.json');completion=read('packing-fixtures-v8/answers-complete.json')
 snapshot=read('packing-v8-source-snapshot-receipt.json');extra=read('packing-v8-prospective-extras-receipt.json')
 resource=read('v8-native-resource-audit.json')
 ids={row['item_id'] for row in manifest['jobs']}
 require(len(ids)==len(manifest['jobs'])==manifest['answers_scheduled']==completion['terminal_answers']==24,'All24 terminal cells required')
 require({row['item_id'] for row in completion['results']}==ids and len(completion['results'])==24,'Completion inventory differs')
 require(all(row['status'] in scope['TERMINAL'] for row in completion['results']),'Nonterminal status')
 require(set(snapshot['source_modules'])==set(scope['RECIPE_PATHS']) and len(snapshot['source_modules'])==20
         and set(extra['extra_source_modules'])==set(scope['EXTRA_PATHS']) and len(extra['extra_source_modules'])==3
         and set(manifest['current_modules'])<=set(snapshot['source_modules'])|set(extra['extra_source_modules']),
         'Prospective 20-plus-three dependency closure differs')
 files=set(scope['CORE'])|set(FIXED)
 source_final=read('v8-source-final.json')
 require(isinstance(source_final['checks'],dict),'Source-final check commitments required')
 files.update(source_final['checks'])
 for iid in ids:
  require(re.fullmatch('[0-9a-f]{16}',iid),'Invalid opaque item ID')
  files.update((f'packing-fixtures-v8/{iid}.input.json',f'packing-fixtures-v8/answers/{iid}.json'))
 for path in snapshot['source_modules']|extra['extra_source_modules']:files.add('packing-v8-source-snapshot/'+path)
 for who in ('R1','R2'):files.add(f'reviewers/{who}/review258-v8.json')
 if primary['adjudication_sha256'] is not None:files.add('reviewers/R3/review258-v8-adjudication.json')
 for name in scope['SNAPSHOTS']:files.add('material-review-v8/quality-freeze/'+name)
 corpus=[]
 for path in (root/'packing-fixtures-v8/corpus/sources').rglob('*.md'):
  name=path.relative_to(root).as_posix()
  require(re.fullmatch(r'packing-fixtures-v8/corpus/sources/[0-9a-f]{2}/[0-9a-f]{64}\.md',name),'Unexpected corpus filename')
  corpus.append(name)
 require(len(corpus)==19,'Exactly19 corpus filenames required');files.update(corpus)
 for path in (root/'packing-fixtures-v8/raw-prompt-audit').iterdir():
  require(path.is_file() and re.fullmatch(r'[A-Za-z0-9_.-]+\.json',path.name),'Unexpected raw prompt audit filename')
  files.add(path.relative_to(root).as_posix())
 for number,row in enumerate(resource['attempt_joins'],1):
  require(row['item_id'] in ids,'Unknown reserved item')
  prefix=f"v8-runtime/calls/{number:03d}.{row['item_id']}"
  files.update((prefix+'.request.json',prefix+'.response.json'))
  if row['transport_sha256'] is not None:files.add(prefix+'.transport.json')
  if (root/(prefix+'.native.json')).is_file():files.add(prefix+'.native.json')
 for name in files:
  scope['safe_name'](name,keys=name in scope['KEYS'])
  scope['regular'](root/name,root)  # metadata check only, never read these bytes
 prior={}
 for version,expected in (('v5',index_sha),('v6',v6_index_sha),('v7',v7_index_sha)):
  index=REPO/('docs/validation/artifacts/evidence-followup-'+version+'-2026-10-21/index.json')
  require(index.is_file() and (index.parent/'COMPLETE.json').is_file(),'Published complete prior archive required')
  index_raw=index.read_bytes();require(h(index_raw)==scope['digest'](expected),'Prior public index changed: '+version)
  prior['prior_'+version+'_public_index']={'path':str(index),'sha256':expected}
 config={'schema':'deepr.v8-public-archive-allowlist.v1','task_root':str(root),'public_output':str(out),
  'builder_sha256':helper_sha,'files':sorted(files),
  'metadata_sha256':{name:h(metadata[name]) for name in sorted(scope['PINNED'])},
  'current_recipe_paths':sorted(snapshot['source_modules']),'extra_recipe_paths':sorted(extra['extra_source_modules']),
  'legacy_consult_source':str(REPO/'.agent/evidence-delivery-2026-10-19/old_consult_prompt.py'),
  **prior,
  'scope':'Exactly24freshconsultcells/56primaryslots/12pairs/36wholepairjudgments and19corpus sources. PriorV5brief component receipts and V5/V6/V7 public indices remain separate hash-bound references; no priorbrief answer or assembly is copied as a freshV8cell. No inference or acceptance authority.'}
 return scope['encode'](config)


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--root',type=Path,default=T)
 parser.add_argument('--helper-sha256',required=True)
 parser.add_argument('--prior-v5-index-sha256',required=True)
 parser.add_argument('--prior-v6-index-sha256',required=True)
 parser.add_argument('--prior-v7-index-sha256',required=True)
 parser.add_argument('--output',type=Path,default=T/'archive-v8-allowlist.json')
 args=parser.parse_args();root=args.root.resolve()
 require(args.output.absolute().parent==root and args.output.name=='archive-v8-allowlist.json','Config output must be the exact new task-owned path')
 require(not args.output.exists(),'Never replace a prepared archive config')
 out=REPO/'docs/validation/artifacts/evidence-followup-v8-2026-10-21'
 raw=build(root,args.helper_sha256,args.prior_v5_index_sha256,args.prior_v6_index_sha256,args.prior_v7_index_sha256,out)
 with args.output.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 print(json.dumps({'config':str(args.output),'config_sha256':h(raw),'model_calls':0,'keys_read':False,'answer_or_judgment_bytes_read':False}))


if __name__=='__main__':
 try:main()
 except (ValueError,OSError,KeyError,TypeError) as error:
  print(json.dumps({'status':'refused','reason':str(error),'semantic_acceptance':None}),file=sys.stderr);raise SystemExit(2)
