"""V8 runner. Import-safe; explicit execution requires finality and independent admission."""

from v8_guards import (FollowupInvariantError, require, validate_modules, validate_protocol,
    validate_manifest, validate_input, require_source_final, require_prospective_extras, validate_extras, validate_recipe, validate_prior_negative_assessments, validate_prior_ledger_bindings, PRIOR_V7_PROTOCOL_SHA256, before_transport)
import asyncio, hashlib, json, os, time
from datetime import datetime, UTC
from pathlib import Path
R = Path('/home/pueo/Work/deepr')
T = Path(__file__).resolve().parent
D = T / 'packing-fixtures-v8'
F = T / 'v8-runtime'
h = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
now = lambda: datetime.now(UTC).isoformat()

def write(path, data):
    from deepr.utils.atomic_io import atomic_write_json
    atomic_write_json(path, data, fsync=True, overwrite=False)

def preflight():
    declaration = require_source_final(R, T)
    validate_prior_negative_assessments(T)
    validate_prior_ledger_bindings(T)
    require(h((T/'v7-review-protocol.json').read_bytes()) == PRIOR_V7_PROTOCOL_SHA256, 'Prior V7 protocol changed')
    extras = require_prospective_extras(R, T)
    authorization = read(T / 'v8-operator-authorization.json')
    protocol_path = T / 'v8-review-protocol.json'
    protocol = read(protocol_path)
    validate_protocol(protocol)
    require(authorization['authorized'] is True, 'Continuing operator local-only test authority required')
    require(authorization['protocol_sha256'] == h(protocol_path.read_bytes()), 'Protocol authority binding')
    require(authorization['runner_sha256'] == h(Path(__file__).read_bytes()), 'Runner authority binding')
    require(authorization['local_generation_ceiling'] == protocol['local_generation_ceiling'] == 24, '24-call cap')
    require(authorization['wall_ceiling_seconds'] == protocol['wall_ceiling_seconds'] == 5400, '5400-second cap')
    require(protocol['source_final_sha256'] == h((T/'v8-source-final.json').read_bytes()), 'Source-final binding')
    require(declaration['source_modules'] == protocol['source_modules'], 'Declared source recipe binding')
    require(declaration['source_recipe_sha256'] == protocol['source_recipe_sha256'], 'Owning recipe binding')
    validate_recipe(R, protocol['source_recipe_sha256'])
    validate_recipe(T / protocol['source_snapshot'], protocol['source_recipe_sha256'])
    require(h((T/'packing-v8-source-snapshot-receipt.json').read_bytes()) == protocol['source_snapshot_receipt_sha256'], 'Snapshot receipt binding')
    require(h((T/'packing-v8-source-recipe-proof.json').read_bytes()) == protocol['source_recipe_proof_sha256'], 'Owning recipe proof binding')
    validate_modules(R, protocol['source_modules'])
    validate_modules(T / protocol['source_snapshot'], protocol['source_modules'])
    require(extras['extra_source_modules'] == protocol['extra_source_modules'], 'Prospective extras binding')
    require(h((T/'packing-v8-prospective-extras-receipt.json').read_bytes()) == protocol['prospective_extras_receipt_sha256'], 'Extras receipt binding')
    validate_extras(T / protocol['source_snapshot'], protocol['extra_source_modules'])
    for relative, expected in protocol['tool_modules'].items():
        require(h((T/relative).read_bytes()) == expected, 'Tool changed: ' + relative)
    require(h((T/'review-instructions-v3.txt').read_bytes()) == protocol['primary_rubric_sha256'], 'Rubric bytes changed')
    audit = read(T / 'reviewers/R3/packing-v8-precollection-audit.json')
    require(audit['admitted'] is True, 'Prospective independent source admission required')
    identity = audit['identity']
    require(identity['manifest_sha256'] == h((D / 'manifest.json').read_bytes()) == protocol['manifest_sha256'], 'Manifest binding')
    require(identity['input_sha256'] == h((T / 'packing-v8-precollection-audit-inputs.json').read_bytes()), 'Audit input binding')
    require(identity['protocol_sha256'] == h(protocol_path.read_bytes()), 'Audit protocol binding')
    require(identity['runner_sha256'] == h(Path(__file__).read_bytes()), 'Audit runner binding')
    manifest = read(D / 'manifest.json')
    validate_manifest(manifest)
    require(manifest['source_modules'] == protocol['source_modules'], 'Manifest source identity binding')
    require(manifest['source_final_sha256'] == protocol['source_final_sha256'], 'Manifest finality binding')
    require(manifest['fixture_builder_sha256'] == protocol['fixture_builder_sha256'], 'Builder binding')
    require(manifest['common_form_adapter_sha256'] == protocol['source_modules']['src/deepr/experts/consult_response.py'], 'Shared new form adapter binding')
    for relative, expected in protocol['review_controls'].items():
        require(h((T/relative).read_bytes()) == expected, 'Review control changed: ' + relative)
    obligations = 0
    for job in manifest['jobs']:
        source = D / f"{job['item_id']}.input.json"
        require(h(source.read_bytes()) == job['input_sha256'], 'Input file binding')
        item = read(source)
        validate_input(item, job)
        obligations += len(item['obligations'])
    require(obligations == 56, 'All 56 consult obligations required')
    for relative, expected in protocol['prior_ledgers'].items():
        require(h((T/relative).read_bytes()) == expected, 'Prior ledger changed: ' + relative)
    require(not (D/'answers').exists() and not (T/'v8-collector-freeze.json').exists(), 'Fresh trial only; no restart or reset')
    return protocol, manifest

async def main():
    protocol, manifest = preflight()
    from filelock import FileLock
    safe = {k: v for k, v in os.environ.items() if k in ('PATH', 'HOME', 'LANG', 'LC_ALL')}
    safe.update(PYTHON_DOTENV_DISABLED='1', DEEPR_ENV_FILE=str(T / 'absent.env'), DEEPR_DATA_DIR=str(F / 'data'), DEEPR_EXPERTS_PATH=str(F / 'experts'), DEEPR_REPORTS_PATH=str(F / 'reports'), DEEPR_COST_DATA_DIR=str(F / 'costs'), TMPDIR=str(F / 'tmp'))
    os.environ.clear()
    os.environ.update(safe)
    from deepr.experts.chat_backends import ExpertChatRequest
    from deepr.experts.investigation.ollama_backend import NativeOllamaInvestigationBackend, _post_json as native_post_json
    from deepr.experts.council import SYNTHESIS_SYSTEM_PROMPT
    from deepr.experts.consult_response import admit_response_form
    from deepr.backends.capacity import OwnedLocalCapacityRefused
    from deepr.observability.local_attempts import LocalAttemptAccountingError
    F.mkdir(exist_ok=True)
    (F / 'tmp').mkdir(exist_ok=True)
    calls = F / 'calls'
    calls.mkdir(exist_ok=False)
    out = D / 'answers'
    out.mkdir(exist_ok=False)
    started_at = now()
    started = time.monotonic()
    write(T / 'v8-collector-freeze.json', {'started_at': started_at, 'runner_sha256': h(Path(__file__).read_bytes()), 'protocol_sha256': h((T / 'v8-review-protocol.json').read_bytes()), 'authorization_sha256': h((T / 'v8-operator-authorization.json').read_bytes()), 'manifest_sha256': h((D / 'manifest.json').read_bytes()), 'audit_sha256': h((T / 'reviewers/R3/packing-v8-precollection-audit.json').read_bytes()), 'max_calls': 24, 'max_wall_seconds': 5400, 'prior_native_attempts': 180, 'native_attempts_if_full': 204, 'paid_provider_api_ceiling_usd': 0, 'original_trial': 'Original100, V5 32, V6 24 and V7 24 attempts remain frozen; V8 fresh24consultcalls under continuing local-only authority, separate ledger, no automatic retry.'})
    generator = manifest['generator']
    active_deadline = {'monotonic': 0.0}
    transport_result = {}

    async def bounded_post_json(url, payload, timeout):
        # Dispatch accounting is synchronous and may consume the remaining budget.
        validate_prior_negative_assessments(T)
        validate_prior_ledger_bindings(T)
        remaining = before_transport(R, protocol, request, active_deadline['monotonic'],
            lambda: 5400 - (datetime.now(UTC) - datetime.fromisoformat(started_at)).total_seconds(), time.monotonic)
        data = await native_post_json(url, payload, min(timeout, remaining))
        # Preserve bytes returned by transport before terminal ledger accounting.
        receipt = request.with_name(request.name.replace('.request.json', '.transport.json'))
        try:
            write(receipt, {'observed_at': now(), 'raw_response': data, 'request_sha256': h(request.read_bytes())})
        except Exception as error:
            raise FollowupInvariantError('Native transport response could not be durably retained') from error
        transport_result.update(raw=data, receipt=receipt)
        return data

    client = NativeOllamaInvestigationBackend(model=generator['model'], timeout=600, post_json=bounded_post_json)
    client.pinned_digest = generator['digest']
    results = []
    fatal_stop = ''
    for number, job in enumerate(manifest['jobs'], 1):
        source = D / f"{job['item_id']}.input.json"
        require(h(source.read_bytes()) == job['input_sha256'], "h(source.read_bytes())==job['input_sha256']")
        item = read(source)
        validate_input(item, job)
        identifier = item['item_id']
        request = None
        require(len(item['prompt']) <= item['prompt_limit_chars'] and h(item['prompt'].encode('utf-8')) == item['prompt_sha256'], "len(item['prompt'])<=item['prompt_limit_chars'] and h(item['prompt'].encode('utf-8'))==item['prompt_sha256']")
        require(item['seed'] in (20261020, 20261021), "item['seed'] in (20261020,20261021)")
        require(all((h((R / path).read_bytes()) == sha for path, sha in protocol['source_modules'].items())), "all(h((R/path).read_bytes())==sha for path,sha in protocol['source_modules'].items())")
        system = SYNTHESIS_SYSTEM_PROMPT
        with FileLock(str(F / 'call-budget.lock')):
            count = len(list(calls.glob('*.request.json')))
            remaining = min(5400 - (time.monotonic() - started), 5400 - (datetime.now(UTC) - datetime.fromisoformat(started_at)).total_seconds())
            if fatal_stop:
                row = {'item_id': identifier, 'status': 'refused_followup_integrity', 'observed_at': now(), 'cause': fatal_stop, 'followup_calls_reserved': count, 'remaining_followup_seconds': remaining}
            elif count >= 24 or remaining <= 0:
                row = {'item_id': identifier, 'status': 'refused_followup_bound', 'observed_at': now(), 'followup_calls_reserved': count, 'remaining_followup_seconds': remaining}
            else:
                request = calls / f'{count + 1:03d}.{identifier}.request.json'
                client.timeout = min(item['timeout_seconds'], remaining)
                write(request, {'phase': 'answer258v8', 'created_at': now(), 'item_id': identifier, 'generator': generator, 'seed': item['seed'], 'system': system, 'user': item['prompt'], 'max_tokens': item['output_tokens'], 'phase_timeout_seconds': item['timeout_seconds'], 'effective_timeout_seconds': client.timeout, 'manifest_sha256': h((D / 'manifest.json').read_bytes())})
        if request is not None:
            call_started = time.perf_counter()
            transport_result.clear()
            try:
                extra = {k: generator[k] for k in ('num_ctx', 'temperature', 'think')}
                extra.update(seed=item['seed'], max_tokens=item['output_tokens'])
                remaining_at_dispatch = min(5400 - (time.monotonic() - started), 5400 - (datetime.now(UTC) - datetime.fromisoformat(started_at)).total_seconds())
                if remaining_at_dispatch <= 0:
                    raise TimeoutError('Follow-up wall budget exhausted before dispatch')
                active_deadline['monotonic'] = time.monotonic() + min(client.timeout, remaining_at_dispatch)
                async with asyncio.timeout(min(client.timeout, remaining_at_dispatch)):
                    response = await client.complete(ExpertChatRequest(model=generator['model'], messages=[{'role': 'system', 'content': system}, {'role': 'user', 'content': item['prompt']}], extra=extra), correlation_id=f'issue-completion:answer258v8:{identifier}')
                native_receipt = request.with_name(request.name.replace('.request.json', '.native.json'))
                write(native_receipt, {'raw_response': response.raw_response, 'text': response.text, 'provider_request_id': response.provider_request_id, 'stop_reason': response.stop_reason})
                raw = response.raw_response or {}
                require(client.last_attested_digest == generator['digest'], "client.last_attested_digest==generator['digest']")
                row = {'item_id': identifier, 'status': 'completed', 'answer': response.text, 'answer_sha256': h(response.text.encode('utf-8')), 'observed_digest': client.last_attested_digest, 'stop_reason': raw.get('done_reason'), 'tokens_input': raw.get('prompt_eval_count'), 'tokens_output': raw.get('eval_count'), 'elapsed_s': round(time.perf_counter() - call_started, 3), 'request_sha256': h(request.read_bytes()), 'native_response_sha256': h(native_receipt.read_bytes())}
                if raw.get('done_reason') in ('length', 'max_tokens'):
                    row['status'] = 'truncated'
                if not response.text.strip():
                    row['status'] = 'empty_answer'
                if item['kind'] == 'consult':
                    admitted = admit_response_form(item['question'], {'text': response.text, 'synthesis_status': 'completed' if row['status'] == 'completed' else row['status'], 'synthesis_error_type': ''})
                    row['response_form'] = admitted['response_form']
                    row['synthesis_status'] = admitted['synthesis_status']
                    row['synthesis_error_type'] = admitted['synthesis_error_type']
                    if admitted['synthesis_error_type'] == 'ResponseWordLimit':
                        row['status'] = 'form_failed'
            except BaseException as error:
                if isinstance(error, (LocalAttemptAccountingError, FollowupInvariantError)) or (isinstance(error, OwnedLocalCapacityRefused) and error.reason == 'model_identity_changed'):
                    fatal_stop = type(error).__name__ + ':' + str(getattr(error, 'reason', 'integrity_failure'))
                row = {'item_id': identifier, 'status': 'cancelled' if isinstance(error, asyncio.CancelledError) else 'failed', 'error_type': type(error).__name__, 'error': str(error), 'elapsed_s': round(time.perf_counter() - call_started, 3), 'request_sha256': h(request.read_bytes())}
                if transport_result.get('receipt'):
                    row['transport_response_sha256'] = h(transport_result['receipt'].read_bytes())
                    data = transport_result['raw']
                    message = data.get('message') if isinstance(data, dict) else None
                    if isinstance(message, dict) and isinstance(message.get('content'), str):
                        row.update(answer=message['content'], answer_sha256=h(message['content'].encode('utf-8')), tokens_input=data.get('prompt_eval_count'), tokens_output=data.get('eval_count'), observed_digest=client.last_attested_digest, stop_reason=data.get('done_reason'))
                write(request.with_name(request.name.replace('.request.json', '.response.json')), row)
                write(out / f'{identifier}.json', row)
                if not isinstance(error, Exception):
                    raise
            else:
                write(request.with_name(request.name.replace('.request.json', '.response.json')), row)
                write(out / f'{identifier}.json', row)
        else:
            write(out / f'{identifier}.json', row)
        results.append(row)
        print(f"Follow-up answer {number}/24: {row['status']}", flush=True)
    write(D / 'answers-complete.json', {'completed_at': now(), 'manifest_sha256': h((D / 'manifest.json').read_bytes()), 'answers_scheduled': 24, 'terminal_answers': len(results), 'native_requests_reserved': len(list(calls.glob('*.request.json'))), 'wall_seconds': round(time.monotonic() - started, 3), 'results': [{'item_id': row['item_id'], 'status': row['status'], 'file_sha256': h((out / f"{row['item_id']}.json").read_bytes())} for row in results]})
    packet = []
    for job in manifest['jobs']:
        item = read(D / f"{job['item_id']}.input.json")
        answer = read(out / f"{job['item_id']}.json")
        packet.append({key: item[key] for key in ('item_id', 'kind', 'question', 'obligations', 'sources', 'delivered_evidence')} | {key: answer[key] for key in ('status', 'answer', 'answer_sha256', 'json_object', 'position_count', 'response_form', 'synthesis_status', 'synthesis_error_type') if key in answer})
    write(D / 'blinded-review.json', packet)
    print('Follow-up terminal review packet complete; assignment key withheld.', flush=True)
if __name__ == '__main__':
    from filelock import FileLock
    with FileLock(str(T / 'followup-runner.lock'), timeout=0):
        asyncio.run(main())
