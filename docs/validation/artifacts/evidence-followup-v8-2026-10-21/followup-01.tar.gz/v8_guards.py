"""Pure scratch invariants. Importing this module performs no filesystem writes."""
from datetime import UTC, datetime
import hashlib
import ast
import json
from pathlib import Path

MODULE_PATHS = (
    'src/deepr/experts/brief.py',
    'src/deepr/experts/brief_attribution.py',
    'src/deepr/experts/brief_contracts.py',
    'src/deepr/experts/brief_selection.py',
    'src/deepr/experts/consult_support.py',
    'src/deepr/experts/study_contracts.py',
    'src/deepr/experts/consult_context.py',
    'src/deepr/experts/consult_prompt.py',
    'src/deepr/experts/consult_response.py',
    'src/deepr/experts/council.py',
    'src/deepr/experts/council_synthesis_runtime.py',
    'src/deepr/experts/consult_routing.py',
    'src/deepr/backends/local.py',
    'src/deepr/backends/embedding_profiles.py',
    'src/deepr/experts/investigation/ollama_backend.py',
    'src/deepr/observability/local_attempts.py',
    'src/deepr/evals/correction_survival.py',
    'src/deepr/evals/correction_survival_cases.py',
    'src/deepr/evals/correction_survival_local.py',
    'src/deepr/evals/correction_survival_review.py',
)
EXTRA_MODULE_PATHS = (
    'src/deepr/experts/consult.py',
    'src/deepr/experts/corpus_store.py',
    'src/deepr/utils/atomic_io.py',
)
CHANGED_CONSULT_MODULES = frozenset({
    'src/deepr/experts/consult_prompt.py',
    'src/deepr/experts/consult_response.py',
})
RUBRIC_SHA256 = 'e349467573ee9a275d75c09f5d9660b5237ff943f1f103540496436a014e1f9a'
GENERATOR = {
    'model': 'qwen3.8:27b',
    'digest': 'aaee06c39dcf2437cde036998d960e1fc1494b8191be7cc9657d01e509097813',
    'num_ctx': 16384, 'temperature': 0, 'think': False,
    'seeds': [20261020, 20261021], 'timeout_seconds': 600,
}

REVIEW_CONTROL_HASHES = {'quality-review-v6-instructions.txt': '2039cfb555aa5fa6a6e7114019a9f0be2d0bc5f37e0da267a5a11aa281712710', 'agent-calibration-inputs.json': 'cf53a4f0ff431a7a0241a752c54596b427b36159d17d5169901ce464c5b738b5', 'review-instructions-v3.txt': 'e349467573ee9a275d75c09f5d9660b5237ff943f1f103540496436a014e1f9a', 'agent-calibration-freeze.json': '60fa55ca8308f95c27821f143b2254a7015368136757225ec0c178757a05955f'}
PRIOR_LEDGER_HASHES = {'runtime/costs/cost_ledger.jsonl': '2af1a9c4344e1c9576c200ee3c7b7c687e0905008efe8b2eec9b2b4c9c97dec1', 'followup-runtime/costs/cost_ledger.jsonl': 'd2291d3c0cd0338b23ebed46a10f2b22161cdc4e1d7f0c704b1ba4909634f658', 'v6-runtime/costs/cost_ledger.jsonl': '8f076a133930ded4ab9dd1fcd776e55e55a991515dd77db00110bea8ac8317b6', 'v7-runtime/costs/cost_ledger.jsonl': 'baff197173e83d43fe0abd6c61980499370f429e4f0bd6e0f9c2e096292e3a9f'}
BASELINE_V7_SOURCE_MODULES = {'src/deepr/experts/brief.py': '7816c634906aa30e3ca104429e9d7357491e65568227b368617c1812709f049b', 'src/deepr/experts/brief_attribution.py': 'eecdff3de40a60c9f58b0e9ab7c89f216fb9a81dce41f4b2033d8e9176c00bb1', 'src/deepr/experts/brief_contracts.py': 'e47f7c4a26e73f685eecf23d6357197e933349017be9f18891d1d38b7094140e', 'src/deepr/experts/brief_selection.py': '177d9ca1ca3a270d4663ffd3023b81a8109bed8832da50721ec100c126e10ad7', 'src/deepr/experts/consult_support.py': 'abad37efa221737c353ecad9961cd6dd1148e5d5bd83dbeac59eb933ac84c877', 'src/deepr/experts/study_contracts.py': '43ba972a955308a61acf59c3bf4dda5e501ebbac906506dfdfc9c9782f74855c', 'src/deepr/experts/consult_context.py': 'e71ab3d7a5f2cd7f240990093c23589146efbad3ed40adeb1761c4b544ce9de5', 'src/deepr/experts/consult_prompt.py': '4a3eb8ad0adad7a0c7ac0e5b6e1642b25d206dd05e169cfed9846d85bd0f8367', 'src/deepr/experts/consult_response.py': 'aae9773a915390d8c2d29fd933c2886c4f60b5ca958939612125ac4f7f48b410', 'src/deepr/experts/council.py': '735b19f2cc4c679791679387df0f181bbd98c80a4078a6a5490c9d16e4a88243', 'src/deepr/experts/council_synthesis_runtime.py': 'c4643eb0388f23e8d3abe35b29e497a950024e3ed3b04400b4fb6bf85b85b729', 'src/deepr/experts/consult_routing.py': '132b576013f57bf8aefd3d5677c57b73aa679b6893a31206a5c432e8df5e27c0', 'src/deepr/backends/local.py': 'eaa59ca82651d381b582864f5c3caa832ee3994369356789beeacefaf2a13139', 'src/deepr/backends/embedding_profiles.py': '6cda8017f07648509e03306583969f6367d96d932f39a20e2ef3cb2a7f2395c5', 'src/deepr/experts/investigation/ollama_backend.py': '76ff53632d9f81dd5d29aa6d8ba3e82759e18271eba688e15763096a351b22da', 'src/deepr/observability/local_attempts.py': '9265d95c1dfbce31979277376af5cdb13b9334807b3ee9092bc5763147ea4943', 'src/deepr/evals/correction_survival.py': '92357cd524df9ab24de7f907698667f1d81fb0f25b031ddac11cf3be293b39ba', 'src/deepr/evals/correction_survival_cases.py': '28547f450cdba4d716132300bb8cc225fa1dd016bc832157a647ca3fce7a2067', 'src/deepr/evals/correction_survival_local.py': '185baf4f81118e7737ba4f709254e0d3b51194262e3cdd2418803bba436c365d', 'src/deepr/evals/correction_survival_review.py': '5f115f68ae9ec513afa5dbe8506e23aeee2a7601045461a17f2657edf7d8cc0c'}
BASELINE_V7_EXTRA_MODULES = {'src/deepr/experts/consult.py': '803e23856780846a01fca6891b6a3b4aed2abf0bea6160d1d692cc2e510e1a7e', 'src/deepr/experts/corpus_store.py': '18a6524256222d05c65f481b20fb48865918904e89ad84628b2ebbf3ff93a69c', 'src/deepr/utils/atomic_io.py': '458dd9fe0a89dadd65c1a44481423caee94f1eb801c4e3c64630a3f04784c96e'}
PRIOR_V7_PROTOCOL_SHA256 = 'bf391e7c15ede68b01cb17709dfa382ff09b19fbd9fb14b16b5082de16b87baf'
PRIOR_V7_COMPONENT_SHA256 = 'd13aaff6dde7b794a783c667bbb7c8b96f8f5db5027bc4761ce3261673ffe949'
PRIOR_NEGATIVE_HASHES = {'issue258-v5-semantic-assessment.json': '3818c34aaa6cd2d318c87030d14e33b2152c53ff51dfc483b5c35edaec36e087', 'issue258-v6-semantic-assessment.json': '1f06a19b91cf9b8f4f94c155c8006a0451a8fa975863fbd13f7c1cc8b9ec4c7c', 'issue258-v7-semantic-assessment.json': '60b5fe90d11f4e38c6d8d3ce6ebb3ca1af37e7e9b42abf836215d21de0f0f8f5'}
FORM_MODULE = "src/deepr/experts/consult_response.py"
BASELINE_FORM_NONINSTRUCTION_AST_SHA256 = '47a532a6b3ccc11b8e4ebf5306879a6fba70098de7fdf1e6bfdc100ba7d724c3'



class FollowupInvariantError(RuntimeError):
    pass


def require(condition, detail):
    if not condition:
        raise FollowupInvariantError('V8 invariant failed: ' + detail)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_exclusive(path, value):
    """Create once; callers must choose their output directory explicitly."""
    with Path(path).open('x', encoding='utf-8', newline='\n') as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write('\n')


def validate_modules(root, expected):
    require(set(expected) == set(MODULE_PATHS), 'Exact 20-module recipe required')
    for relative, expected_hash in expected.items():
        path = Path(root) / relative
        require(path.is_file() and digest(path) == expected_hash, 'Recipe module changed: ' + relative)


def validate_extras(root, expected):
    require(set(expected) == set(EXTRA_MODULE_PATHS), 'Prospective extra dependency closure required')
    for relative, expected_hash in expected.items():
        require(digest(Path(root) / relative) == expected_hash, 'Extra source changed: ' + relative)


def require_prospective_extras(root, task):
    receipt = read(Path(task) / 'packing-v8-prospective-extras-receipt.json')
    require(receipt['source_final_sha256'] == digest(Path(task) / 'v8-source-final.json'), 'Extra source finality binding')
    require(receipt['provenance'] == 'prospectively captured before V8 fixture build and collection', 'Extra provenance must be prospective')
    validate_extras(root, receipt['extra_source_modules'])
    return receipt


def recipe_digest(root):
    """Owning recipe algorithm: ordered package-relative path then raw bytes.

    Matches correction_survival.recipe_sha256: no delimiter and no src/ prefix
    in the bytes representing the package-relative module path.
    """
    identity = hashlib.sha256()
    for relative in MODULE_PATHS:
        identity.update(relative.removeprefix('src/').encode('utf-8'))
        identity.update((Path(root) / relative).read_bytes())
    return identity.hexdigest()


def validate_recipe(root, expected):
    require(recipe_digest(root) == expected, 'Owning source recipe identity differs')


def noninstruction_form_digest(path):
    """Preserve parser/admission structure outside the instruction function body."""
    module = ast.parse(Path(path).read_text(encoding='utf-8'))
    matches = 0
    for node in module.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == 'response_form_instruction':
            node.body = [ast.Pass()]
            matches += 1
    require(matches == 1, 'Exactly one existing form instruction function required')
    return hashlib.sha256(ast.dump(module, include_attributes=False).encode()).hexdigest()


def validate_repair_scope(root, declared):
    """Only form source may change; packing/guidance and extras stay at V7."""
    require(set(declared) == set(BASELINE_V7_SOURCE_MODULES), 'V7 source closure changed')
    changed = {path for path in declared if declared[path] != BASELINE_V7_SOURCE_MODULES[path]}
    require(changed == {FORM_MODULE}, 'V8 repair must change only consult_response.py from V7')
    require(noninstruction_form_digest(Path(root)/FORM_MODULE) == BASELINE_FORM_NONINSTRUCTION_AST_SHA256, 'V8 may change only the drafting instruction body; parser/admission structure must remain unchanged')
    validate_extras(root, BASELINE_V7_EXTRA_MODULES)


def validate_prior_ledger_bindings(task):
    for relative, expected in PRIOR_LEDGER_HASHES.items():
        require(digest(Path(task)/relative) == expected, 'Prior native ledger changed: ' + relative)


def validate_prior_negative_assessments(task):
    for relative, expected in PRIOR_NEGATIVE_HASHES.items():
        require(digest(Path(task)/relative) == expected, 'Prior negative assessment changed: ' + relative)


def require_source_final(root, task):
    declaration = read(Path(task) / 'v8-source-final.json')
    require(declaration.get('source_final') is True, 'Root source-final confirmation required')
    require(declaration.get('confirmed_by') == '/root', 'Root declaration identity required')
    require(bool(declaration.get('instruction', '').strip()), 'Explicit source-final instruction required')
    validate_modules(root, declaration.get('source_modules', {}))
    validate_recipe(root, declaration.get('source_recipe_sha256'))
    validate_repair_scope(root, declaration['source_modules'])
    return declaration


def validate_protocol(protocol):
    require(protocol.get('status') == 'frozen', 'Frozen V8 protocol required')
    require(protocol['local_generation_ceiling'] == 24, '24 calls required')
    require(protocol['wall_ceiling_seconds'] == 5400, '5400 seconds required')
    require(protocol['paid_provider_api_ceiling_usd'] == 0, 'Zero direct paid API ceiling required')
    require(protocol['automatic_retry'] is False, 'Retries forbidden')
    require(protocol['generator'] == GENERATOR, 'Pinned generator changed')
    require(protocol['primary_rubric_sha256'] == RUBRIC_SHA256, 'Frozen rubric changed')
    require(protocol['review_controls'] == REVIEW_CONTROL_HASHES, 'Unchanged review controls required')
    require(protocol['prior_ledgers'] == PRIOR_LEDGER_HASHES, 'All 180 prior attempt ledgers must remain frozen')
    require(protocol['preceding_v7_protocol_sha256'] == PRIOR_V7_PROTOCOL_SHA256, 'Frozen V7 protocol anchor changed')
    require(protocol['prior_negative_assessments_sha256'] == PRIOR_NEGATIVE_HASHES, 'Prior negative pins changed')
    require(protocol['prior_native_attempts'] == 180 and protocol['total_native_attempts_if_v8_full'] == 204, 'Prior/full V8 totals changed')
    require(protocol['permitted_changed_source_modules'] == [FORM_MODULE], 'Form-only repair boundary changed')
    require(protocol['allowances'] == {
        'consult_prompt_chars': 6500, 'production_prompt_chars_ceiling': 16000,
        'output_tokens': 1024, 'call_timeout_seconds': 600,
    }, 'Matched consult allowances changed')


def validate_manifest(manifest):
    require(manifest['answers_scheduled'] == len(manifest['jobs']) == 24, '24 scheduled consult cells required')
    require(len({job['item_id'] for job in manifest['jobs']}) == 24, 'Unique cells required')
    require(manifest['pairs'] == 12 and manifest['case_families'] == 6, 'Six families / 12 seeded pairs required')
    require(manifest['generator'] == GENERATOR, 'Manifest generator changed')


def validate_input(item, job):
    require(item['item_id'] == job['item_id'], 'Input item binding')
    require(item['kind'] == 'consult', 'V8 consult-only trial')
    require(item['status'] == 'ready', 'Refused fixture may not dispatch')
    require(item['seed'] in GENERATOR['seeds'], 'Frozen seed required')
    require(item['output_tokens'] == 1024 and item['timeout_seconds'] == 600, 'Per-call allowance changed')
    require(item['prompt_limit_chars'] == 6500 and len(item['prompt']) <= 6500, 'Prompt allowance changed')
    prompt_hash = hashlib.sha256(item['prompt'].encode()).hexdigest()
    require(prompt_hash == item['prompt_sha256'] == item['delivered_evidence']['prompt_sha256'], 'Prompt byte binding')
    require(item['prompt'] == item['delivered_evidence']['prompt'], 'Delivered prompt differs')


def before_transport(root, protocol, request, active_deadline, wall_remaining, monotonic):
    """Run after dispatch accounting, before the native HTTP transport."""
    validate_modules(root, protocol['source_modules'])
    validate_extras(root, protocol['extra_source_modules'])
    require(request is not None and Path(request).is_file(), 'Durable reservation required before transport')
    remaining = min(active_deadline - monotonic(), wall_remaining())
    require(remaining > 0, 'Deadline exhausted before native POST')
    return remaining


def utc_now():
    return datetime.now(UTC).isoformat()
