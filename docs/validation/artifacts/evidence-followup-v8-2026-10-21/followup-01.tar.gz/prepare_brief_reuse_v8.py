"""Prepare a separate prior V5 brief component receipt; never creates fresh cells.

No action occurs on import. Execution hashes opaque prior artifacts, including
prior returned/assembled artifacts and review receipts, without interpreting
answers or judgments. It never opens assignment keys.
"""
import argparse
from pathlib import Path
from v8_guards import (
    CHANGED_CONSULT_MODULES, GENERATOR, PRIOR_V7_COMPONENT_SHA256, digest, read, require,
    require_source_final, utc_now, write_exclusive,
)


def owned_file(task, relative):
    path = (task / relative).resolve()
    require(path.is_relative_to(task.resolve()), 'Prior artifact escapes task root')
    require('assignment-key' not in relative and path.name != 'key.json', 'Assignment key access forbidden')
    require(path.is_file(), 'Missing prior artifact: ' + relative)
    return path


def checked_files(task, expected):
    for relative, expected_hash in expected.items():
        require(digest(owned_file(task, relative)) == expected_hash, 'Prior artifact changed: ' + relative)
    return dict(expected)


def build_receipt(root, task):
    """Call only after root source-final declaration; V6 receipts remain unchanged."""
    root, task = Path(root), Path(task)
    final = require_source_final(root, task)
    v7_path = task / 'v7-reused-brief-component.json'
    require(digest(v7_path) == PRIOR_V7_COMPONENT_SHA256, 'Exact V7 brief reuse anchor changed')
    v7 = read(v7_path)
    prior_path = task / 'v6-reused-brief-component.json'
    addendum_path = task / 'v6-reused-brief-component-addendum.json'
    correction_path = task / 'v6-reused-brief-provenance-correction.json'
    prior, addendum, correction = read(prior_path), read(addendum_path), read(correction_path)
    require(v7['prior_component_sha256'] == digest(prior_path) and v7['prior_addendum_sha256'] == digest(addendum_path) and v7['prior_provenance_correction_sha256'] == digest(correction_path), 'V7 prior component closure differs')
    require(set(v7['excluded_changed_consult_modules']) == CHANGED_CONSULT_MODULES, 'Both consult modules must stay excluded in V7 anchor')
    require(digest(prior_path) == addendum['original_reuse_receipt_sha256'], 'Original reuse receipt binding')
    require(digest(addendum_path) == correction['addendum_sha256'], 'Corrected dependency provenance binding')
    require(prior['prior_trial'] == 'V5' and prior['prior_brief_cells'] == 8, 'Prior eight V5 brief cells required')
    require(len(set(prior['brief_item_ids'])) == 8 and len(addendum['requests']) == 8, 'Exact eight prior cells required')
    require({r['item_id'] for r in addendum['requests']} == set(prior['brief_item_ids']), 'Prior request identities differ')
    unchanged = {path: value for path, value in prior['unchanged_prior_recipe_modules'].items()
                 if path not in CHANGED_CONSULT_MODULES}
    require(v7['unchanged_prior_recipe_modules'] == unchanged and v7['exact_prior_requests'] == addendum['requests'], 'V7 actual producer/input closure changed')
    require(v7['preserved_adverse_findings_and_limits'] == prior['interpretation'], 'V7 adverse brief findings changed')
    require(set(unchanged) == set(final['source_modules']) - CHANGED_CONSULT_MODULES,
            'Exclude exactly both changed consult modules from prior recipe equality')
    snapshot_bindings = {}
    for relative, expected_hash in unchanged.items():
        require(digest(root / relative) == expected_hash, 'Brief recipe dependency changed: ' + relative)
        snapshot = owned_file(task, 'packing-v5-source-snapshot/' + relative)
        require(digest(snapshot) == expected_hash, 'Original V5 snapshot differs: ' + relative)
        snapshot_bindings[relative] = {'sha256': expected_hash, 'identity': 'Captured in original V5 source snapshot; unchanged in V8.'}
    additional = correction['additional_dependency_bindings']
    for relative, binding in additional.items():
        require(relative not in CHANGED_CONSULT_MODULES, 'Changed consult module cannot enter brief equality')
        require(digest(root / relative) == binding['sha256'], 'Corrected brief dependency changed: ' + relative)
        # Keep captured versus reconstructed provenance exactly as corrected.
        snapshot_bindings[relative] = dict(binding)
    required_files = {'packing-fixtures-v5/manifest.json', 'packing-v5-source-snapshot-receipt.json',
                      'material-review-v5/brief-assembly-receipt.json'}
    for identifier in prior['brief_item_ids']:
        required_files.update({'packing-fixtures-v5/' + identifier + '.input.json',
                               'packing-fixtures-v5/answers/' + identifier + '.json',
                               'material-review-v5/' + identifier + '/assembled.json',
                               'material-review-v5/' + identifier + '/rendered.md'})
    require(required_files <= set(prior['files_sha256']), 'Original input/output/assembly bindings missing')
    require(all(r['request_file'] in addendum['files_sha256'] for r in addendum['requests']), 'Original actual producer request hashes missing')
    files = checked_files(task, prior['files_sha256'])
    files.update(checked_files(task, addendum['files_sha256']))
    for request in addendum['requests']:
        actual = read(owned_file(task, request['request_file']))
        item = read(owned_file(task, 'packing-fixtures-v5/' + request['item_id'] + '.input.json'))
        import hashlib
        sha_text = lambda value: hashlib.sha256(value.encode('utf-8')).hexdigest()
        require(actual['item_id'] == item['item_id'] == request['item_id'], 'Actual prior producer item binding')
        require(item['kind'] == 'brief', 'Consult cells cannot be reused as briefs')
        require(actual['seed'] == item['seed'] == request['seed'], 'Prior seed binding')
        require(actual['user'] == item['prompt'], 'Exact actual producer input differs')
        require(sha_text(actual['user']) == request['user_sha256'], 'Actual user bytes differ')
        require(sha_text(actual['system']) == request['system_sha256'], 'Actual system bytes differ')
        require(actual['generator'] == request['generator'] == GENERATOR, 'Actual prior pinned producer differs')
        require(actual['max_tokens'] == item['output_tokens'] == request['output_tokens'] == 6144,
                'Prior brief producer output allowance differs')
    v5_manifest_path = owned_file(task, 'packing-fixtures-v5/manifest.json')
    v5_manifest = read(v5_manifest_path)
    # The exact frozen baseline brief producer and builder are additional provenance.
    producer_files = {'original_brief.py': v5_manifest['old_brief_sha256']}
    producer_files = checked_files(task, producer_files)
    receipt = {
        'frozen_at': utc_now(), 'prior_trial': 'V5', 'fresh_v8_cells': 0,
        'prior_brief_cells': 8, 'prior_primary_slots': 16,
        'prior_whole_pairs': 4, 'prior_whole_pair_judgments': 12,
        'brief_item_ids': prior['brief_item_ids'], 'brief_pair_ids': prior['brief_pair_ids'],
        'prior_v7_component_sha256': digest(v7_path),
        'prior_component_sha256': digest(prior_path), 'prior_addendum_sha256': digest(addendum_path),
        'prior_provenance_correction_sha256': digest(correction_path),
        'source_final_sha256': digest(task / 'v8-source-final.json'),
        'excluded_changed_consult_modules': sorted(CHANGED_CONSULT_MODULES),
        'unchanged_prior_recipe_modules': unchanged, 'dependency_provenance': snapshot_bindings,
        'exact_prior_requests': addendum['requests'], 'files_sha256': files,
        'additional_actual_producer_files_sha256': producer_files,
        'preserved_adverse_findings_and_limits': prior['interpretation'],
        'interpretation': 'Separate prior V5 component evidence only. No fresh V8 briefing, replication, full V5/V8 policy acceptance or favorable semantic inference from hashes. Every unresolved prior adverse brief finding remains material.',
        'limits': 'Exact retained producer, input, artifact and bounded dependency identity only. Captured versus reconstructed provenance retained. Whole runtime, daemon and semantic correctness are not established.',
    }
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/home/pueo/Work/deepr'))
    parser.add_argument('--task', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    receipt = build_receipt(args.root, args.task)
    output = args.task / 'v8-reused-brief-component.json'
    write_exclusive(output, receipt)
    print(str(output), digest(output))


if __name__ == '__main__':
    main()
