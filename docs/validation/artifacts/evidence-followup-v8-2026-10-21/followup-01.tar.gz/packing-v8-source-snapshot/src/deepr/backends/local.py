"""Local Ollama backend - research on owned hardware at $0 (ROADMAP v2.16).

The capacity release's "local-first validation" step (docs/design/
capacity-waterfall.md): plug a local model into deepr's existing injectable
seams so dev/test and quality-tolerant work run at $0 on owned hardware. Even
when local output quality is below the deep-research floor, the *flow* is fully
real - submit, extract, verify, absorb - so the whole expert lifecycle can be
exercised end to end for free.

Ollama serves an OpenAI-compatible API at ``/v1``, so an ``AsyncOpenAI`` client
pointed there satisfies every chat seam deepr already uses (report_absorber,
reflection, conflict_resolver) with no new client shape. ``make_local_research_fn``
adapts the same to the ``research_fn`` seam (sync, gap-fill).

This is local execution, not deep research. Eval-gated admission for *routing*
quality lands with the waterfall router; this module is the $0 substrate.
"""

from __future__ import annotations

import os
import time
from collections.abc import Awaitable, Callable
from typing import Any

from deepr.backends.capacity import (
    _OLLAMA_DEFAULT_URL,
    ollama_status,
    validate_owned_local_ollama_cloud_status,
    validate_owned_local_ollama_url,
)
from deepr.backends.context_building import (
    ContextBuilder,
    build_context,
    context_evidence_fields,
    context_generation_readiness,
    context_not_ready_error,
)
from deepr.backends.embedding_profiles import EmbeddingIdentity
from deepr.experts.semantic_model_gate import require_zero_dollar_client

# research_fn seam contract (deepr/experts/sync.py): (query, budget) -> result.
ResearchFn = Callable[[str, float], Awaitable[dict[str, Any]]]

# embed_claims seam contract (deepr/experts/belief_embedding_refresh.py):
# ordered claim texts in, one vector per claim out, same order.
EmbedClaimsFn = Callable[[list[str]], Awaitable[list[tuple[float, ...]]]]

# Keep the model resident between calls. Ollama evicts after ~5 min idle by
# default, so a multi-call workload (a sync with several subscriptions, or a
# spaced probe) pays a full cold reload of the weights each time - e.g. ~60s to
# page a 19 GB model back into VRAM on an otherwise-idle GPU. Passing keep_alive
# on every request pins it warm for the window; "-1" would pin indefinitely.
# Ollama reads this from the request body even on its OpenAI-compatible /v1
# endpoint; a server that ignores it simply falls back to the default.
_KEEP_ALIVE = os.getenv("DEEPR_OLLAMA_KEEP_ALIVE", "30m")


async def _guard_and_sanitize_ollama_request(request: Any) -> None:
    """Prove server cloud is disabled and strip ambient provider headers."""
    import httpx

    netloc = request.url.netloc
    rendered_netloc = netloc.decode("ascii") if isinstance(netloc, bytes) else str(netloc)
    endpoint = validate_owned_local_ollama_url(f"{request.url.scheme}://{rendered_netloc}")
    async with httpx.AsyncClient(
        timeout=5.0,
        trust_env=False,
        follow_redirects=False,
        headers={"Accept": "application/json", "User-Agent": "deepr-local-capacity-guard/1"},
    ) as guard:
        response = await guard.get(f"{endpoint}/api/status")
    if response.status_code != 200:
        raise ValueError(f"Owned local Ollama cloud-disable proof returned HTTP {response.status_code}")
    try:
        payload = response.json()
    except ValueError as exc:
        raise ValueError("Owned local Ollama cloud-disable proof was not JSON") from exc
    if not isinstance(payload, dict):
        raise ValueError("Owned local Ollama cloud-disable proof must be an object")
    validate_owned_local_ollama_cloud_status(payload)

    content_length = request.headers.get("content-length")
    request.headers.clear()
    request.headers.update(
        {
            "Accept": "application/json",
            "Authorization": "Bearer ollama",
            "Content-Type": "application/json",
            "Host": rendered_netloc,
            "User-Agent": "deepr-local-ollama/1",
        }
    )
    if content_length:
        request.headers["Content-Length"] = content_length


def _base_url(base_url: str | None) -> str:
    """Resolve and validate the owned Ollama URL (arg > env > default)."""
    return validate_owned_local_ollama_url(base_url or os.getenv("OLLAMA_HOST") or _OLLAMA_DEFAULT_URL)


def ollama_chat_client(base_url: str | None = None, *, timeout: float | None = None) -> Any:
    """An AsyncOpenAI client pointed at Ollama's OpenAI-compatible endpoint.

    Usable anywhere deepr injects a chat ``client`` (report_absorber,
    reflection, local web research). The api_key is a required-but-ignored
    placeholder; nothing is billed - calls hit the local server.

    Local generation is intentionally allowed to be slow - a large model on a
    long context can run at well under 1 token/sec, and that is fine for
    unattended $0 work. The OpenAI SDK's 600s default timeout would abort such a
    legitimate run, so default to a generous timeout (``DEEPR_LOCAL_TIMEOUT``
    seconds, default 3600). Raise ``DEEPR_LOCAL_TIMEOUT`` for very slow runs.
    """
    import httpx2
    from openai import AsyncOpenAI

    if timeout is None:
        timeout = float(os.getenv("DEEPR_LOCAL_TIMEOUT", "3600"))
    http_client = httpx2.AsyncClient(
        timeout=timeout,
        trust_env=False,
        follow_redirects=False,
        event_hooks={"request": [_guard_and_sanitize_ollama_request]},
    )
    client = AsyncOpenAI(
        base_url=f"{_base_url(base_url)}/v1",
        api_key="ollama",
        timeout=timeout,
        max_retries=0,
        http_client=http_client,
        organization="",
        project="",
        default_headers={"Authorization": "Bearer ollama"},
    )
    from deepr.experts.semantic_model_gate import _mark_zero_dollar_client

    return _mark_zero_dollar_client(client, capacity_source="local")


async def release_local_model(model: str, base_url: str | None = None) -> bool:
    """Ask Ollama to unload ``model`` now, freeing VRAM.

    ``_KEEP_ALIVE`` pins weights warm so a multi-call workload does not pay a
    cold reload between calls. That is right during a run and rude after it: a
    19 GB model sitting in VRAM for the rest of the keep-alive window blocks
    every other GPU user on the machine, including a short probe that needed the
    model for one second.

    So the contract is: pin during the workload, release at the end. Callers that
    finish a bounded run should call this in a ``finally``. Best effort - if the
    server is gone or ignores the field, the keep-alive window simply expires as
    before, so failing here is never worth surfacing as an error.
    """
    import httpx

    try:
        async with httpx.AsyncClient(timeout=10.0, trust_env=False, follow_redirects=False) as client:
            response = await client.post(
                f"{_base_url(base_url)}/api/generate",
                json={"model": model, "keep_alive": 0, "prompt": ""},
            )
        return response.status_code < 400
    except Exception:
        return False


async def local_model_runs_on_gpu(model: str, base_url: str | None = None) -> tuple[bool | None, str]:
    """Report whether a loaded model is resident on GPU. Returns (on_gpu, detail).

    A model whose weights plus context exceed available VRAM is silently placed
    on CPU by Ollama, where a study pass that would take minutes instead takes
    many hours. "$0 local" stays literally true and becomes practically
    unusable, and the operator has no way to tell from Deepr's output. This makes
    it visible so a run can be redirected to a smaller model or a shorter
    context rather than appearing to hang.
    """
    import httpx

    try:
        async with httpx.AsyncClient(timeout=10.0, trust_env=False, follow_redirects=False) as client:
            response = await client.get(f"{_base_url(base_url)}/api/ps")
        if response.status_code >= 400:
            return None, "could not determine whether the model is on GPU"
        for entry in (response.json() or {}).get("models") or []:
            if entry.get("name") != model and entry.get("model") != model:
                continue
            total = int(entry.get("size") or 0)
            on_gpu = int(entry.get("size_vram") or 0)
            if total <= 0:
                return None, "could not determine whether the model is on GPU"
            gpu_share = on_gpu / total
            if gpu_share >= 0.99:
                return True, ""
            return False, (
                f"{model} is {(1 - gpu_share) * 100:.0f}% on CPU "
                f"({on_gpu / 1e9:.1f} GB of {total / 1e9:.1f} GB in VRAM). "
                "Expect it to be many times slower than a GPU-resident run; "
                "consider a smaller model or a shorter --max-corpus-chars."
            )
    except Exception:
        return None, "could not determine whether the model is on GPU"
    return None, ""


def _status_model_names(detail: str) -> list[str]:
    """Parse ``ollama_status`` detail into installed model names, in list order."""
    if "model(s): " not in detail:
        return []
    rest = detail.split("model(s): ", 1)[1]
    if rest.endswith("..."):
        rest = rest[: -len("...")]
    return [part.strip().rstrip(".") for part in rest.split(",") if part.strip() and part.strip() != "..."]


def default_local_model(base_url: str | None = None, *, task_class: str = "extraction") -> str | None:
    """Pick a local model: env override, then task-class hygiene over list order.

    ``DEEPR_LOCAL_MODEL`` always wins. Coder and thinking tags are skipped for
    extraction/synthesis when a general instruct model is installed, so an
    80B coder MoE is not the silent default for absorb or consult. Entailment
    callers may pass ``task_class="entailment"`` to refuse coder-only lists.
    """
    url = _base_url(base_url)
    explicit = os.getenv("DEEPR_LOCAL_MODEL")
    if explicit:
        return explicit
    running, detail = ollama_status(url)
    if not running:
        return None
    names = _status_model_names(detail)
    if not names:
        return None
    from deepr.backends.local_fit import prefer_local_model

    return prefer_local_model(names, task_class=task_class) or names[0]


async def default_local_model_async(
    base_url: str | None = None,
    *,
    timeout: float = 0.5,
    task_class: str = "extraction",
) -> str | None:
    """Resolve the default local model through a cancellable bounded probe."""
    url = _base_url(base_url)
    explicit = os.getenv("DEEPR_LOCAL_MODEL")
    if explicit:
        return explicit
    try:
        import httpx

        async with httpx.AsyncClient(timeout=timeout, trust_env=False, follow_redirects=False) as client:
            response = await client.get(f"{url}/api/tags")
            response.raise_for_status()
        payload = response.json()
        models = payload.get("models", []) if isinstance(payload, dict) else []
        names = [
            str(model.get("name", "") or "").strip()
            for model in models
            if isinstance(model, dict) and str(model.get("name", "") or "").strip()
        ]
        if not names:
            return None
        from deepr.backends.local_fit import prefer_local_model

        return prefer_local_model(names, task_class=task_class) or names[0]
    except Exception:
        return None
    return None


def _maintenance_model_preference(profile: object | None, explicit_model: str | None) -> str | None:
    selected = (explicit_model or "").strip()
    if selected:
        return selected
    provider = str(getattr(profile, "provider", "") or "").strip().lower()
    recorded = str(getattr(profile, "model", "") or "").strip()
    return recorded if provider == "local" and recorded and recorded.lower() != "ollama" else None


def resolve_local_maintenance_model(
    profile: object | None,
    *,
    explicit_model: str | None = None,
    base_url: str | None = None,
) -> str | None:
    """Resolve operation model, then a local profile, then the global default.

    Explicit and recorded models remain pinned. Non-local and placeholder
    profiles retain the existing environment/inventory choice.
    """
    owned_base_url = _base_url(base_url)
    selected = _maintenance_model_preference(profile, explicit_model)
    if selected:
        return selected
    # Preserve the established no-argument discovery seam after validating URL.
    return default_local_model() if base_url is None else default_local_model(owned_base_url)


async def resolve_local_maintenance_model_async(
    profile: object | None,
    *,
    explicit_model: str | None = None,
    base_url: str | None = None,
) -> str | None:
    """Apply the same maintenance precedence with cancellable inventory discovery."""
    owned_base_url = _base_url(base_url)
    selected = _maintenance_model_preference(profile, explicit_model)
    if selected:
        return selected
    if base_url is None:
        return await default_local_model_async()
    return await default_local_model_async(owned_base_url)


def _local_prompt(query: str, context: Any | None) -> tuple[str, dict[str, Any] | None]:
    if context is None:
        return query, None
    if hasattr(context, "to_prompt_context"):
        prompt_context = context.to_prompt_context()
        metadata = context.to_metadata() if hasattr(context, "to_metadata") else None
    else:
        prompt_context = str(context)
        metadata = None
    return (
        f"{prompt_context}\n\n## User query\n{query}\n\n"
        "Answer the query using the fresh retrieval context when it is relevant. "
        "For current factual claims, cite source labels from the context. "
        "For deep-context runs, synthesize across sources, name meaningful gaps, "
        "and avoid unsupported claims. If fresh context is unavailable or "
        "insufficient, say so.",
        metadata,
    )


def make_local_embedder(
    model: str,
    *,
    base_url: str | None = None,
    client: Any | None = None,
    profile: str = "none",
    role: str = "document",
    dimensions: int | None = None,
    get_json: Callable[[str, float], Awaitable[dict[str, Any]]] | None = None,
    identity: EmbeddingIdentity | None = None,
    attempt_receipts: list[dict[str, Any]] | None = None,
) -> EmbedClaimsFn:
    """Build a role-aware, durably recorded local $0 embedding batcher.

    Raw input remains the default. Profile and dimension changes require an
    explicit index refresh; there is no metered fallback or automatic pull.
    Calls share the first attested digest and vector dimensions. Pass one
    identity across query/document factories to pin the same embedding space.
    Optional content-free receipts reference the canonical local attempt ledger.
    """
    import asyncio

    from deepr.backends.embedding_profiles import resolve_embedding_profile
    from deepr.experts.investigation.ollama_backend import NativeOllamaInvestigationBackend
    from deepr.observability.local_attempts import LocalGenerationAttempt

    chosen = model.strip()
    if not chosen:
        raise ValueError("embedding model is required")
    spec = resolve_embedding_profile(chosen, profile, dimensions)
    spec.prepare("", role)
    bound = identity or EmbeddingIdentity(chosen, spec.name, dimensions=spec.dimensions)
    bound.require_profile(chosen, spec)
    owned_base_url = _base_url(base_url)
    embeddings_client = client if client is not None else ollama_chat_client(owned_base_url)
    require_zero_dollar_client(embeddings_client, capacity_source="local")
    proof = NativeOllamaInvestigationBackend(model=chosen, base_url=owned_base_url, get_json=get_json)

    async def embed_claims(claims: list[str]) -> list[tuple[float, ...]]:
        if not claims:
            return []
        started = time.perf_counter()
        attempt: LocalGenerationAttempt | None = None
        receipt: dict[str, Any] = {
            "model": chosen,
            "profile": spec.name,
            "role": role,
            "status": "unsettled",
            "accounting": "unsettled",
            "tokens_input": None,
            "cost_usd": 0.0,
            "input_count": len(claims),
        }
        try:
            attempt = LocalGenerationAttempt(chosen, kind="embedding")
            receipt.update(
                attempt_id=attempt.attempt_id,
                request_id=attempt.request_id,
                ledger_path=str(attempt.ledger.ledger_path.resolve()),
                cost_state_id=attempt.ledger.cost_state_id,
            )
            inputs = [spec.prepare(text, role) for text in claims]
            proof.pinned_digest = bound.digest
            digest = await proof.attest_model(chosen)
            bound.bind(digest)
            attempt.dispatch(digest)
            response = await embeddings_client.embeddings.create(
                model=chosen,
                input=inputs,
                extra_body={"keep_alive": _KEEP_ALIVE},
            )
            usage = getattr(response, "usage", None)
            reported_tokens = getattr(usage, "prompt_tokens", None)
            if reported_tokens is not None:
                receipt["tokens_input"] = max(0, int(reported_tokens))
            vectors = spec.ordered_vectors([(row.index, row.embedding) for row in response.data], len(claims))
            receipt["response_dimensions"] = [len(vector) for vector in vectors]
            bound.bind(digest, len(vectors[0]))
        except BaseException as error:
            status = (
                "cancelled"
                if isinstance(error, asyncio.CancelledError)
                else "failed"
                if attempt is not None and attempt.dispatched
                else "refused"
            )
            receipt.update(status=status, error_type=type(error).__name__)
            if attempt is not None:
                attempt.finish(status, tokens_input=receipt["tokens_input"] or 0, error_type=type(error).__name__)
                receipt["accounting"] = "recorded"
            raise
        else:
            attempt.finish("returned", tokens_input=receipt["tokens_input"] or 0)
            receipt.update(status="returned", accounting="recorded")
            return vectors
        finally:
            receipt.update(
                model_digest=proof.last_attested_digest,
                dimensions=bound.dimensions,
                elapsed_ms=round((time.perf_counter() - started) * 1000, 3),
            )
            if attempt_receipts is not None:
                attempt_receipts.append(receipt)

    return embed_claims


def make_local_research_fn(
    model: str,
    *,
    base_url: str | None = None,
    client: Any | None = None,
    context_builder: ContextBuilder | None = None,
) -> ResearchFn:
    """Build a ``research_fn`` that answers via a local Ollama model at $0.

    Satisfies the sync/gap-fill seam: ``(query, budget) -> {"answer", "cost"}``.
    Cost is always 0.0 (owned hardware); ``budget`` is ignored. Errors are
    returned in the result, never raised, matching the seam's contract.
    """
    owned_base_url = _base_url(base_url)
    chat = client if client is not None else ollama_chat_client(owned_base_url)
    require_zero_dollar_client(chat, capacity_source="local")

    async def research_fn(
        query: str,
        budget: float,
        *,
        prior_source_pack: dict[str, Any] | None = None,
        retrieval_query: str | None = None,
    ) -> dict[str, Any]:
        try:
            context = await build_context(
                context_builder,
                retrieval_query or query,
                prior_source_pack=prior_source_pack,
            )
            evidence_fields = context_evidence_fields(context)
            readiness = context_generation_readiness(context)
            if readiness is not None and not readiness.ready:
                return {
                    "answer": "",
                    "cost": 0.0,
                    "error": context_not_ready_error(readiness),
                    "error_code": "fresh_context_not_ready",
                    "retryable": readiness.retryable,
                    "no_metered_fallback": readiness.no_metered_fallback,
                    "context_preflight": readiness.to_dict(),
                    **evidence_fields,
                }
            prompt, metadata = _local_prompt(query, context)
            response = await chat.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                extra_body={"keep_alive": _KEEP_ALIVE},
            )
            answer = response.choices[0].message.content or ""
            result: dict[str, Any] = {"answer": answer, "cost": 0.0}
            result.update(evidence_fields)
            if metadata is not None and "fresh_context" not in result:
                result["fresh_context"] = metadata
            return result
        except Exception as e:  # seam contract: report, do not raise
            return {"answer": "", "cost": 0.0, "error": f"local model error: {e}"}

    return research_fn


async def probe_local(
    model: str | None = None, *, base_url: str | None = None, client: Any | None = None
) -> dict[str, Any]:
    """A $0 round-trip to the local model to prove the backend actually works.

    Returns ``{ok, model, reply, latency_ms, error}``. Never raises.
    """
    try:
        owned_base_url = _base_url(base_url)
    except ValueError as error:
        return {"ok": False, "model": model, "reply": "", "latency_ms": 0, "error": str(error)}
    chosen = model or default_local_model(owned_base_url)
    if not chosen:
        return {"ok": False, "model": None, "reply": "", "latency_ms": 0, "error": "no local model available"}

    chat = client if client is not None else ollama_chat_client(owned_base_url)
    start = time.perf_counter()
    try:
        require_zero_dollar_client(chat, capacity_source="local")
        response = await chat.chat.completions.create(
            model=chosen,
            messages=[{"role": "user", "content": "Reply with exactly: OK"}],
            max_tokens=16,
            extra_body={"keep_alive": _KEEP_ALIVE},
        )
        reply = (response.choices[0].message.content or "").strip()
        return {
            "ok": True,
            "model": chosen,
            "reply": reply,
            "latency_ms": int((time.perf_counter() - start) * 1000),
            "error": "",
        }
    except Exception as e:
        return {
            "ok": False,
            "model": chosen,
            "reply": "",
            "latency_ms": int((time.perf_counter() - start) * 1000),
            "error": str(e),
        }
