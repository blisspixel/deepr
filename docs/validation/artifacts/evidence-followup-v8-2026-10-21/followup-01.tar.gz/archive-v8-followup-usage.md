# V8 archive preparation and later operator workflow

Preparation only. These helpers made no native/model/provider calls and did not
read real keys or experimental answer/judgment rows. No real V8 config or export
was prepared. Existing V5/V6/V7 helpers, configs, ledgers and archives are not
modified. Prior V7 remains a negative archived trial whatever V8 later shows.

The real export requires all 24 terminal V8 consult cells, 56 final primary
labels, 12 complete matched pairs, all 36 independent whole-pair judgments,
legitimate primary and quality first-open receipts, the completed actual V8
resource audit and root's canonical issue258-v8-semantic-assessment.json.
The final assessment must bind the completed source recipe, 24 fresh consults,
eight prior briefs, both pre-key freezes and a timezone-aware assessment time
no earlier than quality opening. Its nonempty disposition may be positive or
negative. Archive admission does not decide or reinterpret that disposition.
Missing or unfinished stages refuse before archive key reads.

The V8 resource auditor is separately owned by R2:
audit_native_resources_v8.py writes v8-native-resource-audit.json only after
root declares collection complete and invokes its --collection-complete CLI.
Archive preparation does not run it. Its guard/check artifacts are
check_resources_v8_R2.py, reviewers/R2/resources-v8-synthetic-checks.json and
v8-resource-auditor-preparation-receipt.json. Four prior ledgers retain 180
attempts; full V8 adds 24 for 204. Partial usage remains unknown rather than
zero. Hardware and review-service costs are unknown, not implied by local API
price zero.

R3 has prepared and hash-bound the actual review-helper sources:
review258_v8_primary.py, prepare_v8_material_review.py and
freeze_pair_quality_v8.py. Their preparation receipt is retained as
reviewers/R3/v8-review-helper-preparation.json. The inventory requires their
actual files. Final
primary outputs are review258-v8-final-blind-freeze.json and
review258-v8-final-labels.json. Material outputs live under material-review-v8/:
primary-key-open-receipt.json, blinded-pairs.json, input-freeze.json,
quality-freeze/FREEZE.json, quality-key-open-receipt.json and
reviewed-whole-pairs.json. No unused derivative comparison summary is required.
The actual quality freeze adds quality-calibration-admission.json to its
snapshot set. The archive checks this against the root quality admission and
checks primary collection/calibration bindings against the exact archived
protocol, manifest, collector, completion, authority and primary admission.
If actual review interfaces change again, inspect the sources and reconcile them
before preparing a real config; do not fabricate missing artifacts.

After every stage exists, independently verify the exact reviewed helper SHA
and the completed V5, V6 and V7 published index/COMPLETE bindings. Supply their
literal SHA256 values to the separate metadata-only inventory builder:

```text
python .agent/issue-completion-2026-10-20/prepare_archive_v8_allowlist.py \
  --helper-sha256 REVIEWED_ARCHIVE_V8_HELPER_SHA256 \
  --prior-v5-index-sha256 VERIFIED_PUBLISHED_V5_INDEX_SHA256 \
  --prior-v6-index-sha256 VERIFIED_PUBLISHED_V6_INDEX_SHA256 \
  --prior-v7-index-sha256 VERIFIED_PUBLISHED_V7_INDEX_SHA256
```

It exclusively writes archive-v8-allowlist.json. Inspect that exact inventory
and its SHA before export. It reads safe metadata and checks filenames; it does
not open key bytes, answer drafts or peer judgment rows. Source-final check-log
commitments are inventoried and later verified from the frozen source-final
record rather than guessed new filenames.

```text
python .agent/issue-completion-2026-10-20/archive_v8_followup.py \
  --config-sha256 REVIEWED_ARCHIVE_V8_CONFIG_SHA256
```

Only docs/validation/artifacts/evidence-followup-v8-2026-10-21 is permitted for
a real export. Existing or interrupted output is never replaced. Preserve an
actual first refusal and pre-repair helper if an actual interface discrepancy
arises; change only the discrepancy, without weakening gates.

Exactly 20 recipe modules and three extra dependencies were prospectively
captured in packing-v8-source-snapshot. The ordered owning recipe is
5a019a92edff47136f12933a4c8e9bdd9a5fb4d0e5774a37f3ae137a8aaa9437;
its hash differs from the snapshot receipt hash. Full source worlds retain
19 corpus texts. Frozen exact inputs, prompts, complete drafts including form
failures, native/accounting receipts and both review stages remain in their
full denominators. All source/check bindings and capture chronology must pass.

The eight unchanged V5 briefs remain separate component references. Both
consult_prompt.py and consult_response.py stay excluded from their equality
contract. The prior V7 reuse receipt and original component provenance chain
are retained. V5/V6/V7 canonical assessment bytes bind their prospective V8
protocol commitments, and all three published predecessor indices are copied
as references. No prior answer/call/assembly directory can enter as fresh V8
cells. The V7 negative is preserved without selecting the V8 outcome.

Keys are final reads after all freeze, source, resource, canonical assessment
and prior-reference guards. Verified bytes are cached and packed without
rereading or clipping; archived text/code is untrusted and never executed.
Parts, index and fsynced COMPLETE.json must each stay strictly below 500 KiB.
After any real export, independently rehash every member, manifests, index and
COMPLETE; verify all earlier archive files and all five trial ledgers unchanged.
Archive integrity does not establish semantic acceptance, release readiness,
S0, expertise, population transfer or memory benefit.

The isolated checks cover 51 archive guards plus four inventory checks,
including both future assessment dispositions, missing/incomplete final
assessments, wrong recipe/chronology, prior-negative mutation, fourth-prior-
ledger preservation, component separation, exact source closure and byte/size
retention. No real audit/config/export or review/key stage ran during these
checks. Earlier synthetic reports remain separate preparation history before final-
assessment metadata guards and alignment with the actual V8 review interface.
The alignment was prepared before any real export and relaxed no guard.
