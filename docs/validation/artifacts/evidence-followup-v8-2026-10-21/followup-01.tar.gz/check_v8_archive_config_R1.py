"""Positive exact-inventory preparation on isolated synthetic metadata only."""
import hashlib,json,runpy,tempfile
from pathlib import Path
from datetime import datetime,timezone
T=Path(__file__).resolve().parent
H=lambda raw:hashlib.sha256(raw).hexdigest()
M=runpy.run_path(str(T/'check_archive_v8_followup_R1.py'),run_name='synthetic_fixture_definition')
P=runpy.run_path(str(T/'prepare_archive_v8_allowlist.py'),run_name='synthetic_config_definition')


def main():
    outcomes={};original_read=Path.read_bytes
    def watched(path):
        assert path.name!='key.json','Config preparation must not read even synthetic key bytes'
        assert path.parent.name!='answers' and path.name not in {'blinded-review.json','blinded-pairs.json','review258-v8-final-labels.json','review258-v8.json'},'No answer or peer rows may be read'
        return original_read(path)
    with tempfile.TemporaryDirectory(prefix='config-v8-synthetic-R1-',dir=T/'reviewers/R1') as temporary:
        root=Path(temporary).resolve();config,values,out=M['fixture'](root)
        (root/'packing-fixtures-v8/raw-prompt-audit').mkdir()
        for name in P['FIXED']:
            path=root/name
            if not path.exists():path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'Synthetic fixed inventory file.\n')
        (root/'archive_v8_followup.py').write_bytes((T/'archive_v8_followup.py').read_bytes())
        repo=root/'repo';hashes={}
        for version in ('v5','v6','v7'):
            prior=repo/'docs/validation/artifacts'/f'evidence-followup-{version}-2026-10-21'
            prior.mkdir(parents=True);(prior/'index.json').write_bytes(b'{"synthetic":true}\n');(prior/'COMPLETE.json').write_bytes(b'{}\n')
            hashes[version]=H((prior/'index.json').read_bytes())
        globals_=P['build'].__globals__;old_repo=globals_['REPO'];globals_['REPO']=repo
        try:
            Path.read_bytes=watched
            raw=P['build'](root,H((root/'archive_v8_followup.py').read_bytes()),hashes['v5'],hashes['v6'],hashes['v7'],out)
        finally:Path.read_bytes=original_read;globals_['REPO']=old_repo
        prepared=json.loads(raw)
        assert set(prepared['files'])==set(values)|set(P['FIXED'])
        assert len(prepared['current_recipe_paths'])==20 and len(prepared['extra_recipe_paths'])==3
        assert 'review258-v8-reviewed-comparison.json' not in prepared['files']
        assert all(name in prepared['files'] for name in ('review258-v8-final-labels.json','review258-v8-final-blind-freeze.json','issue258-v8-semantic-assessment.json'))
        outcomes['exact_positive_inventory20plus3_and_canonical_outputs']='passed'
        outcomes['no_unused_derivative_comparison_required']='passed'
        outcomes['no_key_answer_or_judgment_rows_read_by_preparation']='passed'
        outcomes['no_config_or_public_output_written_by_build']='passed'
        assert not out.exists() and not (root/'archive-v8-allowlist.json').exists()
    receipt={'checked_at':datetime.now(timezone.utc).isoformat(),'checks':outcomes,'model_calls':0,'actual_config_prepared':False,
        'config_recipe_sha256':H((T/'prepare_archive_v8_allowlist.py').read_bytes()),'builder_sha256':H((T/'archive_v8_followup.py').read_bytes())}
    path=T/'reviewers/R1/archive-v8-config-synthetic-checks.json'
    with path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps({'report':str(path),'checks':len(outcomes),'actual_config_prepared':False}))


if __name__=='__main__':main()
