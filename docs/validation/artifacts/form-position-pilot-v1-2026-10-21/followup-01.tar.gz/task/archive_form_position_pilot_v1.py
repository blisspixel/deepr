"""Explicit post-assessment pilot byte archive. No dispatch or semantic verdict."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import argparse,gzip,hashlib,io,json,os,stat,tarfile

T=Path(__file__).resolve().parent
REPO=T.parent.parent
P=T/'form-position-pilot-v1'
OUT=REPO/'docs/validation/artifacts/form-position-pilot-v1-2026-10-21'
INVENTORY=T/'form-position-pilot-v1-archive-inventory.json'
LIMIT=500*1024
KEY='pilot/position-key-unopened/key.json'
CACHES={'__pycache__','.pytest_cache','.mypy_cache','.ruff_cache'}
TASK_FILES=(
 'quality-review-v6-instructions.txt','review-instructions-v3.txt','agent-calibration-inputs.json','agent-calibration-freeze.json',
 'reviewer-v8-calibration-admission.json','reviewer-v8-calibration-mechanical-validation.json','validate_v8_calibrations.py','v8_guards.py',
 'reviewers/R1/calibration-v8-fresh.json','reviewers/R1/calibration-v8-fresh-receipt.json',
 'reviewers/R2/calibration-v8-fresh.json','reviewers/R2/calibration-v8-fresh-receipt.json',
 'v8-review-protocol.json','v8-source-final.json','packing-v8-source-snapshot-receipt.json',
 'packing-v8-prospective-extras-receipt.json','packing-v8-source-recipe-proof.json',
 'packing-fixtures-v8/4c94cd3900e453bf.input.json','v8-runtime/calls/008.4c94cd3900e453bf.request.json',
 'reviewers/R3/post-v8-form-boundary-proposal.json',
 'issue258-v5-semantic-assessment.json','issue258-v6-semantic-assessment.json','issue258-v7-semantic-assessment.json','issue258-v8-semantic-assessment.json',
 'reviewers/R1/archive-v8-independent-verification.json','reviewers/R1/archive-v8-before-export.json',
 'archive_form_position_pilot_v1.py','reviewers/R1/pilot-archive-preparation.json',
 'rejected-v6-v8-product-candidate.patch','rejected-v6-v8-product-candidate.json',
)

def require(ok,message):
 if not ok:raise ValueError(message)

def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def obj(path):return json.loads(raw_file(path,T if path.is_relative_to(T) else REPO))
def instant(value):
 parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
 require(parsed.tzinfo is not None,'Timezone-aware receipt required');return parsed

def safe_name(name,keys=False):
 path=PurePosixPath(name)
 require(name and not path.is_absolute() and str(path)==name and '\\' not in name and '..' not in path.parts,'Unsafe archive path')
 for part in path.parts:
  low=part.lower()
  require(low not in {'s0','research_notes','notes','.env','secrets','credentials'} and not low.startswith('private'),'Private/S0/notes/credential path refused')
 if any(part=='key.json' or 'key-unopened' in part for part in path.parts):require(keys and name==KEY,'Only sole pilot key allowed after gates')
 return name

def raw_file(path,root):
 require(path.is_relative_to(root) and '..' not in path.parts and path.resolve().is_relative_to(root.resolve()),'Input outside explicit root')
 for q in [path,*path.parents]:
  if q==root.parent:break
  require(not q.is_symlink(),'Symlink input refused')
 require(path.is_file() and stat.S_ISREG(path.stat().st_mode),'Required regular input absent: '+str(path))
 return path.read_bytes()

def pilot_paths(p):
 names=[]
 for path in sorted(p.rglob('*')):
  rel=path.relative_to(p)
  if any(x in CACHES for x in rel.parts) or path.suffix in {'.pyc','.pyo'}:continue
  require(not path.is_symlink(),'Symlink in pilot tree refused')
  if path.is_file():safe_name('pilot/'+rel.as_posix(),keys=True);names.append(rel.as_posix())
 return names

def gates(p,t,repo,assessment_sha):
 assessment=obj(p/'root-assessment.json');require(sha(raw_file(p/'root-assessment.json',p))==assessment_sha,'Canonical root assessment changed')
 freeze=obj(p/'pair-review/quality-freeze/FREEZE.json');opened=obj(p/'position-key-open-receipt.json')
 require(assessment['all_four_judgments_frozen_before_key'] is True and opened['all_four_judgments_frozen_before_key'] is True,'All judgments must precede lawful key opening')
 require(freeze['judgments_frozen']==4 and freeze['scheduled_cells']==4 and freeze['independent_review_inputs']==freeze['pairs_per_reviewer']==2,'Complete four-judgment freeze required')
 require(freeze['position_key_read_by_helper'] is False and opened['all_frozen_snapshot_hashes_verified'] is True,'Frozen-review/open attestations required')
 require(opened['quality_freeze_sha256']==sha(raw_file(p/'pair-review/quality-freeze/FREEZE.json',p)),'Lawful opening binds different freeze')
 require(opened['input_freeze_sha256']==sha(raw_file(p/'pair-review/input-freeze.json',p)),'Lawful opening binds different inputs')
 require(instant(freeze['frozen_at'])<=instant(opened['opened_at'])<=instant(assessment['assessed_at'])<=datetime.now(timezone.utc),'Freeze/open/assessment chronology differs')
 require(type(assessment['semantic_acceptance']) is bool,'Actual assessed disposition required; either outcome allowed')
 report=obj(p/'native-resource-audit.json');complete=obj(p/'inputs/answers-complete.json')
 require(report['accounting_complete'] is True and report['scheduled_cells']==report['terminal_cells']==complete['terminal_answers']==complete['answers_scheduled']==4,'Complete actual resource audit required')
 protocol=obj(p/'protocol.json');snap=obj(p/'source-snapshot-receipt.json')
 require(snap['prospective'] is True and len(snap['source_modules'])==20 and len(snap['extra_source_modules'])==3 and snap['source_count']==23,'Original prospective20plus3 snapshot required')
 require(snap['source_modules']==protocol['source_modules'] and snap['extra_source_modules']==protocol['extra_source_modules'],'Prospective source closure differs')
 recipe=hashlib.sha256()
 for name,expected in protocol['source_modules'].items():
  live=raw_file(repo/name,repo);saved=raw_file(p/'source-snapshot'/name,p)
  require(sha(live)==sha(saved)==expected,'Live V8/prospective source bytes differ: '+name)
  recipe.update(name.removeprefix('src/').encode());recipe.update(saved)
 for name,expected in protocol['extra_source_modules'].items():
  require(sha(raw_file(repo/name,repo))==sha(raw_file(p/'source-snapshot'/name,p))==expected,'Extra source bytes differ: '+name)
 require(recipe.hexdigest()==protocol['source_recipe_sha256']==snap['source_recipe_sha256'],'Owning source recipe differs')
 for name,expected in protocol['prior_ledgers'].items():require(sha(raw_file(t/name,t))==expected,'Prior ledger changed: '+name)
 require(sha(raw_file(p/'runtime/costs/cost_ledger.jsonl',p))==report['native_ledger_sha256'],'Pilot ledger changed')
 return assessment,freeze,opened,protocol

def capture(p,t,repo,assessment_sha,task_files=TASK_FILES):
 assessment,freeze,opened,protocol=gates(p,t,repo,assessment_sha)
 names=pilot_paths(p);values={}
 # Key is the last byte read, after all original/corrected review snapshots bind.
 for name in names:
  dest='pilot/'+name
  if dest!=KEY:values[dest]=raw_file(p/name,p)
 for name in task_files:
  dest=safe_name('task/'+name);values[dest]=raw_file(t/name,t)
 for name,expected in protocol['source_references'].items():require(sha(values['task/'+name])==expected,'Explicit dependency commitment differs: '+name)
 for name,expected in protocol['review_controls'].items():require(sha(values['task/'+name])==expected,'Substantive/calibration control changed: '+name)
 admission=json.loads(values['task/reviewer-v8-calibration-admission.json'])
 require(sha(values['task/reviewer-v8-calibration-admission.json'])==protocol['reused_primary_calibration_admission']['sha256'],'Reused admission changed')
 require(sha(values['task/reviewer-v8-calibration-mechanical-validation.json'])==admission['mechanical_validation_sha256'],'Calibration provenance changed')
 for row in admission['reviewers']:
  who=row['reviewer']
  if who in ('R1','R2'):
   require(sha(values['task/reviewers/'+who+'/calibration-v8-fresh.json'])==row['output_sha256'],'Reused calibration output changed')
   require(sha(values['task/reviewers/'+who+'/calibration-v8-fresh-receipt.json'])==row['receipt_sha256'],'Reused calibration receipt changed')
 for name,expected in assessment['artifacts_sha256'].items():require(sha(values['pilot/'+name])==expected,'Root assessment artifact changed: '+name)
 for name,expected in freeze['snapshots_sha256'].items():require(sha(values['pilot/pair-review/quality-freeze/snapshots/'+name])==expected,'Frozen original review/snapshot changed: '+name)
 require(sha(values['task/v8_guards.py'])==protocol['tool_modules']['../v8_guards.py'],'External helper dependency changed')
 for name,expected in protocol['prior_negative_assessments_sha256'].items():require(sha(values['task/'+name])==expected,'Prior negative changed')
 require(sha(values['pilot/prospective-design.md'])==sha(values['pilot/design-reconstructed-after-collection.md'])==protocol['design_sha256'],'Reconstructed committed design differs')
 require(sha(values['pilot/design-reconstruction-receipt.json'])=='aa7c60fb3d1b30c49b841c74b969d67a1bbee0193bb3a653ff35716eaf51b73a','Postcollection design reconstruction provenance differs')
 public_before=json.loads(values['task/reviewers/R1/archive-v8-before-export.json'])['prior_public_files']
 priors=dict(public_before)
 for name,expected in protocol['archive_seal'].items():
  require(sha(raw_file(repo/name,repo))==expected,'Frozen V8 archive reference changed')
  if name.startswith('docs/'):
   priors[name]=expected
   if name.endswith(('index.json','COMPLETE.json')):values['reference/'+name]=raw_file(repo/name,repo)
 for name,expected in priors.items():require(sha(raw_file(repo/name,repo))==expected,'Prior public archive changed: '+name)
 values[KEY]=raw_file(p/'position-key-unopened/key.json',p)
 require(sha(values[KEY])==opened['key_sha256']==obj(p/'input-freeze.json')['key_sha256'],'Sole already-opened key hash differs')
 return values,priors


def archive_bytes(values):
    manifest = {'files': {name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in sorted(values.items())},
                'scope': 'Exact completed form-position pilot evidence, original and corrected envelopes, four frozen judgments and reused calibration provenance. No policy or release acceptance.'}
    manifest_raw = encode(manifest)
    payloads = {**values, 'MANIFEST.json': manifest_raw}
    stream = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(payloads.items()):
                safe_name(name, keys=True)
                info = tarfile.TarInfo(name)
                info.size = len(raw); info.mtime = 0; info.mode = 0o644; info.uid = info.gid = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(raw))
    return stream.getvalue(), manifest_raw, payloads


def fsync_dir(path):
    handle = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(handle)
    finally:
        os.close(handle)


def write(path, raw):
    with path.open('xb') as handle:
        handle.write(raw); handle.flush(); os.fsync(handle.fileno())


def publish(out, selected):
    chunks, chunk = [], {}
    for name, raw in sorted(selected.items()):
        trial = {**chunk, name: raw}
        if len(archive_bytes(trial)[0]) > 480 * 1024 and chunk:
            chunks.append(chunk); chunk = {name: raw}
        else:
            chunk = trial
    if chunk:
        chunks.append(chunk)
    prepared, index = {}, {}
    for number, values in enumerate(chunks, 1):
        packed, manifest, payloads = archive_bytes(values)
        require(len(packed) < LIMIT, 'Oversized evidence file: refuse, never drop or clip')
        name = f'followup-{number:02d}.tar.gz'
        prepared[name] = packed
        with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as tar:
            require([member.name for member in tar.getmembers()] == sorted(payloads), 'Archive member mismatch')
            for member, raw in payloads.items():
                require(tar.extractfile(member).read() == raw, 'Archive exact-byte mismatch')
        index[name] = {'sha256': sha(packed), 'bytes': len(packed), 'evidence_files': len(values), 'manifest_sha256': sha(manifest)}
    index_raw = encode({'archives': index, 'source_files': len(selected), 'source_bytes_preserved': True,
                        'builder_sha256': sha(Path(__file__).read_bytes()), 'semantic_acceptance': None})
    require(len(index_raw) < LIMIT, 'Index exceeds artifact gate')
    complete = encode({'index_sha256': sha(index_raw), 'archive_count': len(prepared), 'source_files': len(selected),
                       'completed_at': datetime.now(timezone.utc).isoformat(), 'semantic_acceptance': None})
    require(len(complete) < LIMIT, 'Completion receipt exceeds artifact gate')
    # mkdir is the exclusive reservation: an existing directory is never renamed,
    # replaced or edited. Interrupted output stays visible and blocks a retry.
    out.mkdir()
    fsync_dir(out.parent)
    for name, raw in prepared.items():
        write(out / name, raw)
    write(out / 'index.json', index_raw)
    fsync_dir(out)
    write(out / 'COMPLETE.json', complete)
    fsync_dir(out); fsync_dir(out.parent)
    return {'output': str(out), 'archives': len(prepared), 'source_files': len(selected), 'semantic_acceptance': None}


def inventory_rows(values):
 return {name:{'sha256':sha(raw),'bytes':len(raw)} for name,raw in sorted(values.items())}

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('stage',choices=('inventory','export'))
 parser.add_argument('--authorized-after-assessment',action='store_true',required=True)
 parser.add_argument('--assessment-sha256',required=True)
 parser.add_argument('--helper-sha256',required=True)
 parser.add_argument('--inventory-sha256')
 args=parser.parse_args()
 require(not OUT.exists(),'Exclusive archive output already exists; preserve any first attempt')
 require(sha(raw_file(Path(__file__),T))==args.helper_sha256,'Reviewed helper bytes changed')
 if args.stage=='inventory':require(not INVENTORY.exists(),'Exclusive inventory already exists')
 else:require(args.inventory_sha256 is not None,'Exact reviewed inventory SHA required')
 values,priors=capture(P,T,REPO,args.assessment_sha256)
 rows=inventory_rows(values)
 if args.stage=='inventory':
  raw=encode({'kind':'deepr.pilot-archive-explicit-inventory.v1','created_at':datetime.now(timezone.utc).isoformat(),'assessment_sha256':args.assessment_sha256,'helper_sha256':args.helper_sha256,'output':str(OUT.relative_to(REPO)),'files':rows,'prior_public_sha256':priors,'scope':'Entire completed scoped pilot excluding caches, explicit substantive/calibration/helper dependencies. Reconstructed design is postcollection hash-matching reconstruction, not a prospective capture.'})
  write(INVENTORY,raw)
  print(json.dumps({'inventory':str(INVENTORY),'sha256':sha(raw),'files':len(rows),'bytes':sum(x['bytes'] for x in rows.values()),'prior_public_files':len(priors)}))
 else:
  raw=raw_file(INVENTORY,T);require(sha(raw)==args.inventory_sha256,'Reviewed inventory changed')
  frozen=json.loads(raw)
  require(frozen['assessment_sha256']==args.assessment_sha256 and frozen['helper_sha256']==args.helper_sha256,'Inventory binding changed')
  require(frozen['output']==str(OUT.relative_to(REPO)) and frozen['files']==rows and frozen['prior_public_sha256']==priors,'Exact scoped inventory changed')
  values['EXPORT-INVENTORY.json']=raw
  result=publish(OUT,values)
  for name,expected in priors.items():require(sha(raw_file(REPO/name,REPO))==expected,'Prior public bytes changed after export')
  gates(P,T,REPO,args.assessment_sha256)
  result.update(index_sha256=sha((OUT/'index.json').read_bytes()),complete_sha256=sha((OUT/'COMPLETE.json').read_bytes()),prior_public_files_unchanged=len(priors),live_v8_source_files_verified=23)
  print(json.dumps(result))

if __name__=='__main__':main()
