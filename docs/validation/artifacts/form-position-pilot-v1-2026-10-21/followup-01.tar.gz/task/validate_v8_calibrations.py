"""Validate fresh rubric anchors; never infer semantic quality from counts."""
from pathlib import Path
from datetime import datetime, UTC
import hashlib,json,sys
T=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def validate(stage,reviewers):
    inputs=read(T/'agent-calibration-inputs.json');key=read(T/'agent-calibration-key.json')
    by_id={row['item_id']:row for row in inputs};results=[]
    assert len(inputs)==len(by_id)==16
    for reviewer in reviewers:
        p=T/'reviewers'/reviewer/'calibration-v8-fresh.json';receipt=p.with_name('calibration-v8-fresh-receipt.json')
        rows=read(p);r=read(receipt)
        assert isinstance(rows,list) and len(rows)==16 and len({row['item_id'] for row in rows})==16
        assert r['input_sha256']==h(T/'agent-calibration-inputs.json')
        assert r.get('instructions_sha256',r.get('rubric_sha256'))==h(T/'review-instructions-v3.txt') and r['output_sha256']==h(p)
        assert r['reviewer']==reviewer
        for row in rows:
            src=by_id[row['item_id']];expected=key[row['item_id']]
            assert row['reviewer']==reviewer and row['obligation_id']==expected['obligation_id']
            assert row['answer_sha256']==src['answer_sha256']==hashlib.sha256(src['answer'].encode()).hexdigest()
            assert row['answer_quote'] in src['answer'] and set(row['source_ids'])<=set(s['source_id'] for s in src['sources'])
            assert row['label']==expected['label'] and row['note'].strip()
        results.append({'reviewer':reviewer,'output_sha256':h(p),'receipt_sha256':h(receipt),'anchors':16,'matches':16,'bound_quotes_hashes_source_ids_verified':True,'rationales_inspected_by_root':False})
    out={'validated_at':datetime.now(UTC).isoformat(),'stage':stage,'controls_sha256':h(T/'agent-calibration-inputs.json'),'rubric_sha256':h(T/'review-instructions-v3.txt'),'calibration_key_sha256':h(T/'agent-calibration-key.json'),'reviewers':results,'admitted':False,'limits':'Mechanical identity and exact anchor checks only. Root must inspect all rationales and independence receipts before admission. Narrow authored anchors do not measure whole-pair accuracy. Service snapshot/usage/cost unknown; no human or zero-service-cost claim.'}
    dest=T/f'{stage}-v8-calibration-mechanical-validation.json'
    with dest.open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(out))
if __name__=='__main__':validate(sys.argv[1],sys.argv[2:])
