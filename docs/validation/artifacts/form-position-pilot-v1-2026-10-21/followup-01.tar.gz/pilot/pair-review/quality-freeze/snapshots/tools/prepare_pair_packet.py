"""Explicitly authorized offline pair packet preparation, never key access."""
from pilot_review_support import P,prepare_pairs

def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection-complete',required=True,action='store_true',help='Root has declared pilot collection complete and authorized offline packet preparation.')
    parser.parse_args()
    print(prepare_pairs(P))
if __name__=='__main__':main()
