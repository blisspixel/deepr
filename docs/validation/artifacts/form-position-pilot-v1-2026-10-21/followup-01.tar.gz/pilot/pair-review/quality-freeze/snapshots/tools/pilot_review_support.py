"""Read-only pilot joins and key-free review utilities. No semantic verdicts."""
from datetime import UTC,datetime
import hashlib
import json
import os
from pathlib import Path
import secrets
from collections import defaultdict
from pilot_guards import require, sha, digest, PRIOR_LEDGERS, PRIOR_NEGATIVES
import audit_resources

P=Path(__file__).resolve().parent
DISPOSITIONS={'no_material_difference','A_materially_worse','B_materially_worse','uncertain'}
ATTESTATIONS=('independent_pilot_judgment','reviewed_without_position_key','reviewed_without_peer_pilot_judgments','all_pairs_reviewed','prior_exposure_disclosed')
SESSIONS={'R1':'/root/primary_v8_one','R2':'/root/primary_v8_two'}
STATUSES={'completed','truncated','empty_answer','form_failed','failed','cancelled','refused_followup_bound','refused_followup_integrity'}

def unique_keys(pairs):
    out={}
    for key,value in pairs:
        require(key not in out,'Duplicate JSON key: '+key);out[key]=value
    return out

def load(path):
    path=Path(path)
    for candidate in (path,path.resolve()):
        for part in candidate.parts:
            low=part.lower()
            require(not (low=='key.json' or 'key-unopened' in low or 'method-key' in low or 'assignment-key' in low or 'position-key' in low or low.startswith('private') or low=='s0'),'Protected key/private path refused before reading')
    return json.loads(path.read_bytes(),object_pairs_hook=unique_keys)

def write(path,value):
    raw=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return hashlib.sha256(raw).hexdigest()

def timestamp(value):
    require(isinstance(value,str),'UTC timestamp text required')
    parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(parsed.tzinfo is not None and parsed.utcoffset() is not None,'Timezone-aware timestamp required')
    return parsed

def collection(root):
    root=Path(root);protocol=load(root/'protocol.json')
    require(protocol['reviewer_tasks']==SESSIONS,'Exact reused reviewer task identities required')
    report=load(root/'native-resource-audit.json')
    actual=audit_resources.audit(root)
    require({k:v for k,v in report.items() if k!='observed_at'}=={k:v for k,v in actual.items() if k!='observed_at'},'Actual resource report no longer matches collection')
    manifest=load(root/'manifest.json');complete=load(root/'inputs/answers-complete.json')
    require(complete['terminal_answers']==complete['answers_scheduled']==len(manifest['jobs'])==4,'All four terminal cells required')
    relative=('protocol.json','manifest.json','input-freeze.json','collector-freeze.json','operator-authorization.json','precollection-audit.json','inputs/answers-complete.json','native-resource-audit.json','source-snapshot-receipt.json','tooling-review-approval.json')
    bindings={name:digest(root/name) for name in relative}
    calibration=protocol['reused_primary_calibration_admission']
    require(digest(root.parent/calibration['path'])==calibration['sha256'],'Reused primary calibration admission changed')
    require(protocol['prior_ledgers']==PRIOR_LEDGERS and protocol['prior_negative_assessments_sha256']==PRIOR_NEGATIVES,'Prior evidence pins changed')
    bindings['calibration_admission_sha256']=calibration['sha256']
    bindings['whole_answer_rubric_sha256']=digest(root.parent/'quality-review-v6-instructions.txt')
    require(bindings['whole_answer_rubric_sha256']==protocol['review_controls']['quality-review-v6-instructions.txt'],'Same substantive whole-answer criterion required')
    return protocol,manifest,bindings

def packet_validate(packet):
    require(isinstance(packet,list) and len(packet)==2,'Exactly two pilot pairs required')
    ids=set();pids=set();seeds=set()
    for pair in packet:
        require(isinstance(pair.get('pair_id'),str) and pair['pair_id'] not in pids,'Unique opaque pair identities required');pids.add(pair['pair_id'])
        require(pair['kind']=='consult' and isinstance(pair['question'],str),'Consult question required')
        require(pair['seed'] in (20261020,20261021) and pair['seed'] not in seeds,'Two frozen seeded pairs required');seeds.add(pair['seed'])
        sources=pair['sources'];sids=set()
        require(isinstance(sources,list) and bool(sources),'Complete retained world required')
        for source in sources:
            require(source['source_id'] not in sids,'Unique source identifiers required');sids.add(source['source_id'])
            require(isinstance(source['text'],str) and sha(source['text'])==source['text_sha256'],'Full source text binding')
        for side in ('A','B'):
            row=pair[side];require(row['item_id'] not in ids,'All four unique items required');ids.add(row['item_id'])
            require(row['status'] in STATUSES,'Terminal cell status required')
            require(row['seed']==pair['seed'],'Pair by manifest seed only')
            require(isinstance(row['delivered_prompt'],str) and sha(row['delivered_prompt'])==row['prompt_sha256'],'Exact delivered prompt binding')
            require(row['full_input']['sources']==sources and row['full_input']['question']==pair['question'] and row['full_input']['obligations']==pair['obligations'],'Full retained input/world binding')
            require(row['full_input']['prompt']==row['delivered_prompt'],'Unchanged actual delivered prompt required')
            require(row['original_answer_receipt']['item_id']==row['item_id'] and row['original_answer_receipt']['status']==row['status'],'Original receipt identity')
            if 'answer' in row:
                require(isinstance(row['answer'],str) and row['answer_sha256']==sha(row['answer']),'Exact complete draft binding')
                require(row['original_answer_receipt'].get('answer')==row['answer'] and row['original_answer_receipt'].get('answer_sha256')==row['answer_sha256'],'Full original draft receipt binding')
                require(not row.get('answer_absence'),'No invented absence for returned draft')
            else:
                require(row['status'] in {'failed','cancelled','refused_followup_bound','refused_followup_integrity'},'Absent return requires explicit failure/refusal status')
                require('answer' not in row['original_answer_receipt'] and row['answer_sha256'] is None and row['answer_absence']=='no_returned_answer','Absent return explicit/null only')
    require(len(ids)==4 and len(seeds)==2,'Full pilot scope required')
    return {pair['pair_id']:pair for pair in packet}

def prepare_pairs(root):
    root=Path(root);require(not (root/'position-key-open-receipt.json').exists(),'Pre-position-key preparation only')
    protocol,manifest,bindings=collection(root)
    by_seed=defaultdict(list)
    for job in manifest['jobs']:
        iid=job['item_id'];input_path=root/'inputs'/(iid+'.input.json');item=load(input_path)
        require(digest(input_path)==job['input_sha256'] and item['seed']==job['seed'],'Frozen input identity')
        result=load(root/'inputs/answers'/(iid+'.json'))
        require(result['item_id']==iid,'Actual result identity')
        side={'item_id':iid,'seed':job['seed'],'status':result['status'],'delivered_prompt':item['prompt'],'prompt_sha256':item['prompt_sha256'],'full_input':item,'original_answer_receipt':result,'answer_sha256':None}
        if 'answer' in result:side.update(answer=result['answer'],answer_sha256=result['answer_sha256'])
        else:side['answer_absence']='no_returned_answer'
        by_seed[job['seed']].append(side)
    require(set(by_seed)=={20261020,20261021} and all(len(v)==2 for v in by_seed.values()),'Two manifest-seed pairs required')
    packet=[]
    for seed,sides in by_seed.items():
        secrets.SystemRandom().shuffle(sides)
        item=sides[0]['full_input']
        require(sides[1]['full_input']['sources']==item['sources'] and sides[1]['full_input']['obligations']==item['obligations'] and sides[1]['full_input']['question']==item['question'],'Matched complete retained worlds required')
        packet.append({'pair_id':secrets.token_hex(12),'kind':'consult','seed':seed,'question':item['question'],'obligations':item['obligations'],'sources':item['sources'],'A':sides[0],'B':sides[1]})
    secrets.SystemRandom().shuffle(packet);packet_validate(packet)
    destination=root/'pair-review';destination.mkdir(mode=0o700)
    # Exclusive destination is a durable latch against rebuilding/rerandomizing.
    packet_sha=write(destination/'pairs.json',packet)
    instructions={'substantive_criterion_path':'../../quality-review-v6-instructions.txt','substantive_criterion_sha256':bindings['whole_answer_rubric_sha256'],'pilot_scope_adapter':protocol['review_scope_adapter'],'reviewer_tasks':SESSIONS,'reused_primary_calibration_admission':protocol['reused_primary_calibration_admission'],'prior_exposure_disclosure':protocol['reviewer_exposure_disclosure'],'independence_attestation_fields':ATTESTATIONS,'review_envelope_fields':['reviewer','review_session_id','completed_at','packet_sha256','input_freeze_sha256','calibration_admission_sha256','prior_exposure','independence_attestation','rows'],'review_receipt_fields':['reviewer','review_session_id','completed_at','packet_sha256','input_freeze_sha256','review_sha256','position_key_opened:false','reviewed_without_position_key:true'],'review_row_fields':['reviewer','pair_id','disposition','note','abstention_assessment','A_answer_sha256','B_answer_sha256','A_quote','B_quote','source_ids'],'dispositions':sorted(DISPOSITIONS),'scope':'Each reviewer judges both pairs/all four complete draft cells, including failed/form-failed/absent returns. No meaning verdict from tooling or policy acceptance. Envelope and own hash receipt must be frozen before position-key access.','identity_limit':'Exact actual prompts expose cue placement. Position key is withheld; no claim that condition identity is uninferable or that reviewers are fresh/naive. Do not guess method identity. Opaque item IDs join A/B directly to the sole existing position key later; no second method key.'}
    write(destination/'review-instructions.json',instructions)
    return write(destination/'input-freeze.json',{'kind':'deepr.scratch.form-position-pilot.pair-input-freeze.v1','prepared_at':datetime.now(UTC).isoformat(),'packet_sha256':packet_sha,'instructions_sha256':digest(destination/'review-instructions.json'),'collection_bindings':bindings,'helper_modules':{name:digest(root/name) for name in ('audit_resources.py','pilot_review_support.py','prepare_pair_packet.py','freeze_reviews.py')},'reviewer_tasks':SESSIONS,'pairs_per_reviewer':2,'judgments_required':4,'semantic_acceptance':None,'position_key_read':False,'method_key_created':False})
