"""Synthetic-only postcollection tests; no pilot results or keys read."""
from pathlib import Path
from datetime import UTC,datetime,timedelta
import copy
import hashlib
import importlib
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
import audit_resources as audit
import pilot_review_support as support
import freeze_reviews as freezing
from pilot_guards import BASE_INPUT,read,sha

P=Path(__file__).resolve().parent
BASE=read(P.parent/BASE_INPUT)

def fixture(root,attempts=4):
    root.mkdir();task=root.parent
    def put(rel,value,raw=False):
        path=root/rel;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(value if raw else (json.dumps(value,indent=2)+'\n').encode());return audit.digest(path)
    prior={}
    for rel,count in audit.PRIOR_ATTEMPTS.items():
        path=task/rel;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(b''.join(json.dumps({'request_id':f'synthetic-prior-{i}'}).encode()+b'\n' for i in range(count)));prior[rel]=audit.digest(path)
    negatives={}
    for rel in audit.PRIOR_NEGATIVES:
        path=task/rel;path.write_text(json.dumps({'synthetic':'adverse'}));negatives[rel]=audit.digest(path)
    calibration=task/'synthetic-calibration-admission.json';calibration.write_text('{"synthetic":true}')
    rubric=task/'quality-review-v6-instructions.txt';rubric.write_text('Synthetic-only same substantive criterion fixture.')
    gen={'model':'synthetic-local','digest':'synthetic-digest'}
    jobs=[];items={}
    for i,seed in enumerate((20261020,20261020,20261021,20261021)):
        iid=f'synthetic-{i}';item=copy.deepcopy(BASE);item.update(item_id=iid,seed=seed)
        items[iid]=item;jobs.append({'item_id':iid,'seed':seed,'input_sha256':put('inputs/'+iid+'.input.json',item)})
    mh=put('manifest.json',{'generator':gen,'jobs':jobs,'system':'same synthetic system'})
    rh=put('pilot_runner.py',b'SYNTHETIC NEVER EXECUTED',True)
    snapshot=put('source-snapshot-receipt.json',{'synthetic':True})
    ih=put('input-freeze.json',{'synthetic':True})
    put('tooling-review-approval.json',{'synthetic':True})
    for name in ('audit_resources.py','pilot_review_support.py','prepare_pair_packet.py','freeze_reviews.py'):
        put(name,(P/name).read_bytes(),True)
    protocol={'paid_provider_api_ceiling_usd':0,'automatic_retry':False,'local_generation_ceiling':4,'wall_ceiling_seconds':1800,'generator':gen,'prior_ledgers':prior,'prior_negative_assessments_sha256':negatives,'prior_native_attempts':204,'total_native_attempts_if_full':208,'source_snapshot_receipt_sha256':snapshot,'source_recipe_sha256':'synthetic-owning-recipe','reviewer_tasks':support.SESSIONS,'reused_primary_calibration_admission':{'path':calibration.name,'sha256':audit.digest(calibration)},'review_controls':{'quality-review-v6-instructions.txt':audit.digest(rubric)},'review_scope_adapter':'Synthetic-only two-pair scope, no acceptance.','reviewer_exposure_disclosure':'Synthetic exposure disclosure, no fresh calibration.'}
    ph=put('protocol.json',protocol)
    ah=put('precollection-audit.json',{'admitted':True,'identity':{'protocol_sha256':ph,'manifest_sha256':mh,'input_freeze_sha256':ih,'runner_sha256':rh}})
    authority={'authorized':True,'dispatch_authorized':True,'paid_provider_api_ceiling_usd':0,'local_generation_ceiling':4,'wall_ceiling_seconds':1800,'protocol_sha256':ph,'runner_sha256':rh,'input_freeze_sha256':ih,'audit_sha256':ah}
    au=put('operator-authorization.json',authority)
    put('collector-freeze.json',{'paid_provider_api_ceiling_usd':0,'manifest_sha256':mh,'authorization_sha256':au,'protocol_sha256':ph,'runner_sha256':rh,'input_freeze_sha256':ih,'audit_sha256':ah,'max_calls':4,'max_wall_seconds':1800,'started_at':'2020-01-01T00:00:00+00:00','prior_native_attempts':204,'native_attempts_if_full':208})
    events=[];results=[];partials=((None,2),(3,None),(None,None),(10,5))
    for i,job in enumerate(jobs):
        iid=job['item_id'];item=items[iid]
        if i>=attempts:
            answer={'item_id':iid,'status':'refused_followup_bound','cause':'synthetic bound'}
        else:
            prefix=f'runtime/calls/{i+1:03d}.{iid}'
            request={'item_id':iid,'phase':'formpositionpilotv1','seed':item['seed'],'system':'same synthetic system','user':item['prompt'],'max_tokens':1024,'generator':gen,'manifest_sha256':mh,'created_at':'2020-01-01T00:00:01+00:00','phase_timeout_seconds':600,'effective_timeout_seconds':600}
            request_hash=put(prefix+'.request.json',request)
            ti,to=partials[i];text='Complete synthetic draft including caveats.'
            raw={'message':{'content':text}}
            if ti is not None:raw['prompt_eval_count']=ti
            if to is not None:raw['eval_count']=to
            transport=put(prefix+'.transport.json',{'request_sha256':request_hash,'raw_response':raw})
            native=put(prefix+'.native.json',{'raw_response':raw})
            answer={'item_id':iid,'status':'form_failed','answer':text,'answer_sha256':sha(text),'tokens_input':ti,'tokens_output':to,'request_sha256':request_hash,'transport_response_sha256':transport,'native_response_sha256':native}
            put(prefix+'.response.json',answer)
            for j,(op,status) in enumerate((('native_local_requested','requested'),('native_local_dispatching','dispatching'),('native_local_terminal','returned'))):
                events.append({'provider':'local','source':'local.native_ollama','cost_usd':0,'request_id':'issue-completion:formpositionpilotv1:'+iid,'idempotency_key':f'{iid}:{j}','operation':op,'model':gen['model'],'timestamp':f'2020-01-01T00:00:0{j+1}+00:00','tokens_input':ti,'tokens_output':to,'metadata':{'schema':'native-local-attempt-v1','kind':'chat','attempt_id':iid,'status':status,'model_digest':gen['digest']}})
        result_hash=put('inputs/answers/'+iid+'.json',answer);results.append({'item_id':iid,'status':answer['status'],'file_sha256':result_hash})
    if events:put('runtime/costs/cost_ledger.jsonl',b''.join(json.dumps(e).encode()+b'\n' for e in events),True)
    (root/'runtime/calls').mkdir(parents=True,exist_ok=True)
    put('inputs/answers-complete.json',{'manifest_sha256':mh,'terminal_answers':4,'answers_scheduled':4,'native_requests_reserved':attempts,'results':results,'wall_seconds':10})
    return prior,negatives

class Postcollection(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory(prefix='synthetic-postcollection-',dir=P)
        self.root=Path(self.temporary.name)/'pilot';self.prior,self.negatives=fixture(self.root)
        self.patches=[patch.object(audit,'PRIOR_LEDGER_EXPECTED',self.prior),patch.object(audit,'PRIOR_NEGATIVES',self.negatives),patch.object(support,'PRIOR_LEDGERS',self.prior),patch.object(support,'PRIOR_NEGATIVES',self.negatives)]
        for item in self.patches:item.start()
    def tearDown(self):
        for item in reversed(self.patches):item.stop()
        self.temporary.cleanup()
    def resource(self):return audit.audit(self.root)
    def put(self,rel,value):
        path=self.root/rel;path.write_text(json.dumps(value));return path
    def packet(self):
        self.put('native-resource-audit.json',self.resource());support.prepare_pairs(self.root)
        return support.load(self.root/'pair-review/pairs.json')
    def reviews(self,packet):
        directory=self.root/'pair-review';input_sha=audit.digest(directory/'input-freeze.json');packet_sha=audit.digest(directory/'pairs.json');cal=support.load(self.root/'protocol.json')['reused_primary_calibration_admission']['sha256']
        reviews={};receipts={}
        for reviewer,session in support.SESSIONS.items():
            rows=[{'reviewer':reviewer,'pair_id':p['pair_id'],'disposition':'uncertain','note':'Synthetic grounded review fixture.','abstention_assessment':'Synthetic fixture, not an actual semantic judgment.','A_answer_sha256':p['A']['answer_sha256'],'B_answer_sha256':p['B']['answer_sha256'],'A_quote':p['A'].get('answer','')[:8],'B_quote':p['B'].get('answer','')[:8],'source_ids':[p['sources'][0]['source_id']]} for p in packet]
            now=datetime.now(UTC).isoformat();review={'reviewer':reviewer,'review_session_id':session,'completed_at':now,'packet_sha256':packet_sha,'input_freeze_sha256':input_sha,'calibration_admission_sha256':cal,'prior_exposure':'Synthetic prior exposure, not fresh calibration.','independence_attestation':dict.fromkeys(support.ATTESTATIONS,True),'rows':rows}
            reviews[reviewer]=self.put(reviewer+'-review.json',review)
            receipt={'reviewer':reviewer,'review_session_id':session,'packet_sha256':packet_sha,'input_freeze_sha256':input_sha,'review_sha256':audit.digest(reviews[reviewer]),'completed_at':datetime.now(UTC).isoformat(),'position_key_opened':False,'reviewed_without_position_key':True}
            receipts[reviewer]=self.put(reviewer+'-receipt.json',receipt)
        return reviews,receipts
    def test_full_resource_and_partial_usage(self):
        report=self.resource();self.assertTrue(report['accounting_complete']);self.assertEqual(report['native_ledger_events'],12)
        self.assertEqual(report['total_native_attempts'],208);self.assertEqual(report['totals']['input_tokens'],13);self.assertEqual(report['totals']['output_tokens'],7);self.assertEqual(report['totals']['unknown_usage_attempts'],3)
    def test_zero_native_attempts_retain_all_four_absences(self):
        self.tearDown();self.setUpZero()
        report=self.resource();self.assertTrue(report['accounting_complete']);self.assertEqual(report['native_ledger_attempts'],0);self.assertIsNone(report['native_ledger_sha256']);self.assertEqual(report['total_native_attempts'],204)
        packet=self.packet();self.assertTrue(all(side['answer_sha256'] is None for p in packet for side in (p['A'],p['B'])))
    def setUpZero(self):
        self.temporary=tempfile.TemporaryDirectory(prefix='synthetic-zero-',dir=P);self.root=Path(self.temporary.name)/'pilot';self.prior,self.negatives=fixture(self.root,0)
        self.patches=[patch.object(audit,'PRIOR_LEDGER_EXPECTED',self.prior),patch.object(audit,'PRIOR_NEGATIVES',self.negatives),patch.object(support,'PRIOR_LEDGERS',self.prior),patch.object(support,'PRIOR_NEGATIVES',self.negatives)]
        for item in self.patches:item.start()
    def test_every_prior_ledger_immutable(self):
        for rel in self.prior:
            path=self.root.parent/rel;original=path.read_bytes();path.write_bytes(original+b'\n')
            with self.assertRaises(ValueError):self.resource()
            path.write_bytes(original)
    def test_paid_or_duplicate_dispatch_refused(self):
        path=self.root/'runtime/costs/cost_ledger.jsonl';original=path.read_bytes();events=[json.loads(line) for line in original.splitlines()]
        events[0]['cost_usd']=1;path.write_bytes(b''.join(json.dumps(e).encode()+b'\n' for e in events))
        with self.assertRaises(ValueError):self.resource()
        events=[json.loads(line) for line in original.splitlines()];events.insert(2,copy.deepcopy(events[1]));path.write_bytes(b''.join(json.dumps(e).encode()+b'\n' for e in events))
        with self.assertRaises(ValueError):self.resource()
    def test_accounting_failure_raw_retained_all_cells_reported(self):
        path=self.root/'runtime/costs/cost_ledger.jsonl';events=[json.loads(line) for line in path.read_bytes().splitlines()];events.pop(2);path.write_bytes(b''.join(json.dumps(e).encode()+b'\n' for e in events))
        iid='synthetic-0';response=self.root/('runtime/calls/001.'+iid+'.response.json');row=support.load(response);row['status']='failed';row['error_type']='LocalAttemptAccountingError'
        self.put('runtime/calls/001.'+iid+'.response.json',row);answer=self.put('inputs/answers/'+iid+'.json',row)
        complete=support.load(self.root/'inputs/answers-complete.json');complete['results'][0].update(status='failed',file_sha256=audit.digest(answer));self.put('inputs/answers-complete.json',complete)
        report=self.resource();self.assertFalse(report['accounting_complete']);self.assertEqual(report['scheduled_cells'],4);self.assertEqual(report['totals']['transport_returned_attempts'],4)
        self.assertTrue(any(x['issue']=='missing_or_duplicate_canonical_lifecycle' for x in report['issues']))
        packet=self.packet();self.assertEqual(sum(side['status']=='failed' for pair in packet for side in (pair['A'],pair['B'])),1)
    def test_capture_failure_fallback_preserved_and_flagged(self):
        iid='synthetic-0';prefix='runtime/calls/001.'+iid
        raw=support.load(self.root/(prefix+'.transport.json'))['raw_response'];(self.root/(prefix+'.transport.json')).unlink()
        row=support.load(self.root/(prefix+'.response.json'));row.update(status='failed',raw_transport_response=raw);row.pop('transport_response_sha256');row.pop('native_response_sha256')
        self.put(prefix+'.response.json',row);answer=self.put('inputs/answers/'+iid+'.json',row)
        complete=support.load(self.root/'inputs/answers-complete.json');complete['results'][0].update(status='failed',file_sha256=audit.digest(answer));self.put('inputs/answers-complete.json',complete)
        report=self.resource();self.assertFalse(report['accounting_complete']);self.assertEqual(report['totals']['transport_returned_attempts'],4)
        self.assertTrue(any(x['issue']=='transport_capture_failed_raw_preserved_in_failure_receipt' for x in report['issues']))
    def test_zero_and_one_known_usage_components_not_conflated(self):
        report=self.resource();self.assertEqual(report['totals']['known_input_attempts'],2);self.assertEqual(report['totals']['known_output_attempts'],2);self.assertEqual(report['totals']['known_usage_attempts'],1)
        self.assertFalse(report['usage_complete'])
    def test_pair_seed_full_scope_no_rebuild(self):
        packet=self.packet();self.assertEqual(len(packet),2);self.assertEqual({p['seed'] for p in packet},{20261020,20261021})
        for pair in packet:
            self.assertEqual(pair['A']['seed'],pair['B']['seed']);self.assertIn('full_input',pair['A']);self.assertIn('original_answer_receipt',pair['B'])
        with self.assertRaises(FileExistsError):support.prepare_pairs(self.root)
    def test_four_review_judgments_exclusive_snapshots(self):
        packet=self.packet();reviews,receipts=self.reviews(packet);freezing.freeze(self.root,reviews,receipts)
        freeze=support.load(self.root/'pair-review/quality-freeze/FREEZE.json');self.assertEqual(freeze['judgments_frozen'],4);self.assertIsNone(freeze['semantic_acceptance'])
        self.assertEqual(freeze['reviewer_tasks'],support.SESSIONS)
        with self.assertRaises(FileExistsError):freezing.freeze(self.root,reviews,receipts)
    def test_bad_quote_source_hash_missing_row_and_session_refused(self):
        packet=self.packet();reviews,receipts=self.reviews(packet)
        original=support.load(reviews['R1'])
        for mutate in (lambda e:e['rows'][0].update(A_quote='Invented absent quote'),lambda e:e['rows'][0].update(source_ids=['nonexistent']),lambda e:e['rows'][0].update(A_answer_sha256='0'*64),lambda e:e['rows'].pop(),lambda e:e.update(review_session_id='/root/not-admitted')):
            changed=copy.deepcopy(original);mutate(changed);self.put('R1-review.json',changed)
            receipt=support.load(receipts['R1']);receipt['review_sha256']=audit.digest(reviews['R1']);self.put('R1-receipt.json',receipt)
            with self.assertRaises(RuntimeError):freezing.freeze(self.root,reviews,receipts)
            self.assertFalse((self.root/'pair-review/quality-freeze').exists())
        self.put('R1-review.json',original)
    def test_no_key_reads_and_open_chronology(self):
        with patch('pathlib.Path.read_bytes',side_effect=AssertionError('protected input read')):
            with self.assertRaises(RuntimeError):support.load(self.root/'position-key-unopened/key.json')
        self.put('position-key-open-receipt.json',{'synthetic':True})
        with self.assertRaises(RuntimeError):support.prepare_pairs(self.root)
    def test_import_safety(self):
        env=dict(os.environ)
        with patch('pathlib.Path.read_bytes',side_effect=AssertionError('import read')),patch('pathlib.Path.mkdir',side_effect=AssertionError('import write')):
            importlib.reload(freezing);importlib.reload(support);importlib.reload(audit)
        self.assertEqual(env,dict(os.environ))
        # Reload resets synthetic constants; restore this test's mocks for tearDown only.

if __name__=='__main__':unittest.main()
