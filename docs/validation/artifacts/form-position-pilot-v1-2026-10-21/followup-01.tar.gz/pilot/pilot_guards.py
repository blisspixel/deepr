"""Unshipped, string-only diagnostic guards; import performs no reads or writes."""
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from v8_guards import MODULE_PATHS, EXTRA_MODULE_PATHS, GENERATOR, REVIEW_CONTROL_HASHES
from v8_guards import PRIOR_LEDGER_HASHES as V8_PRIORS, PRIOR_NEGATIVE_HASHES as V8_NEGATIVES

RECIPE = '5a019a92edff47136f12933a4c8e9bdd9a5fb4d0e5774a37f3ae137a8aaa9437'
BASE_INPUT = 'packing-fixtures-v8/4c94cd3900e453bf.input.json'
BASE_INPUT_SHA = '19fb34d9f86c36f516c62c665e19587bb69d39d16103ca854b3c43fc91bad71a'
BASE_REQUEST = 'v8-runtime/calls/008.4c94cd3900e453bf.request.json'
BASE_REQUEST_SHA = 'a1155e55a7716800c1e24b3cdca07bc667d88dc79d0861f1d934ed3b15b090f7'
BASE_PROMPT_SHA = 'b80481c52b5a5622411d32718e32da37d627a5a7f1ecd35f0c5fb9937b92bff6'
PROPOSAL = 'reviewers/R3/post-v8-form-boundary-proposal.json'
PROPOSAL_SHA = '5a35f9b95382f684279b89e0d40d9b363dd099bb2afe665a4aa87a1f023842ac'
PRIOR_LEDGERS = V8_PRIORS | {'v8-runtime/costs/cost_ledger.jsonl': 'eed780c81aa58fa1e9710668cac8f9631ec7ae9b8b1143f94d675f468e5ef4ac'}
PRIOR_NEGATIVES = V8_NEGATIVES | {'issue258-v8-semantic-assessment.json': 'fea27de2522ad19b3c3c1bbf32b55494ff00f7457beb11dc803e426afb0f9a33'}
CUE = 'Response form: draft a brief answer around 90 words. Use additional room only for supported guidance, applicable conditions and material uncertainty; hard limit 180 whitespace-separated words in the complete visible answer, including headings and caveats. Omit repetition.'

class PilotInvariantError(RuntimeError):
    pass

def require(ok, detail):
    if not ok:
        raise PilotInvariantError(detail)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def relocate(prompt):
    require(len(prompt) == 6336 and sha(prompt) == BASE_PROMPT_SHA, 'Exact V8 prompt required')
    require(prompt.count(CUE) == 1 and prompt.index(CUE) == 1668, 'Single unchanged leading cue required')
    before, after = prompt.split(CUE + '\n\n')
    moved = before + after + '\n\n' + CUE
    require(len(moved) == len(prompt) and moved.count(CUE) == 1, 'Length and single cue preserved')
    require(moved[:-len(CUE)-2] == before + after, 'Every non-cue byte preserved in order')
    require(moved.endswith('\n\n' + CUE), 'Trailing placement required')
    return moved

def recipe(root):
    h = hashlib.sha256()
    for path in MODULE_PATHS:
        h.update(path.removeprefix('src/').encode('utf-8'))
        h.update((Path(root)/path).read_bytes())
    return h.hexdigest()

def check_hashes(root, declared):
    for path, expected in declared.items():
        require(digest(Path(root)/path) == expected, 'Changed bound bytes: ' + path)

def validate_source(root, protocol):
    require(protocol['source_recipe_sha256'] == RECIPE == recipe(root), 'Owning ordered source recipe changed')
    require(set(protocol['source_modules']) == set(MODULE_PATHS), 'Exactly twenty owning modules required')
    require(set(protocol['extra_source_modules']) == set(EXTRA_MODULE_PATHS), 'Exactly three extras required')
    check_hashes(root, protocol['source_modules'] | protocol['extra_source_modules'])

def validate_prior(task, protocol):
    require(protocol['prior_ledgers'] == PRIOR_LEDGERS, 'Five prior ledger pins required')
    require(protocol['prior_negative_assessments_sha256'] == PRIOR_NEGATIVES, 'Four negatives required')
    check_hashes(task, PRIOR_LEDGERS | PRIOR_NEGATIVES)

def validate_protocol(p):
    require(p['status'] == 'frozen' and p['diagnostic_only'] is True, 'Frozen diagnostic required')
    require((p['local_generation_ceiling'], p['wall_ceiling_seconds'], p['paid_provider_api_ceiling_usd']) == (4,1800,0), 'Pilot caps changed')
    require(p['automatic_retry'] is False and p['generator'] == GENERATOR, 'No retries / pinned generator required')
    require(p['prior_native_attempts'] == 204 and p['total_native_attempts_if_full'] == 208, 'Pilot totals changed')
    require(p['review_controls'] == REVIEW_CONTROL_HASHES, 'Unchanged review controls required')
    require(p['allowances'] == {'consult_prompt_chars':6500, 'output_tokens':1024, 'call_timeout_seconds':600}, 'Allowances changed')
    require(p['product_source_changed'] is False and p['unshipped_string_only_transform'] is True, 'Unshipped transform only')

def validate_item(item, job, base):
    require(item['item_id'] == job['item_id'] and item['seed'] == job['seed'], 'Cell identity changed')
    require(item['seed'] in GENERATOR['seeds'], 'Pinned seed required')
    require(item['kind'] == 'consult' and item['status'] == 'ready', 'Consult ready required')
    require(item['prompt'] in (base['prompt'], relocate(base['prompt'])), 'Only exact cue relocation allowed')
    require(len(item['prompt']) == item['prompt_chars'] == 6336, 'Exact 6336 characters required')
    require(sha(item['prompt']) == item['prompt_sha256'] == item['delivered_evidence']['prompt_sha256'], 'Prompt binding')
    require(item['prompt'] == item['delivered_evidence']['prompt'], 'Exact delivered prompt required')
    for key in ('question','obligations','sources','delivery_manifest','response_form'):
        require(item[key] == base[key], 'Retained world/delivery changed: ' + key)
    expected = dict(base['delivered_evidence'], prompt=item['prompt'], prompt_sha256=item['prompt_sha256'])
    require(item['delivered_evidence'] == expected, 'Other delivered evidence changed')
    require((item['output_tokens'],item['timeout_seconds'],item['prompt_limit_chars']) == (1024,600,6500), 'Cell allowances changed')

def validate_manifest(m, inputs, base):
    require(m['answers_scheduled'] == len(m['jobs']) == len(inputs) == 4, 'Exactly four scheduled cells required')
    require(len({j['item_id'] for j in m['jobs']}) == 4, 'Unique cells required')
    require(m['generator'] == GENERATOR and m['pairs'] == 2, 'Two seeded pairs required')
    matrix=[]
    for j,item in zip(m['jobs'], inputs):
        validate_item(item,j,base)
        matrix.append((item['seed'],item['prompt_sha256']))
    require(len(set(matrix)) == 4 and {s for s,h in matrix} == set(GENERATOR['seeds']), 'Complete position by seed matrix required')
    require(m['jobs'][0]['seed'] == m['jobs'][1]['seed'] and m['jobs'][2]['seed'] == m['jobs'][3]['seed'] and m['jobs'][0]['seed'] != m['jobs'][2]['seed'], 'Seed blocks required')
    require(inputs[0]['prompt_sha256'] != inputs[2]['prompt_sha256'], 'Balanced first position across seed blocks required')

def before_transport(root, task, protocol, request, deadline, wall_remaining, monotonic):
    validate_source(root,protocol)
    validate_prior(task,protocol)
    require(request is not None and Path(request).is_file(), 'Durable reservation required')
    remaining=min(deadline-monotonic(),wall_remaining())
    require(remaining>0, 'Deadline exhausted before native POST')
    return remaining
