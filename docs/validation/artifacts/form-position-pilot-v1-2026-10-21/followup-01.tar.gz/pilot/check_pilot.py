"""Offline diagnostic guards and a fake-native accounting failure exercise."""
import asyncio
import copy
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
from pilot_guards import *
import prepare_pilot
import pilot_runner

TASK=Path(__file__).resolve().parent.parent
BASE=read(TASK/BASE_INPUT)

def matrix():
    items=[];jobs=[]
    for i,(seed,trailing) in enumerate(((20261020,False),(20261020,True),(20261021,True),(20261021,False))):
        item=copy.deepcopy(BASE);item.update(item_id=f'fake-{i}',seed=seed)
        if trailing:
            item['prompt']=relocate(item['prompt'])
        item['prompt_sha256']=sha(item['prompt'])
        item['delivered_evidence'].update(prompt=item['prompt'],prompt_sha256=item['prompt_sha256'])
        jobs.append({'item_id':item['item_id'],'seed':seed});items.append(item)
    return {'answers_scheduled':4,'pairs':2,'generator':GENERATOR,'jobs':jobs,'system':'same system'},items

class Guards(unittest.TestCase):
    def test_serialized_hash_without_key_reread_and_private_mode(self):
        with tempfile.TemporaryDirectory() as temp:
            target=Path(temp)/'synthetic-key.json'
            data={'synthetic':'not a real key'}
            expected=hashlib.sha256((json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode()).hexdigest()
            with patch('pathlib.Path.read_bytes',side_effect=AssertionError('must not reread written key')):
                result=prepare_pilot.write(target,data)
            self.assertEqual(result,expected)
            self.assertEqual(target.stat().st_mode & 0o777,0o600)
            with self.assertRaises(FileExistsError):prepare_pilot.write(target,data)
    def test_frozen_protocol_caps_and_pins(self):
        p={'status':'frozen','diagnostic_only':True,'local_generation_ceiling':4,'wall_ceiling_seconds':1800,'paid_provider_api_ceiling_usd':0,'automatic_retry':False,'generator':GENERATOR,'prior_native_attempts':204,'total_native_attempts_if_full':208,'review_controls':REVIEW_CONTROL_HASHES,'allowances':{'consult_prompt_chars':6500,'output_tokens':1024,'call_timeout_seconds':600},'product_source_changed':False,'unshipped_string_only_transform':True}
        validate_protocol(p)
        for field,value in (('local_generation_ceiling',5),('wall_ceiling_seconds',1801),('paid_provider_api_ceiling_usd',1),('automatic_retry',True),('prior_native_attempts',180),('total_native_attempts_if_full',204),('product_source_changed',True),('diagnostic_only',False)):
            bad=copy.deepcopy(p);bad[field]=value
            with self.assertRaises(PilotInvariantError):validate_protocol(bad)
    def test_exact_transform(self):
        moved=relocate(BASE['prompt'])
        self.assertEqual(len(moved),6336)
        self.assertEqual(moved.count(CUE),1)
        self.assertEqual(BASE['prompt'].replace(CUE+'\n\n','',1),moved.removesuffix('\n\n'+CUE))
        self.assertEqual(moved[-len(CUE):],CUE)
    def test_transform_refuses_any_other_byte(self):
        for bad in (BASE['prompt']+' ',BASE['prompt'].replace('180','181',1),BASE['prompt'].replace(CUE,CUE+CUE)):
            with self.assertRaises(PilotInvariantError):relocate(bad)
    def test_complete_balanced_matrix(self):
        m,items=matrix();validate_manifest(m,items,BASE)
    def test_missing_duplicate_and_unbalanced_cells(self):
        m,items=matrix()
        with self.assertRaises(PilotInvariantError):validate_manifest(m,items[:-1],BASE)
        items[3]=copy.deepcopy(items[2]);items[3]['item_id']='fake-3'
        with self.assertRaises(PilotInvariantError):validate_manifest(m,items,BASE)
        m,items=matrix();items[2],items[3]=items[3],items[2];m['jobs'][2],m['jobs'][3]=m['jobs'][3],m['jobs'][2]
        with self.assertRaises(PilotInvariantError):validate_manifest(m,items,BASE)
    def test_no_source_delivery_change(self):
        m,items=matrix()
        for field in ('sources','obligations','delivery_manifest','response_form','question'):
            bad=copy.deepcopy(items[0]);bad[field]=None
            with self.assertRaises(PilotInvariantError):validate_item(bad,m['jobs'][0],BASE)
    def test_owning_recipe_not_receipt_hash(self):
        self.assertEqual(recipe(prepare_pilot.R),RECIPE)
        p=read(TASK/'v8-review-protocol.json')
        p['source_recipe_sha256']=digest(TASK/'packing-v8-source-snapshot-receipt.json')
        with self.assertRaises(PilotInvariantError):validate_source(prepare_pilot.R,p)
    def test_all_five_ledgers_and_four_negatives(self):
        p={'prior_ledgers':PRIOR_LEDGERS,'prior_negative_assessments_sha256':PRIOR_NEGATIVES}
        validate_prior(TASK,p)
        for name in PRIOR_LEDGERS:
            q=copy.deepcopy(p);q['prior_ledgers'][name]='0'*64
            with self.assertRaises(PilotInvariantError):validate_prior(TASK,q)
        for name in PRIOR_NEGATIVES:
            q=copy.deepcopy(p);q['prior_negative_assessments_sha256'][name]='0'*64
            with self.assertRaises(PilotInvariantError):validate_prior(TASK,q)
    def test_post_accounting_deadline_and_reservation(self):
        with tempfile.TemporaryDirectory() as temp:
            request=Path(temp)/'request';request.write_text('{}')
            with patch('pilot_guards.validate_source'),patch('pilot_guards.validate_prior'):
                self.assertEqual(before_transport(None,None,{},request,13,lambda:5,lambda:10),3)
                for req,deadline,wall in ((None,13,5),(request,10,5),(request,13,0)):
                    with self.assertRaises(PilotInvariantError):before_transport(None,None,{},req,deadline,lambda:wall,lambda:10)
    def test_import_safety(self):
        before=dict(os.environ)
        with patch('pathlib.Path.read_bytes',side_effect=AssertionError('import read')),patch('pathlib.Path.read_text',side_effect=AssertionError('import read')),patch('pathlib.Path.mkdir',side_effect=AssertionError('import write')):
            importlib.reload(pilot_runner);importlib.reload(prepare_pilot)
        self.assertEqual(dict(os.environ),before)
    def test_missing_root_review_refuses_freeze(self):
        with tempfile.TemporaryDirectory() as temp,patch.object(prepare_pilot,'P',Path(temp)):
            with self.assertRaises(FileNotFoundError):prepare_pilot.freeze()
            self.assertFalse((Path(temp)/'freeze-started.json').exists())

class FakeAccountingError(RuntimeError):pass
class FakeRefusal(RuntimeError):pass

class Runner(unittest.TestCase):
    def exercise(self, failure):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);p=root/'pilot';p.mkdir();d=p/'inputs';d.mkdir();runtime=p/'runtime'
            (root/BASE_INPUT).parent.mkdir(parents=True);(root/BASE_INPUT).write_text(json.dumps(BASE))
            m,items=matrix()
            for j,item in zip(m['jobs'],items):
                target=d/(item['item_id']+'.input.json');target.write_text(json.dumps(item));j['input_sha256']=digest(target)
            (p/'manifest.json').write_text(json.dumps(m))
            for name in ('protocol.json','operator-authorization.json','precollection-audit.json','input-freeze.json'):(p/name).write_text('{}')
            events=[];calls=[0]
            def exclusive(path,data):
                with Path(path).open('x') as stream:json.dump(data,stream)
            def failing_write(path,data):
                if failure=='capture' and str(path).endswith('.transport.json'):raise OSError('synthetic capture fault')
                exclusive(path,data)
            async def post(url,payload,timeout):
                events.append('transport_returned')
                self.assertEqual(len(list((runtime/'calls').glob('*.request.json'))),calls[0])
                return {'message':{'content':'word '*181},'done_reason':'stop'}
            class Backend:
                def __init__(self,model,timeout,post_json):self.timeout=timeout;self.post=post_json;self.last_attested_digest=GENERATOR['digest']
                async def complete(self,request,correlation_id):
                    calls[0]+=1;events.extend(['requested','dispatching'])
                    raw=await self.post('http://localhost',{},self.timeout)
                    selftest.assertTrue(list((runtime/'calls').glob('*.transport.json')))
                    events.append('raw_durably_retained')
                    if failure=='terminal':raise FakeAccountingError('synthetic terminal failure')
                    events.append('terminal')
                    return types.SimpleNamespace(raw_response=raw,text=raw['message']['content'],provider_request_id=None,stop_reason='stop')
            selftest=self
            def module(**fields):return types.SimpleNamespace(**fields)
            modules={
              'deepr.experts.chat_backends':module(ExpertChatRequest=lambda **kw:kw),
              'deepr.experts.investigation.ollama_backend':module(NativeOllamaInvestigationBackend=Backend,_post_json=post),
              'deepr.experts.council':module(SYNTHESIS_SYSTEM_PROMPT=m['system']),
              'deepr.experts.consult_response':module(admit_response_form=lambda q,a:{'response_form':{'actual_words':len(a['text'].split())},'synthesis_status':'failed','synthesis_error_type':'ResponseWordLimit'}),
              'deepr.backends.capacity':module(OwnedLocalCapacityRefused=FakeRefusal),
              'deepr.observability.local_attempts':module(LocalAttemptAccountingError=FakeAccountingError),
            }
            with patch.dict(sys.modules,modules),patch.dict(os.environ,dict(os.environ)),patch.multiple(pilot_runner,R=root,P=p,T=root,D=d,F=runtime),patch.object(pilot_runner,'write',failing_write),patch.object(pilot_runner,'preflight',return_value=({},m)),patch.object(pilot_runner,'validate_source'),patch.object(pilot_runner,'validate_prior'),patch('pilot_guards.validate_source'),patch('pilot_guards.validate_prior'):
                asyncio.run(pilot_runner.main())
            complete=read(d/'answers-complete.json')
            self.assertEqual(complete['terminal_answers'],4)
            rows=[read(d/'answers'/(j['item_id']+'.json')) for j in m['jobs']]
            self.assertEqual(rows[0]['answer'],'word '*181)
            self.assertEqual(rows[0]['answer_sha256'],sha('word '*181))
            self.assertIsNone(rows[0]['tokens_input']);self.assertIsNone(rows[0]['tokens_output'])
            if failure:
                self.assertEqual(calls[0],1)
                self.assertTrue(all(x['status']=='refused_followup_integrity' for x in rows[1:]))
                self.assertEqual(rows[0]['raw_transport_response']['message']['content'],'word '*181)
            else:
                self.assertEqual(calls[0],4);self.assertTrue(all(x['status']=='form_failed' for x in rows))
            return events
    def test_full_failed_form_preserved_without_retry(self):
        events=self.exercise(None);self.assertEqual(events.count('terminal'),4)
    def test_terminal_accounting_failure_preserves_full_raw_latches(self):
        events=self.exercise('terminal');self.assertIn('raw_durably_retained',events);self.assertNotIn('terminal',events)
    def test_capture_failure_preserves_raw_in_failure_receipt_latches(self):
        events=self.exercise('capture');self.assertNotIn('terminal',events)

if __name__=='__main__':unittest.main()
