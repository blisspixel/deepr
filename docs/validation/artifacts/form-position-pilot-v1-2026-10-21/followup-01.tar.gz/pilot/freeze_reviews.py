"""Mechanical exclusive pilot review freeze. Never interprets verdict meaning or reads keys."""
from datetime import UTC,datetime
from pathlib import Path
from pilot_review_support import *

def nonempty(value,name):
    require(isinstance(value,str) and bool(value.strip()),name+' required')
    return value

def validate_review(envelope,receipt,reviewer,packet,packet_sha,input_sha,earliest,now,calibration_sha):
    require(isinstance(envelope,dict) and envelope.get('reviewer')==reviewer,'Review identity')
    require(envelope.get('review_session_id')==SESSIONS[reviewer],'Actual reused canonical task required')
    require(envelope.get('packet_sha256')==packet_sha and envelope.get('input_freeze_sha256')==input_sha,'Review input commitments')
    require(envelope.get('calibration_admission_sha256')==calibration_sha,'Actual reused calibration binding')
    nonempty(envelope.get('prior_exposure'),'Actual prior exposure disclosure')
    require(envelope.get('fresh_calibration_claimed') is not True,'No fresh calibration claim')
    attestation=envelope.get('independence_attestation')
    require(isinstance(attestation,dict) and all(attestation.get(key) is True for key in ATTESTATIONS),'Truthful complete pilot attestations required')
    completed=timestamp(envelope['completed_at'])
    require(earliest<=completed<=now,'Review completion chronology')
    rows=envelope.get('rows');require(isinstance(rows,list) and len(rows)==2,'Every reviewer must judge both complete pairs')
    seen=set()
    for row in rows:
        require(row.get('reviewer')==reviewer,'Row reviewer mismatch')
        pid=row.get('pair_id');require(pid in packet and pid not in seen,'Unknown/duplicate pair');seen.add(pid)
        require(row.get('disposition') in DISPOSITIONS,'Frozen disposition required')
        nonempty(row.get('note'),'Source-grounded rationale');nonempty(row.get('abstention_assessment'),'Abstention assessment')
        source_ids=row.get('source_ids')
        require(isinstance(source_ids,list) and all(isinstance(s,str) for s in source_ids) and len(set(source_ids))==len(source_ids),'Unique source identifier list required')
        require(set(source_ids)<={s['source_id'] for s in packet[pid]['sources']},'Source IDs outside retained world')
        for side in ('A','B'):
            answer=packet[pid][side]
            require(side+'_answer_sha256' in row and row[side+'_answer_sha256']==answer['answer_sha256'],'Actual draft or absent-return hash binding')
            quote=row.get(side+'_quote');require(isinstance(quote,str),'Exact quote or empty string required')
            require(not quote or quote in answer.get('answer',''),'Quote is not a supplied exact answer substring')
    require(seen==set(packet),'All pairs required')
    require(receipt.get('reviewer')==reviewer and receipt.get('review_session_id')==SESSIONS[reviewer],'Own freeze receipt identity')
    require(receipt.get('packet_sha256')==packet_sha and receipt.get('input_freeze_sha256')==input_sha,'Own receipt input bindings')
    require(receipt.get('position_key_opened') is False and receipt.get('reviewed_without_position_key') is True,'Own receipt pre-key attestation')
    require(completed<=timestamp(receipt['completed_at'])<=now,'Own receipt chronology')

def freeze(root,reviews,receipts):
    root=Path(root)
    require(not (root/'position-key-open-receipt.json').exists(),'Review freeze must precede canonical position-key opening')
    protocol,manifest,bindings=collection(root)
    directory=root/'pair-review'
    packet=load(directory/'pairs.json');indexed=packet_validate(packet)
    input_freeze=load(directory/'input-freeze.json')
    packet_sha=digest(directory/'pairs.json');input_sha=digest(directory/'input-freeze.json')
    require(input_freeze['packet_sha256']==packet_sha and input_freeze['collection_bindings']==bindings,'Pair input/collection binding')
    require(input_freeze['instructions_sha256']==digest(directory/'review-instructions.json'),'Scope instructions binding')
    require(input_freeze['reviewer_tasks']==SESSIONS and input_freeze['pairs_per_reviewer']==2 and input_freeze['judgments_required']==4,'Two actual reviewers/all four judgments required')
    require(input_freeze['semantic_acceptance'] is None and input_freeze['position_key_read'] is False and input_freeze['method_key_created'] is False,'Pre-key nonacceptance input freeze required')
    for rel,expected in input_freeze['helper_modules'].items():require(digest(root/rel)==expected,'Prepared helper changed: '+rel)
    jobs={j['item_id']:j for j in manifest['jobs']};seen=set()
    for pair in packet:
        for side in ('A','B'):
            cell=pair[side];iid=cell['item_id'];require(iid in jobs and iid not in seen,'Scheduled item coverage');seen.add(iid)
            require(cell['full_input']==load(root/'inputs'/(iid+'.input.json')),'Actual full input binding')
            require(cell['original_answer_receipt']==load(root/'inputs/answers'/(iid+'.json')),'Actual original draft/status binding')
            require(cell['seed']==jobs[iid]['seed'],'Manifest seed pairing')
    require(seen==set(jobs),'All four actual cells required')
    now=datetime.now(UTC);earliest=timestamp(input_freeze['prepared_at']);loaded={};receipt_values={};validated_hashes={}
    require(set(reviews)==set(receipts)==set(SESSIONS),'Exactly R1 and R2 reviews and own receipts required')
    paths=[Path(v).resolve() for v in list(reviews.values())+list(receipts.values())]
    require(len(set(paths))==4,'Distinct exclusive review/receipt inputs required')
    for reviewer in SESSIONS:
        envelope=load(Path(reviews[reviewer]));receipt=load(Path(receipts[reviewer]))
        validated_hashes[reviewer]=(digest(Path(reviews[reviewer])),digest(Path(receipts[reviewer])))
        require(receipt.get('review_sha256')==digest(Path(reviews[reviewer])),'Own completed review hash receipt')
        validate_review(envelope,receipt,reviewer,indexed,packet_sha,input_sha,earliest,now,bindings['calibration_admission_sha256'])
        loaded[reviewer]=envelope;receipt_values[reviewer]=receipt
    target=directory/'quality-freeze';target.mkdir(mode=0o700)
    snapshots=target/'snapshots';snapshots.mkdir(mode=0o700);snapshot_hashes={}
    def snapshot(name,source,expected):
        raw=Path(source).read_bytes();require(hashlib.sha256(raw).hexdigest()==expected, 'Validated snapshot input changed: '+name)
        out=snapshots/name;out.parent.mkdir(parents=True,exist_ok=True)
        descriptor=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        snapshot_hashes[name]=hashlib.sha256(raw).hexdigest()
    for reviewer in SESSIONS:
        snapshot(reviewer+'/review.json',reviews[reviewer],validated_hashes[reviewer][0]);snapshot(reviewer+'/receipt.json',receipts[reviewer],validated_hashes[reviewer][1])
    for rel in bindings:
        if rel.endswith('.json'):snapshot('collection/'+rel,root/rel,bindings[rel])
    pair_hashes={'pairs.json':packet_sha,'input-freeze.json':input_sha,'review-instructions.json':input_freeze['instructions_sha256']}
    for rel,expected in pair_hashes.items():snapshot('pair-inputs/'+rel,directory/rel,expected)
    for rel in input_freeze['helper_modules']:snapshot('tools/'+rel,root/rel,input_freeze['helper_modules'][rel])
    snapshot('controls/calibration-admission.json',root.parent/protocol['reused_primary_calibration_admission']['path'],bindings['calibration_admission_sha256'])
    snapshot('controls/whole-answer-rubric.txt',root.parent/'quality-review-v6-instructions.txt',bindings['whole_answer_rubric_sha256'])
    result={'kind':'deepr.scratch.form-position-pilot.review-freeze.v1','frozen_at':now.isoformat(),'protocol_sha256':bindings['protocol.json'],'packet_sha256':packet_sha,'input_freeze_sha256':input_sha,'collection_bindings':bindings,'reviewer_tasks':SESSIONS,'reviewer_prior_exposure':{r:loaded[r]['prior_exposure'] for r in SESSIONS},'reused_calibration_admission_sha256':bindings['calibration_admission_sha256'],'reviews':{r:{'review_sha256':validated_hashes[r][0],'receipt_sha256':validated_hashes[r][1],'rows':2,'review_session_id':SESSIONS[r]} for r in SESSIONS},'scheduled_cells':4,'pairs_per_reviewer':2,'independent_review_inputs':2,'judgments_frozen':4,'snapshots_sha256':snapshot_hashes,'position_key_read_by_helper':False,'position_key_open_receipt_observed':False,'key_nonaccess_evidence':'Reviewer attestations and absence of canonical open receipt. No claim to prove unrestricted session history or make visible prompt condition identity uninferable.','semantic_acceptance':None,'meaning_verdict':'No semantic regrading, voting aggregate or acceptance by this mechanical helper.'}
    return write(target/'FREEZE.json',result)

def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection-complete',required=True,action='store_true',help='Root declared collection complete and authorized offline review freeze.')
    for reviewer in ('r1','r2'):
        parser.add_argument('--'+reviewer,required=True,type=Path)
        parser.add_argument('--'+reviewer+'-receipt',required=True,type=Path)
    args=parser.parse_args()
    print(freeze(P,{'R1':args.r1,'R2':args.r2},{'R1':args.r1_receipt,'R2':args.r2_receipt}))
if __name__=='__main__':main()
