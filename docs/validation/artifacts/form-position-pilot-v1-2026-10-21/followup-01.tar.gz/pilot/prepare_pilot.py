"""Prepare only after root tooling review. Never dispatches or opens a key."""
import copy
import json
import secrets
from datetime import UTC, datetime
from pathlib import Path
from pilot_guards import *
R = Path('/home/pueo/Work/deepr')
P = Path(__file__).resolve().parent
T = P.parent
TOOLS = ('pilot_guards.py','prepare_pilot.py','pilot_runner.py','check_pilot.py')
ARCHIVE = {
 '.agent/issue-completion-2026-10-20/reviewers/R1/archive-v8-independent-verification.json':'ac1228f2d0a0d53cd52b6cd0743c58b9d07024dcc6d5097b8b0179b41cd1540f',
 'docs/validation/artifacts/evidence-followup-v8-2026-10-21/index.json':'615bf88197db5974ce117e7e4a97ba2ebf635f512ab04423a172b4d9f69982c5',
 'docs/validation/artifacts/evidence-followup-v8-2026-10-21/COMPLETE.json':'323955313bc92bc6e45c28406b9b55a65eb23a258394d50e38416f4bcf59f989',
 'docs/validation/artifacts/evidence-followup-v8-2026-10-21/followup-01.tar.gz':'32ec85ebf1e5ef16ae3d73ebf1ece8d629fd2f55614d5a61c8f0e487d9ca6417',
}
SCOPE = """Pilot scope adapter only: reuse the exact whole-answer semantic criterion in quality-review-v6-instructions.txt, changing only its twelve-pair scope to the two pilot seeded pairs. Review all four complete drafts and the full retained world, including form failures, absences, mechanisms, scope, attribution, explanations and uncertainty. Existing calibrated R1/R2 tasks disclose their actual prior experiment exposure. They are independent of each other's pilot judgments and the pilot position key; they are not newly calibrated or naive to the experiment. Model review service snapshot, usage and cost remain unknown. Freeze both complete two-row envelopes and input/output receipts before opening the position key; reviewers never open it afterward. No policy or release acceptance is authorized. Both trailing drafts must meet the unchanged180-word cap and show no material loss or unresolved tradeoff before root considers a product implementation and separately frozen full confirmation. A poor or ambiguous pilot stops this candidate without replacement or retry. Passing this diagnostic cannot establish general quality, causal robustness, statistical superiority, policy/release acceptance or S0. The substantive source-grounded whole-answer criterion and frozen disposition labels remain unchanged."""

def write(path, data, mode=0o600):
    import os
    raw=(json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
    with os.fdopen(descriptor,'wb') as f:
        f.write(raw);f.flush();os.fsync(f.fileno())
    return hashlib.sha256(raw).hexdigest()

def tool_hashes():
    return {name:digest(P/name) for name in TOOLS} | {'../v8_guards.py':digest(T/'v8_guards.py')}

def base_inputs():
    require(digest(T/BASE_INPUT)==BASE_INPUT_SHA, 'Representative input changed')
    require(digest(T/BASE_REQUEST)==BASE_REQUEST_SHA, 'Representative request changed')
    base=read(T/BASE_INPUT); request=read(T/BASE_REQUEST)
    require(base['prompt'] == request['user'] and sha(base['prompt'])==BASE_PROMPT_SHA, 'Saved exact delivered user prompt required')
    require(request['generator']==GENERATOR and request['max_tokens']==1024, 'Same V8 settings required')
    relocate(base['prompt'])
    return base,request

def freeze():
    approval=read(P/'tooling-review-approval.json')
    require(approval.get('reviewed_by')=='/root' and approval.get('authorized_to_freeze') is True, 'Explicit root helper review/freeze authorization required')
    require(approval['tool_modules']==tool_hashes(), 'Root reviewed exact helper bytes required')
    require(approval['proposal_sha256']==PROPOSAL_SHA, 'Reviewed proposal binding')
    require(digest(T/PROPOSAL)==PROPOSAL_SHA, 'Proposal changed')
    design=R/'docs/design/evidence-selection-and-delivery.md'
    require(approval['design_sha256']==digest(design), 'Reviewed design binding')
    require('### Isolate form-cue placement after V8' in design.read_text(), 'Design must precede pilot freeze')
    check_hashes(R,ARCHIVE)
    check_hashes(T,PRIOR_LEDGERS | PRIOR_NEGATIVES | REVIEW_CONTROL_HASHES)
    prior=read(T/'v8-review-protocol.json')
    require(digest(T/'v8-review-protocol.json')=='a0281ee5b2a22538d1457d22bb64db0f1442e4f1ae3d93bd9e4329fa5ecaab91', 'Frozen V8 protocol binding')
    protocol={
      'schema':'deepr.scratch.form-position-pilot.v1','status':'frozen','diagnostic_only':True,
      'unshipped_string_only_transform':True,'product_source_changed':False,
      'local_generation_ceiling':4,'wall_ceiling_seconds':1800,'paid_provider_api_ceiling_usd':0,'automatic_retry':False,
      'generator':GENERATOR,'allowances':{'consult_prompt_chars':6500,'output_tokens':1024,'call_timeout_seconds':600},
      'prior_native_attempts':204,'total_native_attempts_if_full':208,'prior_ledgers':PRIOR_LEDGERS,
      'prior_negative_assessments_sha256':PRIOR_NEGATIVES,'review_controls':REVIEW_CONTROL_HASHES,
      'source_recipe_sha256':RECIPE,'source_modules':prior['source_modules'],'extra_source_modules':prior['extra_source_modules'],
      'archive_seal':ARCHIVE,'tool_modules':tool_hashes(),'root_review_sha256':digest(P/'tooling-review-approval.json'),
      'proposal_sha256':PROPOSAL_SHA,'design_sha256':digest(design),'review_scope_adapter':SCOPE,
      'reviewer_tasks':approval['reviewer_tasks'],
      'reviewer_exposure_disclosure':approval['reviewer_exposure_disclosure'],
      'reused_primary_calibration_admission':approval['reused_primary_calibration_admission'],
      'resource_reporting':'Separate append-only native ledger; direct provider API ceiling0; hardware and model-review service usage/cost unknown, not zero service cost.',
      'source_references':{n:digest(T/n) for n in ('v8-review-protocol.json','v8-source-final.json','packing-v8-source-snapshot-receipt.json','packing-v8-prospective-extras-receipt.json','packing-v8-source-recipe-proof.json',BASE_INPUT,BASE_REQUEST,PROPOSAL)},
      'source_snapshot':'source-snapshot','frozen_at':datetime.now(UTC).isoformat(),
      'ordering':'Randomized seed-block order; random first position in block1 and opposite first position in block2, fixed prospectively before any answers. Reused identical development prompt, no held-out or deterministic-replay claim.',
      'criterion':'Both trailing complete drafts at most180 visible whitespace words and no material supported usefulness loss or unresolved tradeoff in independent whole-answer review. Poor/ambiguous stops candidate. No policy/release acceptance.',
    }
    require(set(protocol['reviewer_tasks'])=={'R1','R2'} and len(set(protocol['reviewer_tasks'].values()))==2, 'Two actual existing reviewer tasks required')
    require(bool(protocol['reviewer_exposure_disclosure'].strip()), 'Actual prior reviewer exposure must be disclosed')
    calibration=protocol['reused_primary_calibration_admission']
    require(digest(T/calibration['path'])==calibration['sha256'], 'Actual reused primary calibration admission binding')
    validate_protocol(protocol);validate_source(R,protocol);validate_prior(T,protocol)
    base,request=base_inputs()
    # This exclusive durable latch refuses rebuild/re-randomization after interruption.
    write(P/'freeze-started.json',{'started_at':protocol['frozen_at'],'tool_modules':tool_hashes()})
    snapshot=P/'source-snapshot';snapshot.mkdir()
    for rel in MODULE_PATHS+EXTRA_MODULE_PATHS:
        target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:
            f.write((R/rel).read_bytes());f.flush()
            import os
            os.fsync(f.fileno())
    validate_source(snapshot,protocol)
    write(P/'source-snapshot-receipt.json',{'captured_at':datetime.now(UTC).isoformat(),'prospective':True,'source_recipe_sha256':RECIPE,'source_modules':protocol['source_modules'],'extra_source_modules':protocol['extra_source_modules'],'recipe_algorithm':'ordered stripped-src path UTF8 followed by raw bytes, no delimiter; exactly20 owning modules','source_count':23})
    protocol['source_snapshot_receipt_sha256']=digest(P/'source-snapshot-receipt.json')
    seeds=list(GENERATOR['seeds']);secrets.SystemRandom().shuffle(seeds)
    first=secrets.choice(['leading','trailing']);other={'leading':'trailing','trailing':'leading'}
    schedule=[(seeds[0],first),(seeds[0],other[first]),(seeds[1],other[first]),(seeds[1],first)]
    inputs=P/'inputs';inputs.mkdir();key=[];jobs=[];items=[]
    for seed,position in schedule:
        iid=secrets.token_hex(8);item=copy.deepcopy(base)
        item.update(item_id=iid,seed=seed,prompt=base['prompt'] if position=='leading' else relocate(base['prompt']))
        item['prompt_sha256']=sha(item['prompt']);item['prompt_chars']=len(item['prompt'])
        item['delivered_evidence'].update(prompt=item['prompt'],prompt_sha256=item['prompt_sha256'])
        write(inputs/(iid+'.input.json'),item)
        jobs.append({'item_id':iid,'seed':seed,'input_sha256':digest(inputs/(iid+'.input.json'))})
        key.append({'item_id':iid,'seed':seed,'position':position});items.append(item)
    manifest={'answers_scheduled':4,'pairs':2,'generator':GENERATOR,'jobs':jobs,'system':request['system'],'system_sha256':sha(request['system']),'base_prompt_sha256':BASE_PROMPT_SHA,'base_input_sha256':BASE_INPUT_SHA,'base_request_sha256':BASE_REQUEST_SHA}
    validate_manifest(manifest,items,base)
    write(P/'manifest.json',manifest)
    protocol['manifest_sha256']=digest(P/'manifest.json')
    write(P/'protocol.json',protocol)
    private=P/'position-key-unopened';private.mkdir(mode=0o700)
    key_sha256=write(private/'key.json',{'protocol_sha256':digest(P/'protocol.json'),'assignments':key})
    write(P/'input-freeze.json',{'completed_at':datetime.now(UTC).isoformat(),'protocol_sha256':digest(P/'protocol.json'),'manifest_sha256':digest(P/'manifest.json'),'source_snapshot_receipt_sha256':digest(P/'source-snapshot-receipt.json'),'key_sha256':key_sha256,'tool_modules':tool_hashes(),'generated_answers':False,'dispatch_authorized':False})
    print(json.dumps({'protocol_sha256':digest(P/'protocol.json'),'manifest_sha256':digest(P/'manifest.json'),'input_freeze_sha256':digest(P/'input-freeze.json')}))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--freeze-after-root-review',action='store_true');args=parser.parse_args()
    require(args.freeze_after_root_review,'Explicit freeze switch required')
    freeze()
